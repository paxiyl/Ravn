# Raven 1.8.9 — Block Duel AI

This build adds `Block Duel AI` under `keystrokesmod.client.module.modules.player.BlockDuel` and registers it in `ModuleManager`.

## Behavioral model

The module is stateful and replans every tick. It classifies the local fight state from target distance, relative velocity, acceleration trend, vertical layer, hurt timing, nearby solid geometry, void/island edges, escape cells, local build ceiling, and line-of-sight.

Candidate actions include:
- recover / clutch around void edges and falling states
- block-stop / intercept against an approaching target
- lateral side-wall control against strafes
- cover / corner-pocket creation
- elevation / one-block height changes
- trap / escape-space reduction when the target is confined or near an edge
- bridge continuation near void gaps
- shears lane opening when a breakable block blocks the attack line

Each successful action updates a short history and the next action is scored again. Recent cells are penalized, the selected pattern changes with the target's movement state and a per-enable seed, and an action budget plus variable timing is applied.

## Rotation model

Rotation is event-driven through Raven's existing `UpdateEvent`/`LookEvent` pipeline. It uses a fast first move, smaller convergence corrections, limited jitter, and per-action variation instead of a fixed aim step.

## Bed-fight geometry

The planner probes a local lattice around the predicted target and self position, checks support faces and 4.5 block reach, rejects placements intersecting entities, detects nearby void/island edges, tracks a local height ceiling, and evaluates whether a new block would reduce target escape space or obstruct the player's own line.

## Controls

Bind `Block Duel AI` to a key and keep it held when `Require key held` is enabled.

Recommended starting settings:
- Target range: 8
- Prediction: 3.5
- World scan radius: 4
- Build ceiling: 253
- Aim deg/tick: 18
- Min action: 95 ms
- Max action: 210 ms
- Action budget: 6/s
- Look-ahead: 3
- Pattern uniqueness: 0.8
- Edge awareness: 1
- Trap awareness: 1

This is an adaptive heuristic tactical planner, not a trained neural network. Exact reproduction of a human video is not guaranteed by footage alone, especially with compressed 24/30 FPS recordings.
