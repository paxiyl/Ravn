# AutoStyle Module Review Package

## What this is
All code related to the AutoStyle / CrazyFlick / KBDisplacement combat modules
for the Raven B+++ client (Minecraft 1.8.9, Forge, SpongePowered Mixin 0.6, Java 8).

## Files

### AutoStyle system (combat/autostyle/)
- `AutoStyle.java` — Main module. Settings, event hooks, spring-damper tracking, flick trigger
- `FlickEngine.java` — Flick state machine, direction selection, trajectory creation
- `FlickTrajectory.java` — 2-phase piecewise easing (easeOutCubic → easeOutQuad)
- `TargetManager.java` — Target acquisition, locking, combo tracking, prediction
- `MovementAnalyzer.java` — Player strafe detection, velocity, relative angles
- `Rotation.java` — Yaw/pitch wrapper with angle math

### Other combat modules modified
- `CrazyFlick.java` — Combo-based flick with wobble, spring-damper settle
- `KBDisplacement.java` — Void detection + rotation flick for bridge KB

### Framework files (for context)
- `Module.java` — Base module class
- `ModuleManager.java` — Module registration
- `SliderSetting.java` / `TickSetting.java` / `ComboSetting.java` / `DescriptionSetting.java` — Settings API
- `UpdateEvent.java` / `ForgeEvent.java` — Event system
- `AimAssist.java` — Reference for spring-damper physics

## Key design decisions
1. **Spring-damper tracking** — Same physics as AimAssist, omega scales with intensity
2. **Hit-only flick** — Default triggers on `hurtTime > 0 && prevHurtTime == 0` (actual damage)
3. **2-phase trajectory** — Fast flick out (easeOutCubic), smooth return (easeOutQuad)
4. **Distance-scaled amplitude** — Closer = smaller flick
5. **7 presets** — Auto-fill sliders when switched, CUSTOM for manual control
6. **8 total settings** — Preset, Range, Intensity, Pitch, Cooldown, HitOnly, Manual, Debug

## Environment
- MC 1.8.9, Forge, Java 8
- `MathHelper.wrapAngleTo180_float()` not `wrapDegrees`
- `Vec3.addVector()` not `add()`
- `KeyBinding.isKeyDown()` not `getIsKeyPressed()`
- `TickSetting.setEnabled(boolean)` not `setToggled()`
