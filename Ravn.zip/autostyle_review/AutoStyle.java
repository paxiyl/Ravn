package keystrokesmod.client.module.modules.combat.autostyle;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class AutoStyle extends Module {

    private static final TargetManager targetMgr = new TargetManager();
    private static final FlickEngine flick = new FlickEngine();

    private static ComboSetting<Style> style;
    private static SliderSetting range;
    private static SliderSetting intensity;
    private static SliderSetting pitchAmt;
    private static SliderSetting cooldownMs;
    private static SliderSetting minCombo;
    private static TickSetting hitOnly;
    private static TickSetting manualTrigger;
    private static TickSetting debug;

    private double velYaw = 0, velPitch = 0;
    private long lastFlickEnd = 0;
    private int prevEnemyHurtTime = -1;
    private int prevPlayerHurtTime = 0;
    private int comboHits = 0;
    private EntityPlayer lastTarget = null;
    private Style lastStyle = null;

    public AutoStyle() {
        super("AutoStyle", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Activates after combo hits"));
        this.registerSetting(style = new ComboSetting("Style", Style.REFERENCE));
        this.registerSetting(range = new SliderSetting("Range", 4.0D, 2.0D, 8.0D, 0.1D));
        this.registerSetting(intensity = new SliderSetting("Intensity", 75.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(pitchAmt = new SliderSetting("Pitch amount", 8.0D, 0.0D, 25.0D, 0.5D));
        this.registerSetting(cooldownMs = new SliderSetting("Cooldown ms", 300.0D, 100.0D, 800.0D, 10.0D));
        this.registerSetting(minCombo = new SliderSetting("Min combo hits", 3.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(hitOnly = new TickSetting("Flick on hit only", true));
        this.registerSetting(manualTrigger = new TickSetting("Manual trigger (V)", false));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public void onEnable() {
        targetMgr.reset();
        flick.reset();
        velYaw = 0;
        velPitch = 0;
        lastFlickEnd = 0;
        prevEnemyHurtTime = -1;
        prevPlayerHurtTime = 0;
        comboHits = 0;
        lastTarget = null;
        lastStyle = null;
        applyPreset(style.getMode());
    }

    @Override
    public void onDisable() {
        targetMgr.reset();
        flick.reset();
    }

    @Override
    public void guiUpdate() {
        Style current = style.getMode();
        if (current != lastStyle) {
            applyPreset(current);
            lastStyle = current;
        }
    }

    private void applyPreset(Style s) {
        switch (s) {
            case SUBTLE:    intensity.setValue(25); pitchAmt.setValue(3); cooldownMs.setValue(400); hitOnly.enable(); break;
            case CLEAN:     intensity.setValue(45); pitchAmt.setValue(5); cooldownMs.setValue(350); hitOnly.enable(); break;
            case NORMAL:    intensity.setValue(60); pitchAmt.setValue(7); cooldownMs.setValue(300); hitOnly.enable(); break;
            case AGGRESSIVE:intensity.setValue(80); pitchAmt.setValue(10); cooldownMs.setValue(220); hitOnly.enable(); break;
            case BOXING:    intensity.setValue(90); pitchAmt.setValue(8); cooldownMs.setValue(180); hitOnly.disable(); break;
            case REFERENCE: intensity.setValue(75); pitchAmt.setValue(8); cooldownMs.setValue(280); hitOnly.enable(); break;
            case CUSTOM:    break;
        }
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!Utils.Player.isPlayerInGame()) return;
        if (!(fe.getEvent() instanceof AttackEntityEvent)) return;

        AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
        if (!(event.target instanceof EntityPlayer)) return;

        EntityPlayer hit = (EntityPlayer) event.target;

        // Reset combo if target changed
        if (hit != lastTarget) {
            comboHits = 0;
            prevEnemyHurtTime = -1;
            lastTarget = hit;
        }

        targetMgr.lockTarget(hit);

        long now = System.nanoTime();
        boolean canFlick = now - lastFlickEnd > (long)(cooldownMs.getInput() * 1_000_000);

        // Only count actual hits (enemy actually took damage)
        boolean actualHit = hit.hurtTime > 0 && prevEnemyHurtTime <= 0;

        if (actualHit) {
            comboHits++;
            prevEnemyHurtTime = hit.hurtTime;

            boolean shouldFlick;
            if (hitOnly.isToggled()) {
                shouldFlick = true;
            } else {
                shouldFlick = canFlick;
            }

            if (shouldFlick && canFlick && !flick.isFlicking() && comboHits >= (int) minCombo.getInput()) {
                flick.startFlick(hit, intensity.getInput(), pitchAmt.getInput());
                lastFlickEnd = now + flick.getTrajectoryDurationNanos();
            }
        } else {
            prevEnemyHurtTime = hit.hurtTime;
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (mc.currentScreen != null) { flick.reset(); return; }

        // Reset combo if player gets hit
        if (mc.thePlayer.hurtTime > 0 && prevPlayerHurtTime <= 0) {
            comboHits = 0;
            flick.reset();
        }
        prevPlayerHurtTime = mc.thePlayer.hurtTime;

        if (manualTrigger.isToggled()) {
            manualTrigger.disable();
            EntityPlayer t = targetMgr.getLockedTarget();
            if (t == null) t = findTarget();
            if (t != null && !flick.isFlicking()) {
                targetMgr.lockTarget(t);
                lastTarget = t;
                comboHits = (int) minCombo.getInput();
                flick.startFlick(t, intensity.getInput(), pitchAmt.getInput());
                lastFlickEnd = System.nanoTime() + flick.getTrajectoryDurationNanos();
            }
        }

        if (flick.isFlicking()) {
            Rotation rot = flick.evaluate();
            if (rot != null) {
                mc.thePlayer.rotationYaw = rot.yaw;
                mc.thePlayer.rotationPitch = rot.pitch;
                mc.thePlayer.rotationYawHead = rot.yaw;
                mc.thePlayer.renderYawOffset = rot.yaw;
                e.setYaw(rot.yaw);
                e.setPitch(rot.pitch);
            }
        }
    }

    private EntityPlayer findTarget() {
        return targetMgr.findTarget(range.getInput(), 180.0, true, false, TargetManager.TargetPriority.COMBO_LOCK);
    }

    public static TargetManager getTargetManager() { return targetMgr; }
    public static FlickEngine getFlickEngine() { return flick; }

    public enum Style {
        SUBTLE, CLEAN, NORMAL, AGGRESSIVE, BOXING, REFERENCE, CUSTOM
    }
}
