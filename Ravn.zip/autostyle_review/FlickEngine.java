package keystrokesmod.client.module.modules.combat.autostyle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class FlickEngine {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private FlickTrajectory trajectory;
    private long flickStart = 0;
    private boolean flicking = false;
    private int styleCount = 0;

    public boolean isFlicking() { return flicking; }

    public void reset() {
        trajectory = null;
        flicking = false;
        styleCount = 0;
    }

    public void startFlick(
        EntityPlayer target,
        double intensity,
        double pitchAmount
    ) {
        if (mc.thePlayer == null || target == null) return;

        styleCount++;
        boolean do360 = (styleCount % 5) == 1 || (styleCount % 5) == 2;

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        float desiredYaw = getDesiredYaw(target);
        float desiredPitch = getDesiredPitch(target);

        if (do360) {
            create360Flick(curYaw, curPitch, desiredYaw, desiredPitch, intensity, pitchAmount);
        } else {
            createStyleFlick(curYaw, curPitch, desiredYaw, desiredPitch, intensity, pitchAmount);
        }

        flickStart = System.nanoTime();
        flicking = true;
    }

    private void create360Flick(
        float curYaw, float curPitch,
        float desiredYaw, float desiredPitch,
        double intensity, double pitchAmount
    ) {
        boolean clockwise = Math.random() < 0.5;
        float spinAmount = (float)(270.0 + Math.random() * 90.0);
        float sign = clockwise ? 1.0F : -1.0F;

        float peakYaw = curYaw + sign * spinAmount;
        float peakPitch = Rotation.clampPitch(curPitch + (float)(pitchAmount * 0.15 * sign));

        long awayNs = (long) (60_000_000 + Math.random() * 30_000_000);
        long holdNs = (long) (10_000_000 + Math.random() * 15_000_000);
        long returnNs = (long) (80_000_000 + Math.random() * 40_000_000);

        trajectory = new FlickTrajectory(
            curYaw, curPitch,
            peakYaw, peakPitch,
            desiredYaw, Rotation.clampPitch(desiredPitch),
            awayNs, holdNs, returnNs
        );
    }

    private void createStyleFlick(
        float curYaw, float curPitch,
        float desiredYaw, float desiredPitch,
        double intensity, double pitchAmount
    ) {
        double distance = mc.thePlayer.getDistanceToEntity(target);
        double distFactor = Math.min(1.0, distance / 3.0);

        double amplitude = (18.0 + intensity * 0.35) * distFactor;
        double jitter = 1.0 + (Math.random() - 0.5) * 0.2;
        amplitude *= jitter;

        float awayYaw = Rotation.angleDiff(desiredYaw, curYaw);
        boolean flickLeft = awayYaw > 0;
        float sign = flickLeft ? -1.0F : 1.0F;

        float peakYaw = curYaw + sign * (float) amplitude;
        float peakPitch = Rotation.clampPitch(curPitch + (float)(pitchAmount * 0.2 * sign));

        long awayNs = (long) (40_000_000 + Math.random() * 30_000_000);
        long holdNs = (long) (30_000_000 + Math.random() * 40_000_000);
        long returnNs = (long) (100_000_000 + Math.random() * 60_000_000);

        trajectory = new FlickTrajectory(
            curYaw, curPitch,
            peakYaw, peakPitch,
            desiredYaw, Rotation.clampPitch(desiredPitch),
            awayNs, holdNs, returnNs
        );
    }

    public Rotation evaluate() {
        if (!flicking || trajectory == null) return null;

        long elapsed = System.nanoTime() - flickStart;
        Rotation rot = trajectory.evaluate(elapsed);

        if (trajectory.isComplete(elapsed)) {
            flicking = false;
            trajectory = null;
        }

        return rot;
    }

    public long getTrajectoryDurationNanos() {
        return trajectory != null ? trajectory.getTotalNanos() : 0;
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.5) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
