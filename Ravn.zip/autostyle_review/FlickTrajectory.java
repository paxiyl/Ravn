package keystrokesmod.client.module.modules.combat.autostyle;

public class FlickTrajectory {

    private final float startYaw, startPitch;
    private final float peakYaw, peakPitch;
    private final float endYaw, endPitch;
    private final long awayNanos;
    private final long holdNanos;
    private final long returnNanos;
    private final long totalNanos;

    public FlickTrajectory(
        float startYaw, float startPitch,
        float peakYaw, float peakPitch,
        float endYaw, float endPitch,
        long awayNanos, long holdNanos, long returnNanos
    ) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.awayNanos = awayNanos;
        this.holdNanos = holdNanos;
        this.returnNanos = returnNanos;
        this.totalNanos = awayNanos + holdNanos + returnNanos;
    }

    public Rotation evaluate(long elapsedNanos) {
        if (elapsedNanos >= totalNanos) return new Rotation(endYaw, endPitch);

        // Phase 1: flick away (fast, easeOutCubic)
        if (elapsedNanos < awayNanos) {
            double t = (double) elapsedNanos / awayNanos;
            double e = easeOutCubic(t);
            return new Rotation(
                startYaw + (peakYaw - startYaw) * (float) e,
                Rotation.clampPitch(startPitch + (peakPitch - startPitch) * (float) e)
            );
        }

        // Phase 2: hold at peak (camera stays away)
        long afterAway = elapsedNanos - awayNanos;
        if (afterAway < holdNanos) {
            return new Rotation(peakYaw, Rotation.clampPitch(peakPitch));
        }

        // Phase 3: smooth return (easeOutQuint — starts fast, decelerates)
        long afterHold = afterAway - holdNanos;
        double t = (double) afterHold / returnNanos;
        double e = easeOutQuint(t);
        return new Rotation(
            peakYaw + (endYaw - peakYaw) * (float) e,
            Rotation.clampPitch(peakPitch + (endPitch - peakPitch) * (float) e)
        );
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalNanos;
    }

    public long getTotalNanos() { return totalNanos; }

    private static double easeOutCubic(double t) {
        double f = 1.0 - t;
        return 1.0 - f * f * f;
    }

    private static double easeOutQuint(double t) {
        double f = 1.0 - t;
        return 1.0 - f * f * f * f * f;
    }
}
