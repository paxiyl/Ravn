# Ravn -> OpenMyau Plus port

Ported from the supplied Ravn source tree into the supplied OpenMyau-Plus 1.6-1 tree:

- AimAssist combo-auto-aim behavior: after two consecutive enemy hurt transitions while the player has not been hurt, combo aim can operate without the normal click gate; player hurt resets the combo state.
- AimSmooth: Ravn's MouseHelper delta smoothing filter and sub-pixel accumulation, connected through an OpenMyau mixin.
- AutoStyle: Ravn AutoStyle plus its TargetManager/FlickEngine/FlickTrajectory/MovementAnalyzer/Rotation support classes, adapted to OpenMyau's event/property APIs.
- Bridge Assist: Ravn timing, bridge-angle tables, GCD quantization and assist behavior adapted to OpenMyau's module/property/event APIs.
- LegitTelly: Ravn cycle tables, activation sequence, anti-sway, rotation interpolation/quantization, placement logic, autoswap, safety stops, packet handling and input timing adapted to OpenMyau events.

GUI changes:

- Added the ported modules to ClickGui.
- Category panels are laid out in fixed horizontal columns.
- Opened categories render their modules as one continuous vertical list with no internal scrolling.
- Saved GUI positions no longer override the fixed column layout; open/closed state is still restored.

Verification note:

The included OpenMyau Gradle wrapper could not download Gradle 8.8 in the execution environment because outbound network access is unavailable. The source tree was therefore checked for Ravn API remnants, registration coverage, imports and generated-file consistency, but a full Gradle compile was not possible in this environment.
