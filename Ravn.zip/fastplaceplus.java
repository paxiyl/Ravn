long nextClickTime = 0;
long lastCpsUpdate = 0;
long startHoldingTime = 0;
double currentTargetCps = 0;
boolean butterflySecondClick = false;
int slowClicksRemaining = 0;

void onLoad() {
    modules.registerSlider("Mode", "", 2, new String[]{"Normal", "Jitter", "Butterfly", "Drag"});
    modules.registerSlider("Min CPS", "", 25, 1, 50, 1);
    modules.registerSlider("Max CPS", "", 30, 1, 50, 1);
    modules.registerSlider("Initial delay", "ms", 120, 5, 1000, 1);
    modules.registerButton("Only holding", true);
    modules.registerButton("Blocks only", true);
    modules.registerButton("Blacklist obsidian", true);
    modules.registerButton("Legit", false);
}

void onDisable() {
    resetState();
}

void resetState() {
    nextClickTime = 0;
    lastCpsUpdate = 0;
    startHoldingTime = 0;
    butterflySecondClick = false;
    slowClicksRemaining = 0;
    currentTargetCps = 0;
}

void onPreUpdate() {
    boolean onlyHolding = modules.getButton(scriptName, "Only holding");
    boolean isHolding = keybinds.isMouseDown(1);

    if (onlyHolding && !isHolding) {
        resetState();
        return;
    }

    if (!onlyHolding && !isHolding) {
        isHolding = true;
    }

    if (modules.getButton(scriptName, "Blocks only")) {
        ItemStack item = inventory.getStackInSlot(inventory.getSlot());
        if (item == null || !item.isBlock) {
            resetState();
            return;
        }
    }

    if (modules.getButton(scriptName, "Blacklist obsidian")) {
        Entity player = client.getPlayer();
        if (player != null) {
            Object[] ray = client.raycastBlock(5.0, player.getYaw(), player.getPitch());
            if (ray != null && ray[0] != null) {
                Block b = world.getBlockAt((Vec3) ray[0]);
                if (b != null && b.name != null && b.name.toLowerCase().contains("obsidian")) {
                    resetState();
                    return;
                }
            }
            ItemStack held = inventory.getStackInSlot(inventory.getSlot());
            if (held != null && held.name != null && held.name.toLowerCase().contains("obsidian")) {
                resetState();
                return;
            }
        }
    }

    long now = client.time();
    
    if (startHoldingTime == 0) {
        startHoldingTime = now;
        double initDelay = modules.getSlider(scriptName, "Initial delay");
        nextClickTime = startHoldingTime + (long) initDelay + calculateDelay();
    }

    if (now >= nextClickTime) {
        int mode = (int) modules.getSlider(scriptName, "Mode");
        boolean legit = modules.getButton(scriptName, "Legit");
        
        if (mode == 2) { // Butterfly
            if (butterflySecondClick) {
                keybinds.rightClick();
                butterflySecondClick = false;
                // Reduced butterfly gap slightly
                nextClickTime = now + (legit ? util.randomInt(10, 25) : 20);
            } else {
                keybinds.rightClick();
                butterflySecondClick = true;
                nextClickTime = now + calculateDelay();
            }
        } else {
            keybinds.rightClick();
            nextClickTime = now + calculateDelay();
        }
    }
}

long calculateDelay() {
    long now = client.time();
    int mode = (int) modules.getSlider(scriptName, "Mode");
    boolean legit = modules.getButton(scriptName, "Legit");

    if (currentTargetCps == 0 || (legit && now - lastCpsUpdate > util.randomInt(800, 2000))) {
        double minCps = modules.getSlider(scriptName, "Min CPS");
        double maxCps = modules.getSlider(scriptName, "Max CPS");
        if (minCps > maxCps) {
            double temp = minCps;
            minCps = maxCps;
            maxCps = temp;
        }
        currentTargetCps = util.randomDouble(minCps, maxCps);
        lastCpsUpdate = now;
    }

    long baseDelay = (long) (1000.0 / currentTargetCps);

    if (!legit) {
        return baseDelay;
    }

    if (mode == 3) { // Drag
        return util.randomInt(33, 45);
    }

    long extraDelay = 0;
    
    if (slowClicksRemaining > 0) {
        // Reduced slow down delay
        extraDelay = util.randomInt(20, 50); 
        slowClicksRemaining--;
    } else {
        double slowChance = (mode == 1) ? 0.04 : 0.06;
        if (Math.random() < slowChance) {
            slowClicksRemaining = util.randomInt(1, 3);
        }
    }

    long delay = baseDelay + extraDelay;

    // Reduced variance for tighter but still human-like clicks
    if (mode == 1) { // Jitter
        delay += util.randomInt(-2, 6);
    } else { // Normal
        delay += util.randomInt(-5, 12);
    }

    if (delay < 34) {
        delay = 34;
    }

    return delay;
}