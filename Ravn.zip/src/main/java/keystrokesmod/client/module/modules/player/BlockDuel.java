package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.LookEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.InventoryUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/**
 * Block Duel AI
 *
 * Stateful tactical planner for Minecraft 1.8.9 bed-fight combat.  The module
 * intentionally does not follow a prerecorded bridge/scaffold sequence.  It
 * rebuilds a short-horizon world model every tick and selects one action from
 * a scored candidate set.  Each action causes the model to be re-evaluated.
 *
 * The model watches:
 *  - relative movement / acceleration and recent strafe direction;
 *  - target distance, hurt state and vertical layer;
 *  - local island/void edges and the player's own safe footprint;
 *  - nearby solid geometry and available support faces;
 *  - head-space / escape-space around both players;
 *  - height ceiling and local build ceiling;
 *  - attack-lane visibility and shears-breakable blockers;
 *  - recent placements so repeated cells/patterns are discouraged.
 *
 * It chooses between cover, side-wall, block-stop, trap, elevation, bridge
 * extension, clutch/recovery and lane-opening actions.  The intent is to
 * reproduce the *decision structure* visible in the supplied gameplay rather
 * than a fixed CPS/rotation macro.
 */
public class BlockDuel extends Module {
    private static final int ACT_NONE = 0;
    private static final int ACT_PLACE = 1;
    private static final int ACT_BREAK = 2;

    private static final int MODE_COVER = 0;
    private static final int MODE_SIDEWALL = 1;
    private static final int MODE_STOP = 2;
    private static final int MODE_TRAP = 3;
    private static final int MODE_ELEVATE = 4;
    private static final int MODE_BRIDGE = 5;
    private static final int MODE_RECOVER = 6;
    private static final int MODE_OPEN = 7;

    private static final int BEHAVIOR_STILL = 0;
    private static final int BEHAVIOR_RUSH = 1;
    private static final int BEHAVIOR_RETREAT = 2;
    private static final int BEHAVIOR_STRAFE_LEFT = 3;
    private static final int BEHAVIOR_STRAFE_RIGHT = 4;
    private static final int BEHAVIOR_AIRBORNE = 5;

    public static SliderSetting targetRange;
    public static SliderSetting predictionTicks;
    public static SliderSetting scanRadius;
    public static SliderSetting maxBuildY;
    public static SliderSetting rotationSpeed;
    public static SliderSetting rotationJitter;
    public static SliderSetting minActionDelay;
    public static SliderSetting maxActionDelay;
    public static SliderSetting maxActionsPerSecond;
    public static SliderSetting planningDepth;
    public static SliderSetting uniqueness;
    public static SliderSetting edgeBias;
    public static SliderSetting trapBias;
    public static SliderSetting defenseBias;
    public static SliderSetting escapeBias;
    public static SliderSetting lookAheadTicks;
    public static SliderSetting patternDrift;
    public static TickSetting holdKey;
    public static TickSetting placeBlocks;
    public static TickSetting useShears;
    public static TickSetting autoSelect;
    public static TickSetting attackLaneBreak;
    public static TickSetting allowHighPlace;

    private EntityPlayer target;
    private WorldModel model;
    private ActionPlan plan;
    private ActionPlan lastPlan;

    private float appliedYaw;
    private float appliedPitch;
    private float previousAppliedYaw;
    private float previousAppliedPitch;
    private boolean rotationApplied;

    private int savedSlot = -1;
    private boolean slotOwned;
    private long nextActionAt;
    private long actionWindowStart;
    private int actionsInWindow;

    private final Random rng = new Random();
    private final Deque<BlockPos> recentPlacements = new ArrayDeque<>();
    private final Deque<Snapshot> targetHistory = new ArrayDeque<>();
    private int targetId = -1;
    private int targetTicks;
    private int placementCount;
    private int uniqueSeed;
    private int behavior;
    private int manualSlot = -1;
    private int patternPhase;
    private int lastLateralSign;
    private int lastMode = -1;
    private long lastDecisionAt;

    public BlockDuel() {
        super("Block Duel AI", ModuleCategory.player);
        registerSetting(new DescriptionSetting(
                "Real-time bed-fight tactical block AI: predicts movement, reads island geometry, stops/traps opponents and opens lanes with shears."));
        registerSetting(targetRange = new SliderSetting("Target range", 8.0D, 3.0D, 12.0D, 0.5D));
        registerSetting(predictionTicks = new SliderSetting("Prediction", 3.5D, 1.0D, 8.0D, 0.5D));
        registerSetting(scanRadius = new SliderSetting("World scan radius", 4.0D, 2.0D, 7.0D, 1.0D));
        registerSetting(maxBuildY = new SliderSetting("Build ceiling", 253.0D, 64.0D, 254.0D, 1.0D));
        registerSetting(rotationSpeed = new SliderSetting("Aim deg/tick", 18.0D, 5.0D, 35.0D, 1.0D));
        registerSetting(rotationJitter = new SliderSetting("Aim variation", 1.2D, 0.0D, 4.0D, 0.1D));
        registerSetting(minActionDelay = new SliderSetting("Min action ms", 95.0D, 40.0D, 250.0D, 5.0D));
        registerSetting(maxActionDelay = new SliderSetting("Max action ms", 210.0D, 70.0D, 450.0D, 5.0D));
        registerSetting(maxActionsPerSecond = new SliderSetting("Action budget", 6.0D, 2.0D, 10.0D, 0.5D));
        registerSetting(planningDepth = new SliderSetting("Look-ahead", 3.0D, 1.0D, 5.0D, 1.0D));
        registerSetting(uniqueness = new SliderSetting("Pattern uniqueness", 0.8D, 0.0D, 2.0D, 0.1D));
        registerSetting(edgeBias = new SliderSetting("Edge awareness", 1.0D, 0.0D, 2.0D, 0.1D));
        registerSetting(trapBias = new SliderSetting("Trap awareness", 1.0D, 0.0D, 2.0D, 0.1D));
        registerSetting(defenseBias = new SliderSetting("Defense bias", 1.35D, 0.4D, 3.0D, 0.1D));
        registerSetting(escapeBias = new SliderSetting("Escape bias", 1.55D, 0.5D, 3.5D, 0.1D));
        registerSetting(lookAheadTicks = new SliderSetting("Threat look-ahead", 4.0D, 1.0D, 8.0D, 0.5D));
        registerSetting(patternDrift = new SliderSetting("Pattern drift", 0.85D, 0.0D, 2.0D, 0.05D));
        registerSetting(holdKey = new TickSetting("Require key held", true));
        registerSetting(placeBlocks = new TickSetting("Place blocks", true));
        registerSetting(useShears = new TickSetting("Break with shears", true));
        registerSetting(autoSelect = new TickSetting("Auto-select hotbar", true));
        registerSetting(attackLaneBreak = new TickSetting("Open blocked lane", true));
        registerSetting(allowHighPlace = new TickSetting("Allow high placements", true));
        setVisableInHud(true);
    }

    @Override
    public void onEnable() {
        reset();
        uniqueSeed = rng.nextInt(1000000);
    }

    @Override
    public void onDisable() {
        restoreSlot();
        reset();
    }

    private void reset() {
        target = null;
        model = null;
        plan = null;
        lastPlan = null;
        appliedYaw = appliedPitch = previousAppliedYaw = previousAppliedPitch = 0.0F;
        rotationApplied = false;
        savedSlot = -1;
        slotOwned = false;
        nextActionAt = 0L;
        actionWindowStart = System.currentTimeMillis();
        actionsInWindow = 0;
        recentPlacements.clear();
        targetHistory.clear();
        targetId = -1;
        targetTicks = 0;
        placementCount = 0;
        behavior = BEHAVIOR_STILL;
        manualSlot = -1;
        patternPhase = rng.nextInt(32);
        lastLateralSign = 0;
        lastMode = -1;
        lastDecisionAt = 0L;
    }

    private boolean active() {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null)
            return false;
        if (mc.currentScreen != null)
            return false;
        return !holdKey.isToggled() || (keycode != 0 && Keyboard.isKeyDown(keycode));
    }

    @Subscribe
    public void onTick(TickEvent event) {
        if (!active()) {
            plan = null;
            restoreSlot();
            return;
        }
        pruneBudget();
        EntityPlayer next = acquireTarget();
        if (next == null) {
            target = null;
            model = null;
            plan = null;
            restoreSlot();
            return;
        }
        if (target == null || target.getEntityId() != next.getEntityId()) {
            target = next;
            targetId = next.getEntityId();
            targetHistory.clear();
            placementCount = 0;
            targetTicks = 0;
            lastPlan = null;
        }
        target = next;
        targetTicks++;
        pushSnapshot(target);
        behavior = classifyBehavior();
        model = buildWorldModel();
        patternPhase = (patternPhase + 1) & 31;
        plan = chooseAction(model);
        lastDecisionAt = System.nanoTime();
    }

    @Subscribe
    public void onUpdate(UpdateEvent event) {
        if (!active() || plan == null)
            return;
        if (event.isPre())
            aimPre(event);
        else
            actPost();
    }

    @Subscribe
    public void onLook(LookEvent event) {
        if (!active() || !rotationApplied)
            return;
        event.setPrevYaw(previousAppliedYaw);
        event.setPrevPitch(previousAppliedPitch);
        event.setYaw(appliedYaw);
        event.setPitch(appliedPitch);
    }

    private void aimPre(UpdateEvent event) {
        float cy = mc.thePlayer.rotationYaw;
        float cp = mc.thePlayer.rotationPitch;
        float dy = MathHelper.wrapAngleTo180_float(plan.yaw - cy);
        float dp = plan.pitch - cp;

        double contextual = Math.min(1.0D, plan.urgency / 10.0D);
        float base = (float) rotationSpeed.getInput();
        float step = base * (0.70F + 0.55F * (float) contextual);
        float jitter = (float) rotationJitter.getInput();

        // Smooth, variable pursuit: quick first movement, smaller correction,
        // tiny drift on the final degrees. The phase changes with each target
        // and selected action so successive fights do not use one signature.
        float phase = (float) ((mc.thePlayer.ticksExisted + uniqueSeed * 0.001) * 0.31);
        float jYaw = (float) Math.sin(phase) * jitter * 0.55F;
        float jPitch = (float) Math.cos(phase * 0.83F) * jitter * 0.32F;
        if ((placementCount + targetTicks) % 7 == 0) {
            jYaw *= 1.35F;
            jPitch *= 1.2F;
        }

        float sy = MathHelper.clamp_float(dy + jYaw, -step, step);
        float sp = MathHelper.clamp_float(dp + jPitch, -step * 0.8F, step * 0.8F);
        if (Math.abs(dy) < 0.9F && rng.nextBoolean()) sy = dy;
        if (Math.abs(dp) < 0.9F && rng.nextInt(3) != 0) sp = dp;

        previousAppliedYaw = rotationApplied ? appliedYaw : cy;
        previousAppliedPitch = rotationApplied ? appliedPitch : cp;
        appliedYaw = cy + sy;
        appliedPitch = MathHelper.clamp_float(cp + sp, -90.0F, 90.0F);
        rotationApplied = true;
        event.setYaw(appliedYaw);
        event.setPitch(appliedPitch);
        mc.thePlayer.rotationYawHead = appliedYaw;
        mc.thePlayer.renderYawOffset = appliedYaw;
    }

    private void actPost() {
        if (System.currentTimeMillis() < nextActionAt || !budgetAvailable())
            return;

        float ey = Math.abs(MathHelper.wrapAngleTo180_float(plan.yaw - (rotationApplied ? appliedYaw : mc.thePlayer.rotationYaw)));
        float ep = Math.abs(plan.pitch - (rotationApplied ? appliedPitch : mc.thePlayer.rotationPitch));
        if (ey > 4.0F || ep > 4.0F)
            return;

        boolean acted = false;
        if (plan.type == ACT_BREAK && useShears.isToggled())
            acted = executeBreak(plan);
        else if (plan.type == ACT_PLACE && placeBlocks.isToggled())
            acted = executePlace(plan);

        if (!acted)
            return;

        lastPlan = plan;
        actionsInWindow++;
        long now = System.currentTimeMillis();
        double min = minActionDelay.getInput();
        double max = Math.max(min, maxActionDelay.getInput());
        double urgency = MathHelper.clamp_double(plan.urgency / 10.0D, 0.0D, 1.0D);
        double desired = max - (max - min) * urgency;
        desired += (rng.nextDouble() - 0.5D) * 30.0D;
        if (plan.mode == MODE_RECOVER || plan.mode == MODE_STOP)
            desired -= 10.0D;
        desired = MathHelper.clamp_double(desired, min, max);
        nextActionAt = now + (long) desired;

        if (plan.type == ACT_PLACE) {
            placementCount++;
            recentPlacements.addLast(plan.block);
            while (recentPlacements.size() > 18)
                recentPlacements.removeFirst();
        }
        if (slotOwned)
            restoreSlot();
        plan = null;
    }

    private void pruneBudget() {
        long now = System.currentTimeMillis();
        if (now - actionWindowStart >= 1000L) {
            actionWindowStart = now;
            actionsInWindow = 0;
        }
    }

    private boolean budgetAvailable() {
        return actionsInWindow < Math.max(1, (int) Math.ceil(maxActionsPerSecond.getInput()));
    }

    private EntityPlayer acquireTarget() {
        double rs = targetRange.getInput() * targetRange.getInput();
        EntityPlayer best = null;
        double bestScore = Double.POSITIVE_INFINITY;
        for (Object o : mc.theWorld.playerEntities) {
            if (!(o instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) o;
            if (p == mc.thePlayer || p.isDead || p.isSpectator() || p.getHealth() <= 0.0F) continue;
            if (mc.thePlayer.getDistanceSqToEntity(p) > rs) continue;

            double d = mc.thePlayer.getDistanceToEntity(p);
            double closing = closingSpeed(p);
            double lateral = lateralSpeed(p);
            double height = Math.abs(p.posY - mc.thePlayer.posY);
            double stability = target != null && p.getEntityId() == target.getEntityId() ? 1.5D : 0.0D;
            double score = d - closing * 2.2D - lateral * 0.45D + height * 0.18D - stability;
            if (score < bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }

    private void pushSnapshot(EntityPlayer p) {
        Snapshot s = new Snapshot(p.posX, p.posY, p.posZ, p.motionX, p.motionY, p.motionZ, p.hurtTime);
        targetHistory.addLast(s);
        while (targetHistory.size() > 8)
            targetHistory.removeFirst();
    }

    private int classifyBehavior() {
        double closing = closingSpeed(target);
        double speed = horizontalSpeed(target.motionX, target.motionZ);
        if (!target.onGround || Math.abs(target.motionY) > 0.12D)
            return BEHAVIOR_AIRBORNE;
        if (speed < 0.035D)
            return BEHAVIOR_STILL;
        if (closing > 0.08D)
            return BEHAVIOR_RUSH;
        if (closing < -0.08D)
            return BEHAVIOR_RETREAT;

        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        double cross = dx * target.motionZ - dz * target.motionX;
        if (cross > 0.035D) return BEHAVIOR_STRAFE_LEFT;
        if (cross < -0.035D) return BEHAVIOR_STRAFE_RIGHT;
        return BEHAVIOR_STILL;
    }

    private WorldModel buildWorldModel() {
        WorldModel m = new WorldModel();
        m.distance = mc.thePlayer.getDistanceToEntity(target);
        m.closing = closingSpeed(target);
        m.enemySpeed = horizontalSpeed(target.motionX, target.motionZ);
        m.playerSpeed = horizontalSpeed(mc.thePlayer.motionX, mc.thePlayer.motionZ);
        m.verticalDelta = target.posY - mc.thePlayer.posY;
        m.inMelee = m.distance <= 3.15D;
        m.veryClose = m.distance <= 1.85D;
        m.targetHurt = target.hurtTime > 0;
        m.playerFalling = mc.thePlayer.fallDistance > 1.2F || (!mc.thePlayer.onGround && mc.thePlayer.motionY < -0.12D);
        m.targetDirection = targetDirection();
        m.lateralDirection = lateralDirection(m.targetDirection);
        m.enemyFuture = predictTarget(m);
        m.selfEdge = edgeInfo(mc.thePlayer);
        m.enemyEdge = edgeInfo(target);
        m.heightCeiling = (int) Math.min(254, Math.floor(maxBuildY.getInput()));
        m.localTopSelf = highestSolidNear(mc.thePlayer, 2);
        m.localTopEnemy = highestSolidNear(target, 2);
        m.attackBlocked = isAttackBlocked();
        m.enemyConfined = confined(target);
        m.selfConfined = confined(mc.thePlayer);
        m.safeEscapeCount = escapeCount(mc.thePlayer);
        m.enemyEscapeCount = escapeCount(target);
        m.hasBlock = findBlockSlot() >= 0;
        m.hasShears = findShearsSlot() >= 0;
        m.inventoryBlocks = blockCount();
        m.nearVoidSelf = nearVoid(mc.thePlayer, 2);
        m.nearVoidEnemy = nearVoid(target, 2);
        m.aheadSupport = supportBelow(m.enemyFuture);
        m.yDeltaToCeiling = m.heightCeiling - (int) Math.floor(Math.max(mc.thePlayer.posY, target.posY));
        m.uniqueBias = Math.sin((targetTicks + uniqueSeed) * 0.173D);
        m.behavior = behavior;
        return m;
    }

    private ActionPlan chooseAction(WorldModel m) {
        if (m == null || target == null)
            return null;

        // First priority is reducing incoming threat. A hard obstruction in the
        // current attack lane gets opened before constructing new geometry.
        if (attackLaneBreak.isToggled() && m.hasShears && m.attackBlocked) {
            ActionPlan open = makeBreakPlan();
            if (open != null) return open;
        }

        if (!m.hasBlock || !placeBlocks.isToggled())
            return null;

        List<ActionPlan> candidates = new ArrayList<>();
        int horizon = Math.max(1, (int) Math.round(planningDepth.getInput()));

        if (m.playerFalling || m.nearVoidSelf)
            addModeCandidates(candidates, m, MODE_RECOVER, horizon + 1);
        if (m.enemyConfined || (m.enemyEdge.distance < 1.25D && m.closing > -0.02D))
            addModeCandidates(candidates, m, MODE_TRAP, horizon);
        if (m.veryClose || m.closing > 0.08D || m.targetHurt)
            addModeCandidates(candidates, m, MODE_STOP, horizon);
        if (m.lateralDirection != 0 || m.enemySpeed > 0.08D)
            addModeCandidates(candidates, m, MODE_SIDEWALL, horizon);
        if (Math.abs(m.verticalDelta) > 0.55D || m.playerSpeed < 0.04D)
            addModeCandidates(candidates, m, MODE_ELEVATE, horizon);
        if (m.selfEdge.distance < 1.4D || m.nearVoidEnemy)
            addModeCandidates(candidates, m, MODE_BRIDGE, horizon);

        // Always keep a defensive candidate pool active; the AI is not forced
        // to wait for a special state before protecting its own hitbox.
        addModeCandidates(candidates, m, MODE_COVER, horizon);
        addModeCandidates(candidates, m, MODE_SIDEWALL, horizon);
        if (m.inMelee) addModeCandidates(candidates, m, MODE_STOP, horizon);
        if (allowHighPlace.isToggled() && m.yDeltaToCeiling > 1)
            addModeCandidates(candidates, m, MODE_ELEVATE, horizon);

        if (candidates.isEmpty()) return null;

        // Deduplicate exact cells while retaining the best tactical role.
        List<ActionPlan> compact = new ArrayList<>();
        for (ActionPlan c : candidates) {
            ActionPlan prior = null;
            for (ActionPlan q : compact) {
                if (q.block.equals(c.block)) { prior = q; break; }
            }
            if (prior == null || c.score < prior.score) {
                if (prior != null) compact.remove(prior);
                compact.add(c);
            }
        }

        for (ActionPlan c : compact) {
            c.score += dynamicScore(c, m);
            c.score += threatScore(c, m);
            c.score += patternTransitionPenalty(c, m);
            c.score += futureBeamPenalty(c, m, horizon);
        }

        Collections.sort(compact, Comparator.comparingDouble(a -> a.score));
        ActionPlan best = compact.get(0);

        // Hysteresis stops the planner from jittering between equally good cells
        // while still allowing a new threat to immediately override the old plan.
        if (lastPlan != null && stillValid(lastPlan) && sceneCompatible(lastPlan, m)) {
            double override = m.playerFalling || m.veryClose ? 0.15D : 1.35D;
            if (lastPlan.score <= best.score + override)
                best = copy(lastPlan, lastPlan.score - 0.22D);
        }
        lastMode = best.mode;
        if (m.lateralDirection != 0) lastLateralSign = m.lateralDirection;
        return best;
    }

    /**
     * Penalize a placement if it leaves the player's body exposed to the
     * opponent's predicted attack ray, or if it creates a pocket with too few
     * exits. This is intentionally self-defense weighted.
     */
    private double threatScore(ActionPlan p, WorldModel m) {
        if (p == null || p.type != ACT_PLACE) return 0.0D;
        Vec3 selfPoint = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight() * 0.68D, mc.thePlayer.posZ);
        Vec3 enemyPoint = new Vec3(m.enemyFuture.xCoord, m.enemyFuture.yCoord + target.getEyeHeight() * 0.62D, m.enemyFuture.zCoord);
        double direct = blocksRay(p.block, enemyPoint, selfPoint) ? -3.4D : 2.2D;

        // Prefer cover that is slightly off-axis: it blocks the immediate hit
        // while preserving at least one direction for the next strafe.
        double dx = p.block.getX() + 0.5D - mc.thePlayer.posX;
        double dz = p.block.getZ() + 0.5D - mc.thePlayer.posZ;
        double len = Math.max(0.01D, Math.sqrt(dx * dx + dz * dz));
        double flank = Math.abs(dx * (target.posZ - mc.thePlayer.posZ) - dz * (target.posX - mc.thePlayer.posX)) / len;
        direct -= Math.min(1.4D, flank * 0.18D) * defenseBias.getInput();

        int selfExits = simulatedEscapeCount(p.block, mc.thePlayer);
        if (selfExits == 0) direct += 5.0D * escapeBias.getInput();
        else if (selfExits == 1) direct += 1.6D * escapeBias.getInput();

        // Don't build directly in the center of the player's projected strafe
        // lane unless the placement is an emergency recovery.
        if (p.mode != MODE_RECOVER) {
            double front = forwardProjection(p.block, mc.thePlayer.motionX, mc.thePlayer.motionZ);
            if (Math.abs(front) < 0.55D) direct += 0.9D;
        }
        return direct;
    }

    private double futureBeamPenalty(ActionPlan p, WorldModel m, int horizon) {
        if (p == null) return 0.0D;
        // Cheap two-step lookahead. We do not clone the whole world; instead we
        // score how the first block changes future escape/cover opportunities.
        double value = 0.0D;
        Vec3 f = predictTargetAtTicks(Math.min(lookAheadTicks.getInput(), 7.0D));
        int eBefore = escapeCount(target);
        int eAfter = simulatedEscapeCount(p.block, target);
        value += (eAfter - eBefore) * 0.85D;
        double futureDist = horizontalDistance(f.xCoord, f.zCoord, p.block.getX() + 0.5D, p.block.getZ() + 0.5D);
        value += Math.max(0.0D, futureDist - 3.0D) * 0.18D;
        if (horizon >= 3 && p.mode == MODE_SIDEWALL) {
            // Alternating wall sides is favored because it changes the enemy's
            // preferred approach instead of presenting the same strafe pocket.
            if (lastLateralSign != 0 && m.lateralDirection != 0 && lastLateralSign != m.lateralDirection)
                value -= 0.65D;
        }
        return value;
    }

    private Vec3 predictTargetAtTicks(double t) {
        double vx = target.motionX, vz = target.motionZ;
        if (targetHistory.size() >= 3) {
            Snapshot a = targetHistory.peekFirst(), b = targetHistory.peekLast();
            double dt = Math.max(1.0D, targetHistory.size() - 1);
            vx = (b.x - a.x) / dt;
            vz = (b.z - a.z) / dt;
        }
        double px = target.posX + vx * t;
        double pz = target.posZ + vz * t;
        double py = target.posY + MathHelper.clamp_double((target.posY - target.prevPosY) * t, -1.5D, 1.5D);
        return new Vec3(px, py, pz);
    }

    private double patternTransitionPenalty(ActionPlan p, WorldModel m) {
        if (p == null) return 0.0D;
        double penalty = 0.0D;
        if (lastMode == p.mode) penalty += 0.28D * patternDrift.getInput();
        if (nearRecent(p.block)) penalty += 2.4D * uniqueness.getInput();
        long h = 17L * p.block.getX() + 31L * p.block.getY() + 47L * p.block.getZ() + uniqueSeed + patternPhase * 101L;
        double noise = ((h ^ (h >>> 17)) & 0xFFFF) / 65535.0D;
        penalty += (noise - 0.5D) * patternDrift.getInput();
        return penalty;
    }

    private double forwardProjection(BlockPos p, double vx, double vz) {
        double len = Math.sqrt(vx * vx + vz * vz);
        if (len < 0.01D) return 0.0D;
        double dx = p.getX() + 0.5D - mc.thePlayer.posX;
        double dz = p.getZ() + 0.5D - mc.thePlayer.posZ;
        return (dx * vx + dz * vz) / len;
    }

    private void addModeCandidates(List<ActionPlan> out, WorldModel m, int mode, int horizon) {
        Vec3 future = m.enemyFuture;
        BlockPos eBase = new BlockPos(MathHelper.floor_double(future.xCoord),
                MathHelper.floor_double(future.yCoord), MathHelper.floor_double(future.zCoord));
        BlockPos sBase = new BlockPos(MathHelper.floor_double(mc.thePlayer.posX),
                MathHelper.floor_double(mc.thePlayer.posY), MathHelper.floor_double(mc.thePlayer.posZ));

        int fx = sign(m.targetDirection.xCoord);
        int fz = sign(m.targetDirection.zCoord);
        int lx = -fz;
        int lz = fx;
        if (fx == 0 && fz == 0) {
            float yaw = mc.thePlayer.rotationYaw;
            fx = sign(-Math.sin(Math.toRadians(yaw)));
            fz = sign(Math.cos(Math.toRadians(yaw)));
            lx = -fz;
            lz = fx;
        }

        List<BlockPos> cells = new ArrayList<>();
        addCell(cells, eBase);
        addCell(cells, eBase.add(0, 1, 0));

        switch (mode) {
            case MODE_COVER:
                addCell(cells, eBase.add(lx, 0, lz));
                addCell(cells, eBase.add(-lx, 0, -lz));
                addCell(cells, eBase.add(lx, 1, lz));
                addCell(cells, eBase.add(-lx, 1, -lz));
                addCell(cells, eBase.add(0, 1, 0));
                break;
            case MODE_SIDEWALL:
                addCell(cells, eBase.add(lx, 0, lz));
                addCell(cells, eBase.add(lx, 1, lz));
                addCell(cells, eBase.add(-lx, 0, -lz));
                addCell(cells, eBase.add(-lx, 1, -lz));
                addCell(cells, eBase.add(fx, 0, fz));
                break;
            case MODE_STOP:
                addCell(cells, eBase.add(fx, 0, fz));
                addCell(cells, eBase.add(fx, 1, fz));
                addCell(cells, eBase.add(2 * fx, 0, 2 * fz));
                addCell(cells, eBase.add(lx, 0, lz));
                addCell(cells, eBase.add(-lx, 0, -lz));
                break;
            case MODE_TRAP:
                addCell(cells, eBase.add(lx, 0, lz));
                addCell(cells, eBase.add(-lx, 0, -lz));
                addCell(cells, eBase.add(fx, 0, fz));
                addCell(cells, eBase.add(-fx, 0, -fz));
                addCell(cells, eBase.add(lx, 1, lz));
                addCell(cells, eBase.add(-lx, 1, -lz));
                addCell(cells, eBase.add(0, 2, 0));
                break;
            case MODE_ELEVATE:
                addCell(cells, sBase.add(0, 1, 0));
                addCell(cells, sBase.add(lx, 1, lz));
                addCell(cells, sBase.add(-lx, 1, -lz));
                addCell(cells, eBase.add(0, 1, 0));
                break;
            case MODE_BRIDGE:
                addCell(cells, sBase.add(fx, -1, fz));
                addCell(cells, sBase.add(fx, 0, fz));
                addCell(cells, sBase.add(2 * fx, -1, 2 * fz));
                addCell(cells, sBase.add(lx, -1, lz));
                addCell(cells, sBase.add(-lx, -1, -lz));
                break;
            case MODE_RECOVER:
                addCell(cells, sBase.add(0, -1, 0));
                addCell(cells, sBase.add(fx, -1, fz));
                addCell(cells, sBase.add(lx, -1, lz));
                addCell(cells, sBase.add(-lx, -1, -lz));
                addCell(cells, sBase.add(fx, 0, fz));
                break;
        }

        // A small local lattice makes the planner responsive to arbitrary
        // BedWars islands instead of assuming one map layout.
        int radius = Math.min(3, (int) Math.ceil(scanRadius.getInput() / 2.0D));
        if (mode == MODE_COVER || mode == MODE_SIDEWALL || mode == MODE_STOP || mode == MODE_TRAP) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.abs(dx) + Math.abs(dz) > radius + 1) continue;
                    addCell(cells, eBase.add(dx, 0, dz));
                    if (horizon >= 3) addCell(cells, eBase.add(dx, 1, dz));
                }
            }
            // Defensive ring around the player: this is the source of the
            // varied "micro-wall / shoulder / corner" patterns seen in fights.
            int sr = Math.min(2, radius);
            for (int dx = -sr; dx <= sr; dx++) {
                for (int dz = -sr; dz <= sr; dz++) {
                    if (Math.abs(dx) + Math.abs(dz) > sr + 1) continue;
                    addCell(cells, sBase.add(dx, 0, dz));
                    if (patternPhase % 3 == 0) addCell(cells, sBase.add(dx, 1, dz));
                }
            }
        }

        for (BlockPos cell : cells) {
            ActionPlan p = makePlaceCandidate(cell, mode, m);
            if (p != null)
                out.add(p);
        }
    }

    private ActionPlan makePlaceCandidate(BlockPos pos, int mode, WorldModel m) {
        if (pos.getY() <= 0 || pos.getY() >= 255 || pos.getY() > m.heightCeiling)
            return null;
        if (pos.getY() > m.localTopSelf + 6 && !allowHighPlace.isToggled())
            return null;
        if (!isReplaceable(pos))
            return null;
        if (intersectsEntity(pos, mc.thePlayer, 0.08D))
            return null;
        if (mode != MODE_BRIDGE && mode != MODE_RECOVER && intersectsEntity(pos, target, 0.02D))
            return null;

        BlockPos support = bestSupport(pos, m);
        if (support == null)
            return null;
        EnumFacing face = facingFromSupport(support, pos);
        Vec3 hit = hitVector(support, face, pos);
        if (!withinReach(hit, 4.5D))
            return null;
        float[] r = rotationsTo(hit);
        double yawDelta = Math.abs(MathHelper.wrapAngleTo180_float(r[0] - mc.thePlayer.rotationYaw));
        if (yawDelta > 125.0D)
            return null;

        double path = distanceToPredicted(m.enemyFuture, pos);
        double self = horizontalDistance(mc.thePlayer.posX, mc.thePlayer.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D);
        double enemy = horizontalDistance(target.posX, target.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D);
        double escapeGain = escapeGain(pos, target);
        double selfSafety = selfSafetyGain(pos);
        double score = 0.0D;
        score += path * 2.45D;
        score += self * 0.30D;
        score += enemy * 0.18D;
        score += yawDelta * 0.022D;
        score -= escapeGain * 2.35D;
        score -= selfSafety * 1.8D;
        // Strong preference for reducing the opponent's clean line to our body.
        Vec3 selfBody = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight() * 0.68D, mc.thePlayer.posZ);
        Vec3 enemyFutureEye = new Vec3(m.enemyFuture.xCoord, m.enemyFuture.yCoord + target.getEyeHeight() * 0.62D, m.enemyFuture.zCoord);
        if (blocksRay(pos, enemyFutureEye, selfBody)) score -= 3.1D;
        else if (mode == MODE_COVER || mode == MODE_SIDEWALL) score += 1.15D * defenseBias.getInput();
        int selfExits = simulatedEscapeCount(pos, mc.thePlayer);
        if (selfExits <= 1 && mode != MODE_RECOVER) score += 1.8D * escapeBias.getInput();

        switch (mode) {
            case MODE_COVER: score -= coverValue(pos, m) * 2.0D; break;
            case MODE_SIDEWALL: score -= sideWallValue(pos, m) * 2.6D; break;
            case MODE_STOP: score -= stopValue(pos, m) * 3.0D; break;
            case MODE_TRAP: score -= trapValue(pos, m) * 4.0D; break;
            case MODE_ELEVATE: score -= elevationValue(pos, m) * 2.2D; break;
            case MODE_BRIDGE: score -= bridgeValue(pos, m) * 3.1D; break;
            case MODE_RECOVER: score -= recoverValue(pos, m) * 6.0D; break;
        }

        if (nearRecent(pos))
            score += 3.0D * uniqueness.getInput();
        score += patternBias(pos, mode, m);

        double urgency = modeUrgency(mode, m);
        return new ActionPlan(ACT_PLACE, pos, support, face, hit, r[0], r[1], score, urgency, mode);
    }

    private double dynamicScore(ActionPlan p, WorldModel m) {
        double s = 0.0D;
        if (m.playerFalling && p.mode != MODE_RECOVER) s += 8.0D;
        if (m.attackBlocked && p.mode == MODE_OPEN) s -= 8.0D;
        if (m.inMelee && (p.mode == MODE_STOP || p.mode == MODE_SIDEWALL)) s -= 1.8D;
        if (m.veryClose && p.mode == MODE_COVER) s -= 1.0D;
        if (m.enemyConfined && p.mode == MODE_TRAP) s -= 2.6D * trapBias.getInput();
        if (m.enemyEdge.distance < 1.1D && p.mode == MODE_STOP) s -= 1.5D * edgeBias.getInput();
        if (m.verticalDelta > 0.6D && p.mode == MODE_ELEVATE) s -= 1.0D;
        if (m.nearVoidEnemy && p.mode == MODE_BRIDGE) s -= 1.4D;
        if (m.behavior == BEHAVIOR_RUSH && p.mode == MODE_STOP) s -= 1.4D;
        if (m.behavior == BEHAVIOR_RUSH && p.mode == MODE_SIDEWALL) s -= 0.8D;
        if (m.behavior == BEHAVIOR_RETREAT && p.mode == MODE_COVER) s -= 0.6D;
        if (m.behavior == BEHAVIOR_STRAFE_LEFT || m.behavior == BEHAVIOR_STRAFE_RIGHT) {
            if (p.mode == MODE_SIDEWALL) s -= 1.2D;
            if (p.mode == MODE_STOP) s -= 0.5D;
        }
        if (m.behavior == BEHAVIOR_AIRBORNE && p.mode == MODE_ELEVATE) s -= 1.0D;
        if (m.selfConfined && p.mode == MODE_COVER) s += 2.2D * escapeBias.getInput();
        if (m.safeEscapeCount <= 1 && p.mode != MODE_RECOVER) s += 1.7D * escapeBias.getInput();
        if (m.behavior == BEHAVIOR_RETREAT && p.mode == MODE_SIDEWALL) s -= 0.7D;
        if (m.enemyEscapeCount <= 1 && p.mode == MODE_TRAP) s -= 1.3D * trapBias.getInput();
        return s;
    }

    private ActionPlan makeBreakPlan() {
        if (target == null || findShearsSlot() < 0)
            return null;
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        Vec3 targetPoint = new Vec3(target.posX, target.posY + target.getEyeHeight() * 0.55D, target.posZ);
        MovingObjectPosition hit = mc.theWorld.rayTraceBlocks(eye, targetPoint, false, false, true);
        if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK)
            return null;
        BlockPos pos = hit.getBlockPos();
        if (!isShearsBreakable(pos))
            return null;
        Vec3 center = new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
        float[] r = rotationsTo(center);
        double d = mc.thePlayer.getDistanceToEntity(target);
        double urgency = 8.0D - Math.min(3.0D, d * 0.35D);
        return new ActionPlan(ACT_BREAK, pos, null, hit.sideHit, center, r[0], r[1], -4.0D + d * 0.25D,
                urgency, MODE_OPEN);
    }

    private boolean executePlace(ActionPlan p) {
        int slot = findBlockSlot();
        if (slot < 0) return false;
        if (!switchTo(slot)) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock) || held.stackSize <= 0)
            return false;
        if (!isReplaceable(p.block)) return false;
        if (p.support == null) return false;
        Block support = mc.theWorld.getBlockState(p.support).getBlock();
        if (!(support.isNormalCube() || support.isFullBlock())) return false;
        if (!withinReach(p.hit, 4.5D)) return false;
        if (intersectsEntity(p.block, mc.thePlayer, 0.08D)) return false;

        boolean ok = mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, held,
                p.support, p.face, p.hit);
        if (ok) mc.thePlayer.swingItem();
        return ok;
    }

    private boolean executeBreak(ActionPlan p) {
        int slot = findShearsSlot();
        if (slot < 0 || !switchTo(slot)) return false;
        if (!isShearsBreakable(p.block)) return false;
        return mc.playerController.onPlayerDamageBlock(p.block, p.face);
    }

    private int findBlockSlot() {
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held != null && held.stackSize > 0 && held.getItem() instanceof ItemBlock && InventoryUtils.isGoodBlockStack(held))
            return mc.thePlayer.inventory.currentItem;
        if (!autoSelect.isToggled()) return -1;
        int best = -1;
        int bestCount = -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack s = mc.thePlayer.inventory.getStackInSlot(slot);
            if (s != null && s.stackSize > 0 && s.getItem() instanceof ItemBlock && InventoryUtils.isGoodBlockStack(s)) {
                if (s.stackSize > bestCount) {
                    best = slot;
                    bestCount = s.stackSize;
                }
            }
        }
        return best;
    }

    private int blockCount() {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.thePlayer.inventory.getStackInSlot(i);
            if (s != null && s.stackSize > 0 && s.getItem() instanceof ItemBlock) count += s.stackSize;
        }
        return count;
    }

    private int findShearsSlot() {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack s = mc.thePlayer.inventory.getStackInSlot(slot);
            if (s != null && s.stackSize > 0 && s.getItem() instanceof ItemShears)
                return slot;
        }
        return -1;
    }

    private boolean isShearsBreakable(BlockPos pos) {
        int slot = findShearsSlot();
        if (slot < 0 || pos == null) return false;
        ItemStack s = mc.thePlayer.inventory.getStackInSlot(slot);
        Block b = mc.theWorld.getBlockState(pos).getBlock();
        if (s == null || b == Blocks.air || b instanceof BlockLiquid) return false;
        if (b.getBlockHardness(mc.theWorld, pos) < 0.0F) return false;
        return s.getItem().getDigSpeed(s, mc.theWorld.getBlockState(pos)) >= 1.0F;
    }

    private boolean switchTo(int slot) {
        if (slot < 0 || slot > 8) return false;
        if (!slotOwned) {
            savedSlot = mc.thePlayer.inventory.currentItem;
            slotOwned = true;
        }
        if (mc.thePlayer.inventory.currentItem != slot) {
            mc.thePlayer.inventory.currentItem = slot;
            if (mc.getNetHandler() != null)
                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(slot));
        }
        return true;
    }

    private void restoreSlot() {
        if (!slotOwned || mc.thePlayer == null) return;
        if (savedSlot >= 0 && savedSlot <= 8) {
            mc.thePlayer.inventory.currentItem = savedSlot;
            if (mc.getNetHandler() != null)
                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(savedSlot));
        }
        slotOwned = false;
        savedSlot = -1;
    }

    private BlockPos bestSupport(BlockPos pos, WorldModel m) {
        EnumFacing[] order = {EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST, EnumFacing.UP};
        BlockPos best = null;
        double bestScore = Double.POSITIVE_INFINITY;
        for (EnumFacing face : order) {
            BlockPos support = pos.offset(face);
            if (support.getY() < 0 || support.getY() > 254) continue;
            Block b = mc.theWorld.getBlockState(support).getBlock();
            if (!(b.isNormalCube() || b.isFullBlock())) continue;
            if (intersectsEntity(support, mc.thePlayer, 0.0D) || intersectsEntity(support, target, 0.0D)) continue;
            Vec3 hit = hitVector(support, face, pos);
            if (!withinReach(hit, 4.5D)) continue;
            float[] rr = rotationsTo(hit);
            double yaw = Math.abs(MathHelper.wrapAngleTo180_float(rr[0] - mc.thePlayer.rotationYaw));
            double vertical = Math.abs(rr[1] - mc.thePlayer.rotationPitch);
            double s = yaw * 0.02D + vertical * 0.01D;
            if (face == EnumFacing.DOWN) s -= 0.25D;
            if (face == EnumFacing.UP) s += 0.10D;
            if (s < bestScore) { bestScore = s; best = support; }
        }
        return best;
    }

    private Vec3 hitVector(BlockPos support, EnumFacing face, BlockPos placed) {
        double x = support.getX() + 0.5D;
        double y = support.getY() + 0.5D;
        double z = support.getZ() + 0.5D;
        double edge = 0.37D;
        // Slightly offset the hit point toward the resulting block. This keeps
        // the ray target centered on the exact face while avoiding identical
        // pixel-perfect clicks on every placement.
        double tx = placed.getX() + 0.5D;
        double ty = placed.getY() + 0.5D;
        double tz = placed.getZ() + 0.5D;
        x += MathHelper.clamp_double(tx - x, -edge, edge);
        y += MathHelper.clamp_double(ty - y, -edge, edge);
        z += MathHelper.clamp_double(tz - z, -edge, edge);
        x += face.getFrontOffsetX() * 0.08D;
        y += face.getFrontOffsetY() * 0.08D;
        z += face.getFrontOffsetZ() * 0.08D;
        return new Vec3(x, y, z);
    }

    private EnumFacing facingFromSupport(BlockPos support, BlockPos placed) {
        int dx = placed.getX() - support.getX();
        int dy = placed.getY() - support.getY();
        int dz = placed.getZ() - support.getZ();
        if (Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz)) return dx >= 0 ? EnumFacing.EAST : EnumFacing.WEST;
        if (Math.abs(dz) >= Math.abs(dy)) return dz >= 0 ? EnumFacing.SOUTH : EnumFacing.NORTH;
        return dy >= 0 ? EnumFacing.UP : EnumFacing.DOWN;
    }

    private float[] rotationsTo(Vec3 p) {
        double dx = p.xCoord - mc.thePlayer.posX;
        double dy = p.yCoord - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = p.zCoord - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.clamp_float(pitch, -90.0F, 90.0F)};
    }

    private Vec3 predictTarget(WorldModel m) {
        double t = predictionTicks.getInput();
        Snapshot latest = targetHistory.peekLast();
        Snapshot oldest = targetHistory.peekFirst();
        double vx = target.motionX;
        double vz = target.motionZ;
        if (latest != null && oldest != null && targetHistory.size() >= 3) {
            double dt = Math.max(1.0D, targetTicks - Math.max(0, targetTicks - targetHistory.size()));
            vx = (latest.x - oldest.x) / dt;
            vz = (latest.z - oldest.z) / dt;
        }
        double ax = MathHelper.clamp_double(target.motionX - vx, -0.08D, 0.08D);
        double az = MathHelper.clamp_double(target.motionZ - vz, -0.08D, 0.08D);
        double px = target.posX + vx * t + 0.5D * ax * t * t;
        double pz = target.posZ + vz * t + 0.5D * az * t * t;
        double vy = target.posY - target.prevPosY;
        double py = target.posY + MathHelper.clamp_double(vy * t, -1.4D, 1.4D);
        return new Vec3(px, py, pz);
    }

    private Vec3 targetDirection() {
        double vx = target.motionX;
        double vz = target.motionZ;
        if (targetHistory.size() >= 2) {
            Snapshot a = targetHistory.peekFirst();
            Snapshot b = targetHistory.peekLast();
            vx = b.x - a.x;
            vz = b.z - a.z;
        }
        return new Vec3(vx, 0.0D, vz);
    }

    private int lateralDirection(Vec3 dir) {
        if (Math.abs(dir.xCoord) + Math.abs(dir.zCoord) < 0.02D) return 0;
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        double cross = dx * dir.zCoord - dz * dir.xCoord;
        return cross > 0.0D ? 1 : -1;
    }

    private double closingSpeed(EntityPlayer p) {
        double dx = p.posX - mc.thePlayer.posX;
        double dz = p.posZ - mc.thePlayer.posZ;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 1.0E-5D) return 0.0D;
        double nx = dx / d;
        double nz = dz / d;
        double rvx = p.motionX - mc.thePlayer.motionX;
        double rvz = p.motionZ - mc.thePlayer.motionZ;
        return -(rvx * nx + rvz * nz);
    }

    private double lateralSpeed(EntityPlayer p) {
        double dx = p.posX - mc.thePlayer.posX;
        double dz = p.posZ - mc.thePlayer.posZ;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 1.0E-5D) return 0.0D;
        double nx = dx / d;
        double nz = dz / d;
        double rvx = p.motionX - mc.thePlayer.motionX;
        double rvz = p.motionZ - mc.thePlayer.motionZ;
        double along = rvx * nx + rvz * nz;
        double sq = rvx * rvx + rvz * rvz;
        return Math.sqrt(Math.max(0.0D, sq - along * along));
    }

    private double horizontalSpeed(double x, double z) { return Math.sqrt(x * x + z * z); }

    private EdgeInfo edgeInfo(EntityPlayer p) {
        EdgeInfo e = new EdgeInfo();
        double best = 99.0D;
        int bestDx = 0, bestDz = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                double dist = dx * dx + dz * dz == 2 ? 1.414D : 1.0D;
                if (!groundAt(p, dx, dz)) {
                    if (dist < best) { best = dist; bestDx = dx; bestDz = dz; }
                }
            }
        }
        e.distance = best;
        e.dx = bestDx;
        e.dz = bestDz;
        return e;
    }

    private boolean groundAt(EntityPlayer p, int dx, int dz) {
        int x = MathHelper.floor_double(p.posX + dx);
        int y = MathHelper.floor_double(p.posY) - 1;
        int z = MathHelper.floor_double(p.posZ + dz);
        for (int dy = 0; dy >= -3; dy--) {
            Block b = mc.theWorld.getBlockState(new BlockPos(x, y + dy, z)).getBlock();
            if (b != Blocks.air && !(b instanceof BlockLiquid) && b.getMaterial().blocksMovement()) return true;
        }
        return false;
    }

    private boolean nearVoid(EntityPlayer p, int radius) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) continue;
                if (!groundAt(p, dx, dz)) return true;
            }
        }
        return false;
    }

    private int highestSolidNear(EntityPlayer p, int radius) {
        int max = MathHelper.floor_double(p.posY);
        int bx = MathHelper.floor_double(p.posX);
        int bz = MathHelper.floor_double(p.posZ);
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int y = max + 4; y >= Math.max(0, max - 3); y--) {
                    Block b = mc.theWorld.getBlockState(new BlockPos(bx + dx, y, bz + dz)).getBlock();
                    if (b != Blocks.air && !(b instanceof BlockLiquid) && b.getMaterial().blocksMovement()) {
                        if (y > max) max = y;
                        break;
                    }
                }
            }
        }
        return max;
    }

    private boolean confined(EntityPlayer p) {
        int clear = 0;
        int bx = MathHelper.floor_double(p.posX);
        int by = MathHelper.floor_double(p.posY);
        int bz = MathHelper.floor_double(p.posZ);
        for (EnumFacing f : new EnumFacing[]{EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.EAST, EnumFacing.WEST}) {
            Block b = mc.theWorld.getBlockState(new BlockPos(bx + f.getFrontOffsetX(), by, bz + f.getFrontOffsetZ())).getBlock();
            if (b == Blocks.air || b.isReplaceable(mc.theWorld, new BlockPos(bx + f.getFrontOffsetX(), by, bz + f.getFrontOffsetZ()))) clear++;
        }
        Block above = mc.theWorld.getBlockState(new BlockPos(bx, by + 2, bz)).getBlock();
        return clear <= 1 || (above != Blocks.air && above.isNormalCube());
    }

    private int escapeCount(EntityPlayer p) {
        int count = 0;
        int bx = MathHelper.floor_double(p.posX);
        int by = MathHelper.floor_double(p.posY);
        int bz = MathHelper.floor_double(p.posZ);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos foot = new BlockPos(bx + dx, by - 1, bz + dz);
                BlockPos body = new BlockPos(bx + dx, by, bz + dz);
                Block a = mc.theWorld.getBlockState(foot).getBlock();
                Block b = mc.theWorld.getBlockState(body).getBlock();
                if (a != Blocks.air && a.getMaterial().blocksMovement() && b.isReplaceable(mc.theWorld, body)) count++;
            }
        }
        return count;
    }

    private boolean supportBelow(Vec3 p) {
        int x = MathHelper.floor_double(p.xCoord);
        int y = MathHelper.floor_double(p.yCoord) - 1;
        int z = MathHelper.floor_double(p.zCoord);
        for (int dy = 0; dy >= -3; dy--) {
            Block b = mc.theWorld.getBlockState(new BlockPos(x, y + dy, z)).getBlock();
            if (b != Blocks.air && !(b instanceof BlockLiquid) && b.getMaterial().blocksMovement()) return true;
        }
        return false;
    }

    private boolean isAttackBlocked() {
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        Vec3 targetVec = new Vec3(target.posX, target.posY + target.getEyeHeight() * 0.55D, target.posZ);
        MovingObjectPosition hit = mc.theWorld.rayTraceBlocks(eye, targetVec, false, false, true);
        return hit != null && hit.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK;
    }

    private boolean isReplaceable(BlockPos pos) { return mc.theWorld.getBlockState(pos).getBlock().isReplaceable(mc.theWorld, pos); }

    private boolean intersectsEntity(BlockPos pos, EntityPlayer p, double expand) {
        AxisAlignedBB bb = new AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0D, pos.getY() + 1.0D, pos.getZ() + 1.0D);
        if (expand > 0) bb = bb.expand(expand, 0.0D, expand);
        return p != null && bb.intersectsWith(p.getEntityBoundingBox());
    }

    private boolean withinReach(Vec3 v, double r) {
        Vec3 e = mc.thePlayer.getPositionEyes(1.0F);
        double dx = v.xCoord - e.xCoord, dy = v.yCoord - e.yCoord, dz = v.zCoord - e.zCoord;
        return dx * dx + dy * dy + dz * dz <= r * r;
    }

    private double distanceToPredicted(Vec3 p, BlockPos b) { return horizontalDistance(p.xCoord, p.zCoord, b.getX() + 0.5D, b.getZ() + 0.5D); }
    private double horizontalDistance(double x1, double z1, double x2, double z2) { double dx = x1 - x2, dz = z1 - z2; return Math.sqrt(dx * dx + dz * dz); }
    private int sign(double v) { return v > 0.15D ? 1 : v < -0.15D ? -1 : 0; }

    private double coverValue(BlockPos pos, WorldModel m) {
        double val = 0;
        if (blocksRay(pos, mc.thePlayer.getPositionEyes(1.0F), new Vec3(target.posX, target.posY + target.getEyeHeight() * 0.55D, target.posZ))) val += 2.5D;
        double side = Math.max(0.0D, 1.5D - horizontalDistance(target.posX, target.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D));
        return val + side * 1.5D;
    }

    private double sideWallValue(BlockPos pos, WorldModel m) {
        int lx = m.lateralDirection == 0 ? 1 : m.lateralDirection;
        Vec3 rel = new Vec3(target.posX - mc.thePlayer.posX, 0, target.posZ - mc.thePlayer.posZ);
        double len = Math.max(0.01D, Math.sqrt(rel.xCoord * rel.xCoord + rel.zCoord * rel.zCoord));
        double nx = -rel.zCoord / len * lx, nz = rel.xCoord / len * lx;
        double px = pos.getX() + 0.5D - target.posX, pz = pos.getZ() + 0.5D - target.posZ;
        return Math.max(0.0D, (px * nx + pz * nz) * 1.8D);
    }

    private double stopValue(BlockPos pos, WorldModel m) {
        Vec3 d = m.targetDirection;
        double len = Math.max(0.01D, Math.sqrt(d.xCoord * d.xCoord + d.zCoord * d.zCoord));
        double ux = d.xCoord / len, uz = d.zCoord / len;
        double px = pos.getX() + 0.5D - target.posX, pz = pos.getZ() + 0.5D - target.posZ;
        double forward = px * ux + pz * uz;
        return Math.max(0.0D, 2.2D - Math.abs(forward) * 1.3D);
    }

    private double trapValue(BlockPos pos, WorldModel m) {
        double centerDist = horizontalDistance(target.posX, target.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D);
        double exits = simulatedEscapeCount(pos, target);
        return Math.max(0.0D, 3.0D - centerDist) + Math.max(0.0D, 3.0D - exits);
    }

    private double elevationValue(BlockPos pos, WorldModel m) {
        double desired = Math.floor(mc.thePlayer.posY) + (m.verticalDelta < -0.5D ? 1.0D : 0.0D);
        return Math.max(0.0D, 2.0D - Math.abs(pos.getY() - desired));
    }

    private double bridgeValue(BlockPos pos, WorldModel m) {
        if (!m.nearVoidEnemy && m.selfEdge.distance > 4.0D) return 0;
        double d = horizontalDistance(pos.getX() + 0.5D, pos.getZ() + 0.5D, mc.thePlayer.posX, mc.thePlayer.posZ);
        return Math.max(0.0D, 2.8D - d);
    }

    private double recoverValue(BlockPos pos, WorldModel m) {
        double d = horizontalDistance(pos.getX() + 0.5D, pos.getZ() + 0.5D, mc.thePlayer.posX, mc.thePlayer.posZ);
        double below = Math.abs(pos.getY() - (Math.floor(mc.thePlayer.posY) - 1.0D));
        return Math.max(0.0D, 4.0D - d * 2.0D - below);
    }

    private double escapeGain(BlockPos pos, EntityPlayer p) {
        int before = escapeCount(p);
        int after = simulatedEscapeCount(pos, p);
        return before - after;
    }

    private double selfSafetyGain(BlockPos pos) {
        if (nearVoid(mc.thePlayer, 1) && pos.getY() <= Math.floor(mc.thePlayer.posY) - 1) return 3.0D;
        double d = horizontalDistance(pos.getX() + 0.5D, pos.getZ() + 0.5D, mc.thePlayer.posX, mc.thePlayer.posZ);
        return d < 1.6D ? 1.5D : 0.0D;
    }

    private int simulatedEscapeCount(BlockPos place, EntityPlayer p) {
        int count = 0;
        int bx = MathHelper.floor_double(p.posX);
        int by = MathHelper.floor_double(p.posY);
        int bz = MathHelper.floor_double(p.posZ);
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            if (dx == 0 && dz == 0) continue;
            BlockPos foot = new BlockPos(bx + dx, by - 1, bz + dz);
            BlockPos body = new BlockPos(bx + dx, by, bz + dz);
            if (foot.equals(place)) continue;
            Block a = mc.theWorld.getBlockState(foot).getBlock();
            Block b = mc.theWorld.getBlockState(body).getBlock();
            if (a != Blocks.air && a.getMaterial().blocksMovement() && b.isReplaceable(mc.theWorld, body)) count++;
        }
        return count;
    }

    private boolean blocksRay(BlockPos pos, Vec3 a, Vec3 b) {
        AxisAlignedBB box = new AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
        return segmentIntersects(a, b, box);
    }

    private boolean segmentIntersects(Vec3 a, Vec3 b, AxisAlignedBB bb) {
        double[] t = {0.0D, 1.0D};
        return clip(a.xCoord, b.xCoord, bb.minX, bb.maxX, t) && clip(a.yCoord, b.yCoord, bb.minY, bb.maxY, t) && clip(a.zCoord, b.zCoord, bb.minZ, bb.maxZ, t);
    }

    private boolean clip(double a, double b, double min, double max, double[] t) {
        double d = b - a;
        if (Math.abs(d) < 1.0E-8D) return a >= min && a <= max;
        double inv = 1.0D / d;
        double t0 = (min - a) * inv;
        double t1 = (max - a) * inv;
        if (t0 > t1) { double z = t0; t0 = t1; t1 = z; }
        if (t0 > t[0]) t[0] = t0;
        if (t1 < t[1]) t[1] = t1;
        return t[1] >= t[0];
    }

    private boolean nearRecent(BlockPos pos) { return recentPlacements.contains(pos); }

    private double patternBias(BlockPos pos, int mode, WorldModel m) {
        long hash = 31L * (pos.getX() * 734287L + pos.getY() * 912271L + pos.getZ() * 438289L) + mode * 999983L + uniqueSeed;
        double n = ((hash ^ (hash >>> 21)) & 0xFFFF) / 65535.0D;
        return (0.5D - n) * uniqueness.getInput() * 0.9D + m.uniqueBias * (mode == MODE_SIDEWALL ? 0.08D : 0.04D);
    }

    private double modeUrgency(int mode, WorldModel m) {
        switch (mode) {
            case MODE_RECOVER: return 10.0D;
            case MODE_STOP: return 8.0D + Math.min(2.0D, m.closing * 4.0D);
            case MODE_TRAP: return 7.0D;
            case MODE_OPEN: return 8.5D;
            case MODE_SIDEWALL: return 6.0D;
            case MODE_BRIDGE: return 8.0D;
            case MODE_ELEVATE: return 5.0D;
            default: return 4.5D;
        }
    }

    private boolean stillValid(ActionPlan p) {
        if (p == null || target == null) return false;
        if (p.type == ACT_PLACE) return isReplaceable(p.block) && p.support != null && isSolid(p.support) && withinReach(p.hit, 4.5D);
        if (p.type == ACT_BREAK) return isShearsBreakable(p.block);
        return false;
    }

    private boolean sceneCompatible(ActionPlan p, WorldModel m) {
        if (p.mode == MODE_RECOVER) return m.playerFalling || m.nearVoidSelf;
        if (p.mode == MODE_TRAP) return m.enemyConfined || m.enemyEdge.distance < 1.3D;
        if (p.mode == MODE_STOP) return m.closing > 0.04D || m.inMelee;
        return true;
    }

    private boolean isSolid(BlockPos p) {
        Block b = mc.theWorld.getBlockState(p).getBlock();
        return b.isNormalCube() || b.isFullBlock();
    }

    private ActionPlan copy(ActionPlan a, double score) {
        return new ActionPlan(a.type, a.block, a.support, a.face, a.hit, a.yaw, a.pitch, score, a.urgency, a.mode);
    }

    private void addCell(List<BlockPos> list, BlockPos p) { if (!list.contains(p)) list.add(p); }

    private static final class Snapshot {
        final double x, y, z, mx, my, mz; final int hurt;
        Snapshot(double x, double y, double z, double mx, double my, double mz, int hurt) { this.x=x;this.y=y;this.z=z;this.mx=mx;this.my=my;this.mz=mz;this.hurt=hurt; }
    }

    private static final class EdgeInfo { double distance=99.0D; int dx,dz; }

    private static final class WorldModel {
        double distance, closing, enemySpeed, playerSpeed, verticalDelta;
        double uniqueBias;
        int behavior;
        int localTopSelf, localTopEnemy, heightCeiling, yDeltaToCeiling;
        int inventoryBlocks, safeEscapeCount, enemyEscapeCount;
        Vec3 targetDirection, enemyFuture;
        EdgeInfo selfEdge, enemyEdge;
        boolean inMelee, veryClose, targetHurt, playerFalling, attackBlocked, enemyConfined, selfConfined;
        boolean hasBlock, hasShears, nearVoidSelf, nearVoidEnemy, aheadSupport;
        int lateralDirection;
    }

    private static final class ActionPlan {
        final int type; final BlockPos block, support; final EnumFacing face; final Vec3 hit;
        final float yaw, pitch; double score; final double urgency; final int mode;
        ActionPlan(int type, BlockPos block, BlockPos support, EnumFacing face, Vec3 hit,
                   float yaw, float pitch, double score, double urgency, int mode) {
            this.type=type;this.block=block;this.support=support;this.face=face;this.hit=hit;
            this.yaw=yaw;this.pitch=pitch;this.score=score;this.urgency=urgency;this.mode=mode;
        }
    }

}
