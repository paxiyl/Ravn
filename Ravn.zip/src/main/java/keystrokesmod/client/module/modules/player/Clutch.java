package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Clutch extends Module {
    public static SliderSetting speed;
    public static SliderSetting snapbackSpeed;
    public static SliderSetting maxDistance;
    public static SliderSetting reach;
    public static SliderSetting aimError;
    public static TickSetting autoClutch;
    public static SliderSetting minFallDistance;

    private float aimYaw, aimPitch;
    private float renderedYaw, renderedPitch;
    private boolean hasAim = false;
    private boolean placing = false;
    private boolean resetting = false;
    private int prevSlot = -1;
    private boolean slotWasSwapped = false;
    private int clutchBlocksPlaced = 0;
    private BlockPos lastPlaced = null;
    private BlockPos targetHitPos = null;
    private EnumFacing targetSide = null;
    private Vec3 targetHitVec = null;
    private boolean autoClutchActive = false;
    private int prevHurtTime = -1;

    private float jitterYaw, jitterPitch;
    private int jitterTimer = 0;
    private boolean hasOvershot = false;
    private float overshootYaw, overshootPitch;
    private int phase = 0;
    private float smoothVelYaw = 0, smoothVelPitch = 0;
    private int aimSettleFrames = 0;

    public Clutch() {
        super("Clutch", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Places blocks under you when falling (human-like)"));
        this.registerSetting(speed = new SliderSetting("Speed", 6.0D, 1.0D, 20.0D, 1.0D));
        this.registerSetting(snapbackSpeed = new SliderSetting("Snapback", 8.0D, 1.0D, 20.0D, 1.0D));
        this.registerSetting(reach = new SliderSetting("Reach", 4.5D, 2.0D, 6.0D, 0.5D));
        this.registerSetting(maxDistance = new SliderSetting("Max blocks", 3.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(aimError = new SliderSetting("Aim error", 4.0D, 0.0D, 12.0D, 0.5D));
        this.registerSetting(autoClutch = new TickSetting("Auto clutch", false));
        this.registerSetting(minFallDistance = new SliderSetting("Min fall distance", 3.0D, 2.0D, 10.0D, 1.0D));
    }

    @Override
    public void onEnable() {
        hasAim = false;
        placing = false;
        resetting = false;
        clutchBlocksPlaced = 0;
        autoClutchActive = false;
        prevHurtTime = -1;
        phase = 0;
        hasOvershot = false;
        smoothVelYaw = 0;
        smoothVelPitch = 0;
        aimSettleFrames = 0;
    }

    @Override
    public void onDisable() {
        restoreAll();
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null) {
            restoreAll();
            return;
        }

        if (mc.thePlayer.onGround) {
            clutchBlocksPlaced = 0;
            lastPlaced = null;
            autoClutchActive = false;
            phase = 0;
        }

        boolean active = isKeyDown() || autoClutchActive;

        if (!active) {
            if (resetting) {
                doSnapback(e);
                return;
            }
            restoreAll();
            return;
        }

        if (autoClutch.isToggled()) {
            updateAutoClutch();
        }

        if (placing || hasAim) {
            doHumanAim(e);
        }

        if (resetting) {
            doSnapback(e);
            return;
        }

        if (!placing && hasAim) {
            placing = true;
            prevSlot = mc.thePlayer.inventory.currentItem;
            phase = 0;
            hasOvershot = false;
            smoothVelYaw = 0;
            smoothVelPitch = 0;
            aimSettleFrames = 0;
        }

        int slot = findBlockSlot();
        if (slot == -1) {
            clearAim(true);
            return;
        }

        mc.thePlayer.inventory.currentItem = slot;
        slotWasSwapped = true;

        AimResult result = findPlacement();
        if (result != null) {
            aimYaw = result.yaw;
            aimPitch = result.pitch;
            hasAim = true;
            targetHitPos = result.pos;
            targetSide = result.face;
            targetHitVec = result.hitVec;

            if (placing && canPlaceAtTarget()) {
                doPlace();
            }
        } else {
            clearAim(true);
        }
    }

    private void doHumanAim(UpdateEvent e) {
        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;

        float targetOffYaw = (float) (aimYaw + (Math.random() - 0.5) * aimError.getInput() * 2.0F);
        float targetOffPitch = (float) (aimPitch + (Math.random() - 0.5) * aimError.getInput() * 2.0F);
        targetOffPitch = clampPitch(targetOffPitch);

        if (phase == 0) {
            float deltaYaw = wrapYawDelta(currentYaw, aimYaw);
            float deltaPitch = aimPitch - currentPitch;
            float totalDist = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);

            if (totalDist > 40.0F) {
                float overshootAmt = 3.0F + (float) Math.random() * 5.0F;
                overshootYaw = aimYaw + deltaYaw / totalDist * overshootAmt;
                overshootPitch = aimPitch + deltaPitch / totalDist * overshootAmt * 0.5F;
                overshootPitch = clampPitch(overshootPitch);
                hasOvershot = true;
                phase = 1;
            } else {
                phase = 2;
            }
        }

        float goalYaw, goalPitch;
        if (phase == 1) {
            goalYaw = overshootYaw;
            goalPitch = overshootPitch;
        } else {
            goalYaw = targetOffYaw;
            goalPitch = targetOffPitch;
        }

        float deltaYaw = wrapYawDelta(currentYaw, goalYaw);
        float deltaPitch = goalPitch - currentPitch;
        float totalDelta = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);

        if (phase == 1 && totalDelta < 5.0F) {
            phase = 2;
            deltaYaw = wrapYawDelta(currentYaw, targetOffYaw);
            deltaPitch = targetOffPitch - currentPitch;
            totalDelta = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
        }

        float baseSpeed = (float) speed.getInput();
        float speedMultiplier;

        if (phase == 1) {
            speedMultiplier = 0.8F + (float) Math.random() * 0.4F;
        } else {
            float closeness = 1.0F - Math.min(totalDelta / 60.0F, 1.0F);
            speedMultiplier = 0.3F + closeness * 0.5F + (float) Math.random() * 0.2F;
        }

        float maxStep = baseSpeed * speedMultiplier;

        jitterTimer++;
        if (jitterTimer >= 3 + (int) (Math.random() * 4)) {
            jitterTimer = 0;
            jitterYaw = (float) ((Math.random() - 0.5) * 1.2F);
            jitterPitch = (float) ((Math.random() - 0.5) * 0.8F);
        }

        float newYaw, newPitch;
        if (totalDelta <= maxStep) {
            newYaw = goalYaw;
            newPitch = goalPitch;
            smoothVelYaw *= 0.5F;
            smoothVelPitch *= 0.5F;
        } else {
            float scale = maxStep / totalDelta;
            smoothVelYaw = smoothVelYaw * 0.6F + deltaYaw * scale * 0.4F;
            smoothVelPitch = smoothVelPitch * 0.6F + deltaPitch * scale * 0.4F;
            newYaw = currentYaw + smoothVelYaw;
            newPitch = currentPitch + smoothVelPitch;
        }

        newYaw += jitterYaw;
        newPitch += jitterPitch;
        newPitch = clampPitch(newPitch);

        renderedYaw = newYaw;
        renderedPitch = newPitch;

        e.setYaw(renderedYaw);
        e.setPitch(renderedPitch);
        mc.thePlayer.rotationYawHead = renderedYaw;
        mc.thePlayer.renderYawOffset = renderedYaw;
    }

    private void doSnapback(UpdateEvent e) {
        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;

        float snapTargetYaw = mc.thePlayer.rotationYaw;
        float snapTargetPitch = mc.thePlayer.rotationPitch;

        float deltaYaw = wrapYawDelta(currentYaw, snapTargetYaw);
        float deltaPitch = snapTargetPitch - currentPitch;
        float totalDelta = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);

        if (totalDelta < 0.5F) {
            resetting = false;
            restoreAll();
            return;
        }

        float baseSpeed = (float) snapbackSpeed.getInput();
        float closeness = 1.0F - Math.min(totalDelta / 60.0F, 1.0F);
        float speedMult = 0.4F + closeness * 0.4F;
        float maxStep = baseSpeed * speedMult;

        jitterTimer++;
        if (jitterTimer >= 3 + (int) (Math.random() * 5)) {
            jitterTimer = 0;
            jitterYaw = (float) ((Math.random() - 0.5) * 0.6F);
            jitterPitch = (float) ((Math.random() - 0.5) * 0.4F);
        }

        float newYaw, newPitch;
        if (totalDelta <= maxStep) {
            newYaw = snapTargetYaw;
            newPitch = snapTargetPitch;
        } else {
            float scale = maxStep / totalDelta;
            smoothVelYaw = smoothVelYaw * 0.5F + deltaYaw * scale * 0.5F;
            smoothVelPitch = smoothVelPitch * 0.5F + deltaPitch * scale * 0.5F;
            newYaw = currentYaw + smoothVelYaw;
            newPitch = currentPitch + smoothVelPitch;
        }

        newYaw += jitterYaw;
        newPitch += jitterPitch;
        newPitch = clampPitch(newPitch);

        e.setYaw(newYaw);
        e.setPitch(newPitch);
        mc.thePlayer.rotationYawHead = newYaw;
        mc.thePlayer.renderYawOffset = newYaw;
    }

    private void updateAutoClutch() {
        int curHurtTime = mc.thePlayer.hurtTime;
        if (curHurtTime > prevHurtTime && !autoClutchActive) {
            if (willFallFar(minFallDistance.getInput())) {
                autoClutchActive = true;
            }
        }
        prevHurtTime = curHurtTime;

        if (autoClutchActive && mc.thePlayer.onGround) {
            autoClutchActive = false;
        }
    }

    private boolean willFallFar(double minFall) {
        double startY = mc.thePlayer.posY;
        double motionY = mc.thePlayer.motionY;
        for (int t = 0; t < 40; t++) {
            motionY -= 0.08D;
            double newY = startY + motionY;
            if (newY < startY - minFall) return true;
            if (mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer,
                    mc.thePlayer.getEntityBoundingBox().offset(0, motionY, 0)).size() > 0) return false;
            startY = newY;
            motionY *= 0.98D;
        }
        return false;
    }

    private boolean isKeyDown() {
        return mc.gameSettings.keyBindUseItem.isKeyDown() || mc.gameSettings.keyBindAttack.isKeyDown();
    }

    private AimResult findPlacement() {
        Vec3 playerPos = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        Vec3 eyePos = mc.thePlayer.getPositionEyes(1.0F);

        int feetX = MathHelper.floor_double(playerPos.xCoord);
        int feetY = MathHelper.floor_double(playerPos.yCoord);
        int feetZ = MathHelper.floor_double(playerPos.zCoord);

        ArrayList<BlockCandidate> candidates = new ArrayList<>();

        for (int y = feetY - 1; y >= feetY - 3; y--) {
            for (int x = feetX - 2; x <= feetX + 1; x++) {
                for (int z = feetZ - 2; z <= feetZ + 1; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!canPlaceThrough(pos)) continue;

                    Block block = mc.theWorld.getBlockState(pos).getBlock();
                    if (block != Blocks.air && !(block instanceof net.minecraft.block.BlockLiquid)) continue;

                    if (!canPlaceThrough(pos.down())) {
                        double dist = mc.thePlayer.getDistance(x + 0.5D, y + 0.5D, z + 0.5D);
                        if (dist <= reach.getInput()) {
                            candidates.add(new BlockCandidate(dist, pos, EnumFacing.UP));
                        }
                    }

                    for (EnumFacing f : EnumFacing.HORIZONTALS) {
                        BlockPos adj = pos.offset(f);
                        if (!canPlaceThrough(adj) && !isReplaceable(adj)) {
                            double dist = mc.thePlayer.getDistance(x + 0.5D, y + 0.5D, z + 0.5D);
                            if (dist <= reach.getInput()) {
                                candidates.add(new BlockCandidate(dist, pos, f.getOpposite()));
                            }
                        }
                    }
                }
            }
        }

        if (candidates.isEmpty()) return null;

        Collections.sort(candidates, Comparator.comparingDouble(c -> c.score));

        ItemStack held = mc.thePlayer.getHeldItem();
        for (BlockCandidate candidate : candidates) {
            AimResult result = getRotationsForBlock(eyePos, candidate.pos, candidate.face, held);
            if (result != null) return result;
        }

        return null;
    }

    private AimResult getRotationsForBlock(Vec3 eyePos, BlockPos targetPos, EnumFacing face, ItemStack held) {
        double inset = 0.05D;
        double targetX, targetY, targetZ;

        switch (face) {
            case UP:
                targetX = targetPos.getX() + 0.5D;
                targetY = targetPos.getY() + 1.0D - inset;
                targetZ = targetPos.getZ() + 0.5D;
                break;
            case DOWN:
                targetX = targetPos.getX() + 0.5D;
                targetY = targetPos.getY() + inset;
                targetZ = targetPos.getZ() + 0.5D;
                break;
            case NORTH:
                targetX = targetPos.getX() + 0.5D;
                targetY = targetPos.getY() + 0.5D;
                targetZ = targetPos.getZ() + inset;
                break;
            case SOUTH:
                targetX = targetPos.getX() + 0.5D;
                targetY = targetPos.getY() + 0.5D;
                targetZ = targetPos.getZ() + 1.0D - inset;
                break;
            case WEST:
                targetX = targetPos.getX() + inset;
                targetY = targetPos.getY() + 0.5D;
                targetZ = targetPos.getZ() + 0.5D;
                break;
            case EAST:
                targetX = targetPos.getX() + 1.0D - inset;
                targetY = targetPos.getY() + 0.5D;
                targetZ = targetPos.getZ() + 0.5D;
                break;
            default:
                return null;
        }

        double dx = targetX - eyePos.xCoord;
        double dy = targetY - eyePos.yCoord;
        double dz = targetZ - eyePos.zCoord;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontalDist)));

        yaw = wrapYaw(yaw);
        pitch = clampPitch(pitch);

        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;
        float deltaYaw = Math.abs(wrapYawDelta(currentYaw, yaw));
        float deltaPitch = Math.abs(currentPitch - pitch);

        if (deltaYaw + deltaPitch > 120.0F) return null;

        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyePos,
                eyePos.addVector(
                        Math.cos(Math.toRadians(yaw + 90)) * Math.cos(Math.toRadians(pitch)) * reach.getInput(),
                        Math.sin(Math.toRadians(pitch)) * reach.getInput(),
                        Math.sin(Math.toRadians(yaw + 90)) * Math.cos(Math.toRadians(pitch)) * reach.getInput()));

        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return null;
        if (!mop.getBlockPos().equals(targetPos)) return null;
        if (mop.sideHit != face) return null;

        return new AimResult(targetPos, face, mop.hitVec, yaw, pitch);
    }

    private boolean canPlaceAtTarget() {
        if (targetHitPos == null || targetSide == null) return false;
        if (clutchBlocksPlaced >= (int) maxDistance.getInput()) return false;

        float currentYaw = renderedYaw != 0 ? renderedYaw : mc.thePlayer.rotationYaw;
        float currentPitch = renderedPitch != 0 ? renderedPitch : mc.thePlayer.rotationPitch;
        float deltaYaw = Math.abs(wrapYawDelta(currentYaw, aimYaw));
        float deltaPitch = Math.abs(currentPitch - aimPitch);

        return deltaYaw <= 30.0F && deltaPitch <= 30.0F;
    }

    private void doPlace() {
        if (targetHitPos == null || targetSide == null || targetHitVec == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return;

        if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, held,
                targetHitPos, targetSide, targetHitVec)) {
            clutchBlocksPlaced++;
            lastPlaced = targetHitPos;
            mc.thePlayer.swingItem();
        }

        clearAim(true);
    }

    private void clearAim(boolean snapback) {
        targetHitPos = null;
        targetSide = null;
        targetHitVec = null;
        lastPlaced = null;
        clutchBlocksPlaced = 0;
        if (snapback && hasAim) {
            resetting = true;
            smoothVelYaw = 0;
            smoothVelPitch = 0;
            jitterTimer = 0;
        }
        hasAim = false;
        placing = false;
        phase = 0;
        hasOvershot = false;
    }

    private void restoreAll() {
        if (slotWasSwapped && prevSlot != -1) {
            mc.thePlayer.inventory.currentItem = prevSlot;
            slotWasSwapped = false;
        }
        prevSlot = -1;
        placing = false;
        hasAim = false;
        resetting = false;
        renderedYaw = 0;
        renderedPitch = 0;
    }

    private int findBlockSlot() {
        for (int slot = 0; slot <= 8; slot++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack != null && stack.getItem() instanceof ItemBlock) {
                return slot;
            }
        }
        return -1;
    }

    private boolean canPlaceThrough(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        Material material = block.getMaterial();
        return material == Material.air || material == Material.water
                || material == Material.lava || block == Blocks.fire;
    }

    private boolean isReplaceable(BlockPos pos) {
        return canPlaceThrough(pos);
    }

    private static float wrapYaw(float yaw) {
        yaw = yaw % 360.0F;
        if (yaw >= 180.0F) yaw -= 360.0F;
        else if (yaw < -180.0F) yaw += 360.0F;
        return yaw;
    }

    private static float wrapYawDelta(float from, float to) {
        float delta = to - from;
        while (delta > 180.0F) delta -= 360.0F;
        while (delta < -180.0F) delta += 360.0F;
        return delta;
    }

    private static float clampPitch(float pitch) {
        return MathHelper.clamp_float(pitch, -90.0F, 90.0F);
    }

    private static class BlockCandidate {
        final double score;
        final BlockPos pos;
        final EnumFacing face;

        BlockCandidate(double score, BlockPos pos, EnumFacing face) {
            this.score = score;
            this.pos = pos;
            this.face = face;
        }
    }

    private static class AimResult {
        final BlockPos pos;
        final EnumFacing face;
        final Vec3 hitVec;
        final float yaw;
        final float pitch;

        AimResult(BlockPos pos, EnumFacing face, Vec3 hitVec, float yaw, float pitch) {
            this.pos = pos;
            this.face = face;
            this.hitVec = hitVec;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }
}
