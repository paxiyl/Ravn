package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.GameLoopEvent;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.server.S01PacketJoinGame;
import net.minecraft.network.play.server.S06PacketUpdateHealth;
import net.minecraft.network.play.server.S07PacketRespawn;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S13PacketDestroyEntities;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import org.lwjgl.opengl.GL11;

import java.util.concurrent.ConcurrentLinkedQueue;

public class Backtrack extends Module {

    public static SliderSetting range, delayMin, delayMax;
    public static TickSetting smart;
    public static TickSetting showReal;

    private double prevTargetDist = 0;

    private static final int MAX_QUEUE_SIZE = 100;

    private static final class QueuedPacket {
        final Packet<INetHandlerPlayClient> packet;
        final long time;

        QueuedPacket(Packet<INetHandlerPlayClient> packet, long time) {
            this.packet = packet;
            this.time = time;
        }
    }

    private final ConcurrentLinkedQueue<QueuedPacket> queue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<QueuedPacket> overflow = new ConcurrentLinkedQueue<>();

    private EntityPlayer target;
    private long currentDelay = 100L;

    private double realX, realY, realZ;
    private boolean hasRealPos = false;

    public Backtrack() {
        super("Backtrack", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Hits enemies where they were, not where they are"));
        this.registerSetting(range = new SliderSetting("Range", 3.5D, 1.0D, 6.0D, 0.5D));
        this.registerSetting(delayMin = new SliderSetting("Delay min (ms)", 60.0D, 0.0D, 500.0D, 10.0D));
        this.registerSetting(delayMax = new SliderSetting("Delay max (ms)", 120.0D, 0.0D, 500.0D, 10.0D));
        this.registerSetting(smart = new TickSetting("Smart", false));
        this.registerSetting(showReal = new TickSetting("Show real pos", true));
    }

    @Override
    public void onEnable() {
        armDelay();
        hasRealPos = false;
    }

    @Override
    public void onDisable() {
        flush();
        target = null;
        hasRealPos = false;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof AttackEntityEvent) {
            if (!isEnabled())
                return;

            Entity attacked = ((AttackEntityEvent) fe.getEvent()).target;
            if (!(attacked instanceof EntityPlayer) || attacked == mc.thePlayer)
                return;

            setTarget((EntityPlayer) attacked);
        }

        if (fe.getEvent() instanceof RenderWorldLastEvent && showReal.isToggled()) {
            if (!isBacktracking() || !hasRealPos || target == null)
                return;
            renderRealPos();
        }
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (!e.isIncoming() || !isEnabled())
            return;

        if (!Utils.Player.isPlayerInGame()) {
            flush(false);
            return;
        }

        Packet<?> p = e.getPacket();

        if (p instanceof S01PacketJoinGame || p instanceof S07PacketRespawn
                || p instanceof S08PacketPlayerPosLook) {
            flush();
            return;
        }

        if (p instanceof S06PacketUpdateHealth) {
            if (((S06PacketUpdateHealth) p).getHealth() <= 0.0F)
                flush();
            return;
        }

        if (p instanceof S13PacketDestroyEntities) {
            if (target != null) {
                for (int id : ((S13PacketDestroyEntities) p).getEntityIDs()) {
                    if (id == target.getEntityId()) {
                        setTarget(null);
                        break;
                    }
                }
            }
            return;
        }

        if (!isBacktracking())
            return;

        boolean qualifies = p instanceof S14PacketEntity
                || p instanceof S18PacketEntityTeleport
                || p instanceof S12PacketEntityVelocity;
        if (!qualifies)
            return;

        int entityId = getPacketEntityId(p);
        if (target != null && entityId != Integer.MIN_VALUE && entityId == target.getEntityId()) {
            extractRealPos(p);

            e.setCancelled(true);
            @SuppressWarnings("unchecked")
            Packet<INetHandlerPlayClient> cast = (Packet<INetHandlerPlayClient>) p;
            queue.add(new QueuedPacket(cast, System.currentTimeMillis()));
            while (queue.size() > MAX_QUEUE_SIZE) {
                QueuedPacket oldest = queue.poll();
                if (oldest != null)
                    overflow.add(oldest);
            }
        }
    }

    private void extractRealPos(Packet<?> p) {
        try {
            if (p instanceof S18PacketEntityTeleport) {
                S18PacketEntityTeleport tp = (S18PacketEntityTeleport) p;
                realX = tp.getX();
                realY = tp.getY();
                realZ = tp.getZ();
                hasRealPos = true;
            } else if (p instanceof S14PacketEntity) {
                S14PacketEntity ep = (S14PacketEntity) p;
                realX = target.posX + ep.func_149065_a();
                realY = target.posY + ep.func_149062_c();
                realZ = target.posZ + ep.func_149064_d();
                hasRealPos = true;
            } else if (p instanceof S12PacketEntityVelocity) {
                S12PacketEntityVelocity vel = (S12PacketEntityVelocity) p;
                realX = target.posX;
                realY = target.posY;
                realZ = target.posZ;
                hasRealPos = true;
            }
        } catch (Exception ignored) {
        }
    }

    private void renderRealPos() {
        if (target == null || mc.thePlayer == null || mc.getRenderManager() == null)
            return;

        double x = realX - mc.getRenderManager().viewerPosX;
        double y = realY - mc.getRenderManager().viewerPosY;
        double z = realZ - mc.getRenderManager().viewerPosZ;

        float r = 0.0F, g = 1.0F, b = 0.0F, a = 0.6F;

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        GL11.glLineWidth(2.0F);

        double wd = 0.3D;
        double wd2 = 1.8D;

        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        GL11.glVertex3d(x - wd, y, z - wd);
        GL11.glVertex3d(x + wd, y, z - wd);
        GL11.glVertex3d(x + wd, y, z + wd);
        GL11.glVertex3d(x - wd, y, z + wd);
        GL11.glEnd();

        GL11.glBegin(GL11.GL_LINE_LOOP);
        GL11.glVertex3d(x - wd, y + wd2, z - wd);
        GL11.glVertex3d(x + wd, y + wd2, z - wd);
        GL11.glVertex3d(x + wd, y + wd2, z + wd);
        GL11.glVertex3d(x - wd, y + wd2, z + wd);
        GL11.glEnd();

        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(x - wd, y, z - wd);
        GL11.glVertex3d(x - wd, y + wd2, z - wd);
        GL11.glVertex3d(x + wd, y, z - wd);
        GL11.glVertex3d(x + wd, y + wd2, z - wd);
        GL11.glVertex3d(x + wd, y, z + wd);
        GL11.glVertex3d(x + wd, y + wd2, z + wd);
        GL11.glVertex3d(x - wd, y, z + wd);
        GL11.glVertex3d(x - wd, y + wd2, z + wd);
        GL11.glEnd();

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private static int getPacketEntityId(Packet<?> p) {
        for (String name : new String[]{"getEntityId", "getEntityID"}) {
            try {
                java.lang.reflect.Method m = p.getClass().getMethod(name);
                return ((Number) m.invoke(p)).intValue();
            } catch (Exception ignored) {
            }
        }
        try {
            for (java.lang.reflect.Field f : p.getClass().getDeclaredFields()) {
                if (f.getType() == int.class
                        && (f.getName().toLowerCase().contains("entityid")
                        || f.getName().startsWith("field_"))) {
                    f.setAccessible(true);
                    return f.getInt(p);
                }
            }
        } catch (Exception ignored) {
        }
        return Integer.MIN_VALUE;
    }

    @Subscribe
    public void onGameLoop(GameLoopEvent e) {
        if (!Utils.Player.isPlayerInGame()) {
            flush(false);
            return;
        }

        validateTarget();

        QueuedPacket overflowed;
        while ((overflowed = overflow.poll()) != null)
            process(overflowed);

        if (queue.isEmpty())
            return;

        long now = System.currentTimeMillis();
        QueuedPacket head;
        while ((head = queue.peek()) != null && now - head.time >= currentDelay) {
            queue.poll();
            process(head);
        }

        if (queue.isEmpty())
            armDelay();
    }

    private boolean isBacktracking() {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer.isDead || !mc.thePlayer.isEntityAlive())
            return false;
        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())
            return false;
        if (target == null || target.isDead || !target.isEntityAlive())
            return false;
        if (mc.thePlayer.getDistanceToEntity(target) > range.getInput())
            return false;

        if (smart.isToggled()) {
            double currentDist = mc.thePlayer.getDistanceToEntity(target);
            if (prevTargetDist > 0 && currentDist < prevTargetDist - 0.1D) {
                prevTargetDist = currentDist;
                return false;
            }
            prevTargetDist = currentDist;
        }

        return true;
    }

    private void validateTarget() {
        if (target != null && !isBacktracking()) {
            flush();
            target = null;
        }
    }

    private void setTarget(EntityPlayer newTarget) {
        if (newTarget == target)
            return;

        if (newTarget == null) {
            validateTarget();
            return;
        }

        flush();
        target = newTarget;
        hasRealPos = false;
        armDelay();
    }

    private void armDelay() {
        double lo = Math.min(delayMin.getInput(), delayMax.getInput());
        double hi = Math.max(delayMin.getInput(), delayMax.getInput());
        currentDelay = lo == hi ? (long) lo : (long) Utils.Java.randomInt(lo, hi + 0.1D);
    }

    private void process(QueuedPacket queued) {
        try {
            queued.packet.processPacket(mc.getNetHandler());
        } catch (Exception ignored) {
        }
    }

    private void flush() {
        flush(true);
    }

    private void flush(boolean handlePackets) {
        QueuedPacket q;
        while ((q = queue.poll()) != null) {
            if (handlePackets)
                process(q);
        }
    }
}
