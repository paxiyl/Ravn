package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.LookEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.opengl.GL11;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Predictive 3-block horizontal wall placement across a moving target's path.
 *
 * ROTATION ARCHITECTURE (matches Ravn's existing pipeline):
 *
 *   UpdateEvent PRE  →  e.setYaw()/setPitch()        →  C03 packet (server)
 *                    →  renderYawOffset/yawHead       →  player model
 *                    →  rotationYaw/pitch              →  direct field write
 *
 *   LookEvent        →  e.setYaw()/setPitch()          →  camera look direction
 *
 * Both layers must be set every tick while rotating.
 * If only UpdateEvent is set, the camera does NOT move (LookEvent controls it).
 * If only LookEvent is set, the server gets stale rotation.
 */
public class AutoBlock extends Module {

    // ========================= SETTINGS =========================

    public static SliderSetting range;
    public static SliderSetting predictionTicks;
    public static SliderSetting placementReach;
    public static SliderSetting wallSpacing;
    public static SliderSetting frontDistance;
    public static SliderSetting tickDelay;
    public static SliderSetting earlyTicks;
    public static SliderSetting minEnemyDistance;
    public static SliderSetting confirmDelay;
    public static SliderSetting maxRetries;
    public static SliderSetting rotationSpeed;
    public static SliderSetting rotationTolerance;
    public static TickSetting predictiveRotation;
    public static TickSetting debug;
    public static TickSetting renderTarget;
    public static TickSetting renderPredicted;
    public static TickSetting renderBlocks;
    public static TickSetting blockPreview;
    public static SliderSetting previewLineWidth;
    public static SliderSetting previewAlpha;
    public static TickSetting renderConfirmed;
    public static TickSetting disableWhileBridging;
    public static TickSetting independentPlaceTiming;
    public static TickSetting adaptivePrediction;
    public static TickSetting threatCorridor;
    public static TickSetting preserveAttackLane;
    public static TickSetting directionChangeRecompute;
    public static TickSetting candidateLock;
    public static TickSetting verticalPrediction;
    public static SliderSetting adaptiveEarlyScale;
    public static SliderSetting enemyAttackReach;
    public static SliderSetting safetyMargin;
    public static SliderSetting directionChangeThreshold;
    public static SliderSetting candidateLockMs;
    public static SliderSetting candidateSwitchMargin;
    public static SliderSetting confidenceThreshold;
    public static SliderSetting pathSamples;

    // ========================= STATE MACHINE =========================

    private static final int S_IDLE = 0;
    private static final int S_ACQUIRING = 1;
    private static final int S_COMPUTING = 2;
    private static final int S_ROTATING = 3;
    private static final int S_PLACING = 4;
    private static final int S_CONFIRMING = 5;
    private static final int S_COMPLETE = 6;

    private int state;
    private int tickAccum;
    private int confirmAccum;
    private int retryAccum;
    private int acquireTicks;
    private int completeTicks;

    // AutoBlock owns its own placement timing. FastPlace/FastPlace+ are not
    // used to trigger or schedule AutoBlock placements.
    private static final Field blockHitDelayField;
    static {
        Field f = null;
        try {
            f = ReflectionHelper.findField(
                    net.minecraft.client.multiplayer.PlayerControllerMP.class,
                    "field_78778_q", "blockHitDelay");
        } catch (Throwable ignored) {
        }
        blockHitDelayField = f;
        if (blockHitDelayField != null) blockHitDelayField.setAccessible(true);
    }

    private boolean isPlacementCooldownAvailable() {
        if (blockHitDelayField == null || mc.playerController == null) return true;
        try {
            return blockHitDelayField.getInt(mc.playerController) <= 0;
        } catch (Throwable ignored) {
            return true;
        }
    }

    private void clearOwnPlacementCooldown() {
        if (blockHitDelayField == null || mc.playerController == null) return;
        try {
            blockHitDelayField.setInt(mc.playerController, 0);
        } catch (Throwable ignored) {
        }
    }

    // ========================= ROTATION =========================
    //
    // Unified rotation state. Both UpdateEvent and LookEvent read from
    // these fields. This is the SINGLE source of truth for camera direction.
    //
    private float desiredYaw, desiredPitch;
    private float appliedYaw, appliedPitch;
    private float prevAppliedYaw, prevAppliedPitch;
    private boolean hasApplied;
    private boolean rotationReached;

    // ========================= PLACEMENT PLAN =========================
    // Single source of truth for preview, rotation, validation, and placement.

    private int blockIdx;
    private final BlockPos[] wallPos = new BlockPos[3];
    private final BlockPos[] supportPos = new BlockPos[3];
    private final EnumFacing[] face = new EnumFacing[3];
    private final Vec3[] hitVec = new Vec3[3];
    private final WallResult[] result = new WallResult[3];
    private Block expectedBlock;

    // Hard safety cap: one target engagement may place at most 1 block.
    private int successfulPlacements;
    private boolean rearmRequired;
    /** Hard one-placement latch: no second placement until the target changes. */
    private boolean placementConsumed;
    private int consumedTargetId = -1;
    private long placementCooldownUntilMs;
    private int completedTargetId = -1;
    private double completedTargetX, completedTargetZ;

    // ========================= TARGET / PREDICTION =========================

    private EntityPlayer target;
    private double prevTX, prevTZ;
    private double velX, velZ;
    private boolean hasVel;
    private double predX, predZ, predYaw;
    private double prevVelX, prevVelZ;
    private boolean hasPreviousVelocity;
    private double confidence;
    private double threatTimeTicks;
    private double threatDistance;

    // ========================= STALE =========================

    private double stalePlayerX, stalePlayerZ;
    private double staleVelX, staleVelZ;
    private long candidateLockedUntilMs;
    private BlockPos lockedCandidate;
    private double lockedCandidateScore = Double.MAX_VALUE;

    // ========================= INVENTORY =========================

    private int savedSlot = -1;
    private int blockSlot = -1;

    // ========================= CONFIRMATION =========================

    private long placementStartTick;
    private Block placementExpectedBlock;
    private static final long PLACEMENT_TIMEOUT_TICKS = 20;

    // ========================= SLOT SWITCHING =========================

    private void setSlot(int slot) {
        if (mc.thePlayer == null || slot < 0 || slot > 8) return;
        if (mc.thePlayer.inventory.currentItem == slot) return;
        mc.thePlayer.inventory.currentItem = slot;
        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(slot));
    }

    // ========================= GCD =========================

    private double getMouseGCD() {
        final float sens = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        final float pow = sens * sens * sens * 8.0F;
        return pow * 0.15D;
    }

    private float applyGCD(float yaw, float prevYaw) {
        double gcd = getMouseGCD();
        float dif = yaw - prevYaw;
        return yaw - (float)(dif % gcd);
    }

    // ========================= CONSTRUCTOR =========================

    public AutoBlock() {
        super("AutoBlock", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting(
                "Predictive 3-block horizontal wall placement across a moving target's path."));
        this.registerSetting(range = new SliderSetting("Target range", 20.0D, 4.0D, 40.0D, 1.0D));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction ticks", 7.0D, 1.0D, 25.0D, 0.5D));
        this.registerSetting(placementReach = new SliderSetting("Reach buffer", 0.0D, 0.0D, 1.0D, 0.1D));
        this.registerSetting(wallSpacing = new SliderSetting("Wall spacing", 1.0D, 0.5D, 3.0D, 0.5D));
        this.registerSetting(frontDistance = new SliderSetting("Front distance", 1.5D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(tickDelay = new SliderSetting("Tick delay", 0.0D, 0.0D, 4.0D, 1.0D));
        this.registerSetting(earlyTicks = new SliderSetting("Early placement", 6.0D, 0.0D, 12.0D, 0.5D));
        this.registerSetting(minEnemyDistance = new SliderSetting("Enemy safe distance", 3.15D, 2.5D, 5.0D, 0.05D));
        this.registerSetting(confirmDelay = new SliderSetting("Confirm ticks", 1.0D, 1.0D, 6.0D, 1.0D));
        this.registerSetting(maxRetries = new SliderSetting("Max retries", 2.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 180.0D, 20.0D, 360.0D, 5.0D));
        this.registerSetting(rotationTolerance = new SliderSetting("Rotation tolerance", 3.0D, 0.5D, 12.0D, 0.5D));
        this.registerSetting(predictiveRotation = new TickSetting("Predictive rotation", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
        this.registerSetting(renderTarget = new TickSetting("Render target", true));
        this.registerSetting(renderPredicted = new TickSetting("Render predicted", true));
        this.registerSetting(renderBlocks = new TickSetting("Render blocks", true));
        this.registerSetting(blockPreview = new TickSetting("Block preview", true));
        this.registerSetting(previewLineWidth = new SliderSetting("Preview line width", 2.0D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(previewAlpha = new SliderSetting("Preview alpha", 1.0D, 0.1D, 1.0D, 0.1D));
        this.registerSetting(renderConfirmed = new TickSetting("Render confirmed", false));
        this.registerSetting(disableWhileBridging = new TickSetting("Disable while bridging", true));
        this.registerSetting(independentPlaceTiming = new TickSetting("Independent placement timing", true));
        this.registerSetting(adaptivePrediction = new TickSetting("Adaptive prediction", true));
        this.registerSetting(threatCorridor = new TickSetting("Threat corridor", true));
        this.registerSetting(preserveAttackLane = new TickSetting("Preserve attack lane", true));
        this.registerSetting(directionChangeRecompute = new TickSetting("Direction change recompute", true));
        this.registerSetting(candidateLock = new TickSetting("Candidate lock", true));
        this.registerSetting(verticalPrediction = new TickSetting("Vertical prediction", true));
        this.registerSetting(adaptiveEarlyScale = new SliderSetting("Adaptive early scale", 1.25D, 0.0D, 2.0D, 0.05D));
        this.registerSetting(enemyAttackReach = new SliderSetting("Enemy attack reach", 3.05D, 2.6D, 4.0D, 0.05D));
        this.registerSetting(safetyMargin = new SliderSetting("Safety margin", 0.55D, 0.10D, 1.25D, 0.05D));
        this.registerSetting(directionChangeThreshold = new SliderSetting("Direction change", 22.0D, 5.0D, 60.0D, 1.0D));
        this.registerSetting(candidateLockMs = new SliderSetting("Candidate lock ms", 45.0D, 0.0D, 200.0D, 5.0D));
        this.registerSetting(candidateSwitchMargin = new SliderSetting("Candidate switch margin", 0.35D, 0.05D, 2.0D, 0.05D));
        this.registerSetting(confidenceThreshold = new SliderSetting("Confidence threshold", 0.30D, 0.0D, 1.0D, 0.02D));
        this.registerSetting(pathSamples = new SliderSetting("Path samples", 20.0D, 6.0D, 32.0D, 1.0D));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        restoreSlot();
        reset();
    }

    private boolean isActive() {
        return state >= S_ROTATING && state <= S_CONFIRMING;
    }

    // ========================= TICK =========================

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null)
            return;
        if (mc.currentScreen != null)
            return;

        if (disableWhileBridging.isToggled() && isBridging()) {
            restoreSlot();
            reset();
            return;
        }

        if (state > S_IDLE && state < S_COMPLETE && !targetValid()) {
            debugMsg("\u00a7cTarget lost");
            restoreSlot();
            reset();
            return;
        }

        tickAccum++;
        if (tickAccum < (int) tickDelay.getInput())
            return;
        tickAccum = 0;

        switch (state) {
            case S_IDLE:      tickIdle(); break;
            case S_ACQUIRING: tickAcquiring(); break;
            case S_COMPUTING: tickComputing(); break;
            case S_ROTATING:  tickRotating(); break;
            case S_PLACING:   tickPlacing(); break;
            case S_CONFIRMING:tickConfirming(); break;
            case S_COMPLETE:  tickComplete(); break;
        }
    }

    private void tickIdle() {
        if (!AutoBlockHelper.isHoldingBlock()) return;
        EntityPlayer found = AutoBlockHelper.findTarget(range.getInput());
        if (found == null) {
            target = null;
            hasVel = false;
            // Re-arm only after the previous target leaves the engagement.
            rearmRequired = false;
            completedTargetId = -1;
            return;
        }

        // Do not start a defensive placement while the enemy is already inside
        // the configured melee safety radius. Wait until there is enough space.
        if (!isEnemyOutsideSafetyRadius(found)) {
            target = found;
            return;
        }

        // HARD ONE-BLOCK PER TARGET: movement of the same target must never
        // re-arm placement. This prevents repeated placements as the target
        // crosses the prediction corridor multiple times.
        if (placementConsumed && found.getEntityId() == consumedTargetId) {
            target = found;
            return;
        }
        if (placementConsumed && found.getEntityId() != consumedTargetId) {
            placementConsumed = false;
            consumedTargetId = -1;
            rearmRequired = false;
            successfulPlacements = 0;
        }

        if (found != target) {
            if (target == null || found.getEntityId() != target.getEntityId())
                successfulPlacements = 0;
            target = found;
            hasVel = false;
            acquireTicks = 0;
        }
        state = S_ACQUIRING;
    }

    private void tickAcquiring() {
        if (!targetValid()) { restoreSlot(); reset(); return; }
        if (hasVel) {
            double[] v = AutoBlockHelper.calcVelocity(target, prevTX, prevTZ);
            prevVelX = velX; prevVelZ = velZ;
            velX = v[0]; velZ = v[1];
            hasPreviousVelocity = true;
        }
        prevTX = target.posX; prevTZ = target.posZ;
        if (!hasVel) {
            prevVelX = velX; prevVelZ = velZ;
        }
        hasVel = true;
        acquireTicks++;
        if (acquireTicks >= 1)
            state = S_COMPUTING;
    }

    private void tickComputing() {
        if (!isEnemyOutsideSafetyRadius(target)) {
            restoreSlot();
            reset();
            return;
        }

        if (disableWhileBridging.isToggled() && isBridging()) {
            restoreSlot();
            reset();
            return;
        }

        PredictionProfile profile = buildPredictionProfile(target);
        if (profile.confidence < confidenceThreshold.getInput()) {
            debugMsg("\u00a7eLow prediction confidence: " + String.format("%.2f", profile.confidence));
            restoreSlot();
            reset();
            return;
        }

        predX = profile.futureX;
        predZ = profile.futureZ;
        predYaw = AutoBlockHelper.directionDegrees(profile.futureVX, profile.futureVZ);
        confidence = profile.confidence;
        threatTimeTicks = profile.threatTicks;
        threatDistance = profile.threatDistance;

        int wallY = (int) Math.floor(profile.futureY);
        if (wallY <= 0) {
            debugMsg("\u00a7cWall below void (Y=" + wallY + ")");
            restoreSlot();
            reset();
            return;
        }

        List<CandidatePlan> plans = buildThreatCandidates(target, profile);
        CandidatePlan selected = chooseStableCandidate(plans);
        if (selected == null) {
            debugMsg("\u00a7cNo safe interception candidate");
            restoreSlot();
            reset();
            return;
        }

        BlockPos selectedPos = selected.pos;
        if (!isWithinActualReach(selectedPos)) {
            debugMsg("\u00a7cPrediction out of reach");
            restoreSlot();
            reset();
            return;
        }

        if (savedSlot == -1) savedSlot = mc.thePlayer.inventory.currentItem;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            blockSlot = AutoBlockHelper.findBlockInHotbar();
            if (blockSlot == -1) { debugMsg("\u00a7cNo block in hotbar"); restoreSlot(); reset(); return; }
            setSlot(blockSlot);
            held = mc.thePlayer.getHeldItem();
        } else {
            blockSlot = mc.thePlayer.inventory.currentItem;
        }
        if (held == null || !(held.getItem() instanceof ItemBlock)) {
            debugMsg("\u00a7cNo block available"); restoreSlot(); reset(); return;
        }
        expectedBlock = ((ItemBlock) held.getItem()).block;

        // Keep one selected block as the only placement target. The other slots
        // remain empty so this module cannot silently fall back to a 3-block burst.
        for (int i = 0; i < 3; i++) {
            wallPos[i] = supportPos[i] = null;
            face[i] = null;
            hitVec[i] = null;
            result[i] = WallResult.FAILED;
        }

        wallPos[0] = selected.pos;
        supportPos[0] = selected.support;
        face[0] = selected.face;
        hitVec[0] = selected.hitVec;
        result[0] = WallResult.WAITING;
        blockIdx = 0;

        stalePlayerX = mc.thePlayer.posX;
        stalePlayerZ = mc.thePlayer.posZ;
        staleVelX = velX;
        staleVelZ = velZ;

        computeRotation(blockIdx);
        state = S_ROTATING;
        confirmAccum = 0;
        retryAccum = 0;
    }

    /**
     * Builds an adaptive short-horizon movement model.  It uses the enemy's
     * current velocity plus a bounded acceleration estimate, then increases the
     * horizon when the target is moving quickly toward the player's attack zone.
     */
    private PredictionProfile buildPredictionProfile(EntityPlayer p) {
        double vx = velX;
        double vz = velZ;
        double ax = 0.0D;
        double az = 0.0D;
        if (adaptivePrediction.isToggled() && hasPreviousVelocity) {
            ax = clamp(vx - prevVelX, -0.20D, 0.20D);
            az = clamp(vz - prevVelZ, -0.20D, 0.20D);
        }

        double speed = Math.sqrt(vx * vx + vz * vz);
        double currentDistance = Math.sqrt(
                (p.posX - mc.thePlayer.posX) * (p.posX - mc.thePlayer.posX) +
                (p.posZ - mc.thePlayer.posZ) * (p.posZ - mc.thePlayer.posZ));

        double pingSeconds = 0.0D;
        try {
            if (mc.getNetHandler() != null) {
                net.minecraft.client.network.NetworkPlayerInfo enemyInfo =
                        mc.getNetHandler().getPlayerInfo(p.getUniqueID());
                net.minecraft.client.network.NetworkPlayerInfo selfInfo =
                        mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
                int enemyPing = enemyInfo == null ? 0 : Math.max(0, enemyInfo.getResponseTime());
                int selfPing = selfInfo == null ? 0 : Math.max(0, selfInfo.getResponseTime());
                pingSeconds = Math.min(Math.max(enemyPing, selfPing), 300) / 1000.0D;
            }
        } catch (Throwable ignored) {
        }

        double baseEarly = Math.max(0.0D, earlyTicks.getInput()) * 0.05D;
        double adaptive = adaptivePrediction.isToggled()
                ? (speed * 0.40D + pingSeconds * 0.90D + Math.max(0.0D, enemyAttackReach.getInput() + safetyMargin.getInput() - currentDistance) * 0.20D)
                : 0.0D;
        adaptive *= adaptiveEarlyScale.getInput();

        double horizonTicks = predictionTicks.getInput() + (baseEarly + adaptive) * 20.0D;
        horizonTicks = clamp(horizonTicks, 1.0D, 24.0D);

        double futureX = p.posX;
        double futureZ = p.posZ;
        double futureY = p.posY;
        double futureVX = vx;
        double futureVZ = vz;
        int steps = Math.max(1, (int) Math.ceil(horizonTicks));
        double threatTicksFound = Double.MAX_VALUE;
        double threatDistanceFound = currentDistance;

        for (int i = 1; i <= steps; i++) {
            double t = Math.min(horizonTicks, i);
            double tx = p.posX + vx * t + 0.5D * ax * t * t;
            double tz = p.posZ + vz * t + 0.5D * az * t * t;
            double ty = p.posY;
            if (verticalPrediction.isToggled()) {
                double vy = p.posY - p.prevPosY;
                ty = p.posY + vy * t - 0.5D * 0.08D * t * t;
            }
            double dx = tx - mc.thePlayer.posX;
            double dz = tz - mc.thePlayer.posZ;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d <= enemyAttackReach.getInput() + safetyMargin.getInput() && threatTicksFound == Double.MAX_VALUE) {
                threatTicksFound = t;
                threatDistanceFound = d;
                futureX = tx;
                futureZ = tz;
                futureY = ty;
                futureVX = vx + ax * t;
                futureVZ = vz + az * t;
            }
        }

        if (threatTicksFound == Double.MAX_VALUE) {
            double t = horizonTicks;
            futureX = p.posX + vx * t + 0.5D * ax * t * t;
            futureZ = p.posZ + vz * t + 0.5D * az * t * t;
            futureY = p.posY;
            if (verticalPrediction.isToggled()) {
                double vy = p.posY - p.prevPosY;
                futureY = p.posY + vy * t - 0.5D * 0.08D * t * t;
            }
            futureVX = vx + ax * t;
            futureVZ = vz + az * t;
            double dx = futureX - mc.thePlayer.posX;
            double dz = futureZ - mc.thePlayer.posZ;
            threatDistanceFound = Math.sqrt(dx * dx + dz * dz);
        }

        double directionStability = 1.0D;
        if (hasPreviousVelocity && AutoBlockHelper.isMoving(vx, vz, 0.01D)
                && AutoBlockHelper.isMoving(prevVelX, prevVelZ, 0.01D)) {
            double oldA = Math.atan2(prevVelZ, prevVelX);
            double newA = Math.atan2(vz, vx);
            double delta = Math.abs(Math.toDegrees(Math.atan2(Math.sin(newA - oldA), Math.cos(newA - oldA))));
            directionStability = clamp(1.0D - delta / 90.0D, 0.0D, 1.0D);
        }
        double speedConfidence = clamp(speed / 0.16D, 0.0D, 1.0D);
        double safetyConfidence = threatDistanceFound >= enemyAttackReach.getInput() + safetyMargin.getInput()
                ? 1.0D : clamp((threatDistanceFound / Math.max(0.01D, enemyAttackReach.getInput() + safetyMargin.getInput())), 0.0D, 1.0D);
        double conf = clamp(0.45D * directionStability + 0.35D * speedConfidence + 0.20D * safetyConfidence, 0.0D, 1.0D);

        return new PredictionProfile(futureX, futureY, futureZ, futureVX, futureVZ,
                threatTicksFound == Double.MAX_VALUE ? horizonTicks : threatTicksFound,
                threatDistanceFound, conf, horizonTicks);
    }

    /**
     * Generates candidate cells from the full enemy approach corridor.  The
     * candidate must be replaceable, reachable, supported, and positioned on a
     * body/reach trajectory that can actually enter the player's attack zone.
     */
    private List<CandidatePlan> buildThreatCandidates(EntityPlayer enemy, PredictionProfile profile) {
        List<CandidatePlan> plans = new ArrayList<>();
        int samples = Math.max(4, (int) pathSamples.getInput());
        double vx = velX;
        double vz = velZ;
        double speed = Math.sqrt(vx * vx + vz * vz);
        if (speed < 0.01D) {
            vx = mc.thePlayer.posX - enemy.posX;
            vz = mc.thePlayer.posZ - enemy.posZ;
            speed = Math.sqrt(vx * vx + vz * vz);
        }
        if (speed < 0.01D) return plans;
        vx /= speed;
        vz /= speed;
        double sideX = -vz;
        double sideZ = vx;

        for (int i = 1; i <= samples; i++) {
            double t = profile.horizonTicks * (i / (double) samples);
            double px = enemy.posX + velX * t;
            double pz = enemy.posZ + velZ * t;
            if (adaptivePrediction.isToggled()) {
                double ax = hasPreviousVelocity ? clamp(velX - prevVelX, -0.20D, 0.20D) : 0.0D;
                double az = hasPreviousVelocity ? clamp(velZ - prevVelZ, -0.20D, 0.20D) : 0.0D;
                px += 0.5D * ax * t * t;
                pz += 0.5D * az * t * t;
            }

            int footY = (int) Math.floor(enemy.posY);
            if (verticalPrediction.isToggled()) {
                double vy = enemy.posY - enemy.prevPosY;
                footY = (int) Math.floor(enemy.posY + vy * t - 0.5D * 0.08D * t * t);
            }

            // Search across the enemy's body width and one cell forward/backward
            // through the trajectory, not just at a single center cell.
            double[] sideOffsets = {-0.85D, 0.0D, 0.85D};
            double[] forwardOffsets = {-0.20D, 0.35D, 0.85D};
            for (double side : sideOffsets) {
                for (double forward : forwardOffsets) {
                    double cx = px + sideX * side + vx * forward;
                    double cz = pz + sideZ * side + vz * forward;
                    int[] ys = verticalPrediction.isToggled()
                            ? new int[]{footY, footY + 1}
                            : new int[]{(int) Math.floor(enemy.posY)};

                    for (int y : ys) {
                        BlockPos pos = new BlockPos(MathHelper.floor_double(cx), y, MathHelper.floor_double(cz));
                        CandidatePlan plan = evaluateCandidate(enemy, pos, cx, cz, t, profile);
                        if (plan != null) plans.add(plan);
                    }
                }
            }
        }
        return plans;
    }

    private CandidatePlan evaluateCandidate(EntityPlayer enemy, BlockPos pos,
                                             double predictedX, double predictedZ,
                                             double sampleTicks, PredictionProfile profile) {
        if (pos == null || pos.getY() <= 0) return null;
        if (!AutoBlockHelper.isChunkLoaded(pos) || !AutoBlockHelper.isBlockReplaceable(pos)) return null;
        if (!isWithinActualReach(pos)) return null;

        BlockPos support = AutoBlockHelper.findSupportBlock(pos);
        if (support == null || support.getY() <= 0) return null;
        EnumFacing f = AutoBlockHelper.findPlacementFace(pos, support);
        if (f == null) return null;
        Vec3 hv = AutoBlockHelper.computeHitVec(support, f);

        AxisAlignedBB blockBB = new AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0D, pos.getY() + 1.0D, pos.getZ() + 1.0D);
        if (blockBB.intersectsWith(mc.thePlayer.getEntityBoundingBox().expand(0.06D, 0.0D, 0.06D))) return null;

        // Full threat-body check: use the enemy's whole horizontal body plus
        // attack reach rather than a single center-point distance.
        AxisAlignedBB enemyNow = enemy.getEntityBoundingBox();
        AxisAlignedBB projectedEnemy = offsetHorizontal(enemyNow, predictedX - enemy.posX, predictedZ - enemy.posZ);
        boolean bodyIntersects = blockBB.expand(0.04D, 0.04D, 0.04D).intersectsWith(projectedEnemy);

        double enemyToPlayer = horizontalDistance(predictedX, predictedZ, mc.thePlayer.posX, mc.thePlayer.posZ);
        if (enemyToPlayer < enemyAttackReach.getInput() + safetyMargin.getInput() - 0.10D) return null;

        double corridorDistance = corridorDistanceToPlayerAttackZone(predictedX, predictedZ, pos);
        boolean corridorHit = corridorDistance <= 0.90D;
        if (threatCorridor.isToggled() && !corridorHit && !bodyIntersects) return null;

        if (preserveAttackLane.isToggled() && !preservesPlayerAttackLane(enemy, pos)) return null;

        double yaw = AutoBlockHelper.calcRotation(hv)[0];
        double yawDelta = Math.abs(MathHelper.wrapAngleTo180_float((float) yaw - mc.thePlayer.rotationYaw));
        if (yawDelta > 180.0D) yawDelta = 360.0D - yawDelta;

        double blockToFuture = horizontalDistance(pos.getX() + 0.5D, pos.getZ() + 0.5D, predictedX, predictedZ);
        double attackBuffer = Math.max(0.0D, enemyToPlayer - enemyAttackReach.getInput());
        double lateral = Math.max(0.0D, corridorDistance - 0.25D);
        double earlyBias = sampleTicks * 0.10D;
        double confidencePenalty = (1.0D - profile.confidence) * 4.0D;

        double score = sampleTicks * 0.18D
                + blockToFuture * 5.0D
                + lateral * 9.0D
                + yawDelta * 0.015D
                + Math.max(0.0D, 0.45D - attackBuffer) * 6.0D
                + confidencePenalty
                + earlyBias;

        if (bodyIntersects) score -= 1.0D;
        if (corridorHit) score -= 1.75D;
        if (enemyToPlayer <= enemyAttackReach.getInput() + safetyMargin.getInput() + 1.0D) score -= 1.0D;

        float[] rot = AutoBlockHelper.calcRotation(hv);
        return new CandidatePlan(pos, support, f, hv, rot[0], rot[1], score, profile.confidence,
                sampleTicks, enemyToPlayer, bodyIntersects, corridorHit);
    }

    private CandidatePlan chooseStableCandidate(List<CandidatePlan> plans) {
        if (plans.isEmpty()) return null;
        plans.sort(Comparator.comparingDouble(c -> c.score));
        CandidatePlan best = plans.get(0);
        long now = System.currentTimeMillis();

        if (candidateLock.isToggled() && lockedCandidate != null && now < candidateLockedUntilMs) {
            CandidatePlan locked = null;
            for (CandidatePlan c : plans) {
                if (lockedCandidate.equals(c.pos)) { locked = c; break; }
            }
            if (locked != null && best.score + candidateSwitchMargin.getInput() >= locked.score) {
                return locked;
            }
        }

        lockedCandidate = best.pos;
        lockedCandidateScore = best.score;
        candidateLockedUntilMs = now + (long) candidateLockMs.getInput();
        return best;
    }

    private double corridorDistanceToPlayerAttackZone(double enemyX, double enemyZ, BlockPos pos) {
        double px = mc.thePlayer.posX;
        double pz = mc.thePlayer.posZ;
        double dx = enemyX - px;
        double dz = enemyZ - pz;
        double lenSq = dx * dx + dz * dz;
        if (lenSq < 1.0E-6D) return Double.MAX_VALUE;
        double bx = pos.getX() + 0.5D - px;
        double bz = pos.getZ() + 0.5D - pz;
        double t = (bx * dx + bz * dz) / lenSq;
        t = clamp(t, 0.0D, 1.0D);
        double cx = px + dx * t;
        double cz = pz + dz * t;
        return horizontalDistance(pos.getX() + 0.5D, pos.getZ() + 0.5D, cx, cz);
    }

    private boolean preservesPlayerAttackLane(EntityPlayer enemy, BlockPos candidate) {
        AxisAlignedBB bb = new AxisAlignedBB(candidate.getX(), candidate.getY(), candidate.getZ(),
                candidate.getX() + 1.0D, candidate.getY() + 1.0D, candidate.getZ() + 1.0D);
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        Vec3[] aimPoints = new Vec3[]{
                new Vec3(enemy.posX, enemy.posY + enemy.getEyeHeight() * 0.90D, enemy.posZ),
                new Vec3(enemy.posX, enemy.posY + enemy.height * 0.55D, enemy.posZ),
                new Vec3(enemy.posX, enemy.posY + 0.30D, enemy.posZ)
        };
        for (Vec3 point : aimPoints) {
            if (!segmentIntersectsBB(eye, point, bb)) return true;
        }
        return false;
    }

    private boolean segmentIntersectsBB(Vec3 a, Vec3 b, AxisAlignedBB bb) {
        double[] tMinMax = {0.0D, 1.0D};
        if (!clipAxis(a.xCoord, b.xCoord, bb.minX, bb.maxX, tMinMax)) return false;
        if (!clipAxis(a.yCoord, b.yCoord, bb.minY, bb.maxY, tMinMax)) return false;
        if (!clipAxis(a.zCoord, b.zCoord, bb.minZ, bb.maxZ, tMinMax)) return false;
        return tMinMax[1] >= tMinMax[0];
    }

    private boolean clipAxis(double start, double end, double min, double max, double[] t) {
        double d = end - start;
        if (Math.abs(d) < 1.0E-8D) return start >= min && start <= max;
        double inv = 1.0D / d;
        double a = (min - start) * inv;
        double b = (max - start) * inv;
        if (a > b) { double tmp = a; a = b; b = tmp; }
        t[0] = Math.max(t[0], a);
        t[1] = Math.min(t[1], b);
        return t[1] >= t[0];
    }

    private AxisAlignedBB offsetHorizontal(AxisAlignedBB bb, double dx, double dz) {
        return new AxisAlignedBB(bb.minX + dx, bb.minY, bb.minZ + dz,
                bb.maxX + dx, bb.maxY, bb.maxZ + dz);
    }

    private double horizontalDistance(double x1, double z1, double x2, double z2) {
        double dx = x1 - x2;
        double dz = z1 - z2;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private void tickRotating() {
        if (!isEnemyOutsideSafetyRadius(target) || isBridging()) {
            result[blockIdx] = WallResult.FAILED;
            restoreSlot();
            reset();
            return;
        }

        if (isWallStale()) {
            debugMsg("\u00a7eWall stale, recomputing");
            restoreSlot(); state = S_COMPUTING; savedSlot = -1; return;
        }

        if (!rotationReached) {
            confirmAccum++;
            if (confirmAccum > 8) {
                debugMsg("\u00a7cRotation timeout"); result[blockIdx] = WallResult.FAILED; advance();
            }
            return;
        }

        if (!validatePlacement(blockIdx)) {
            debugMsg("\u00a7cPre-place validation failed, re-aiming");
            computeRotation(blockIdx);
            return;
        }

        if (mc.thePlayer.inventory.currentItem != blockSlot)
            setSlot(blockSlot);

        state = S_PLACING;
    }

    private void tickPlacing() {
        if (!holdBlock()) { result[blockIdx] = WallResult.FAILED; advance(); return; }
        if (supportPos[blockIdx] == null) { result[blockIdx] = WallResult.NO_SUPPORT; advance(); return; }

        boolean placed = doPlace(wallPos[blockIdx], supportPos[blockIdx], face[blockIdx], hitVec[blockIdx]);
        if (placed) {
            successfulPlacements++;
            placementStartTick = mc.thePlayer.ticksExisted;
            placementExpectedBlock = expectedBlock;
            debugMsg("\u00a7aBlock " + successfulPlacements + "/1 sent");

            // Never allow more than one successful placement in one
            // engagement, even if the state machine is reset immediately.
            if (successfulPlacements >= 1) {
                rearmRequired = true;
                placementConsumed = true;
                consumedTargetId = target == null ? -1 : target.getEntityId();
                completedTargetId = consumedTargetId;
                completedTargetX = target == null ? 0.0D : target.posX;
                completedTargetZ = target == null ? 0.0D : target.posZ;
                // Prevent an immediate second click even if another event/state
                // transition reaches S_PLACING during the same short window.
                placementCooldownUntilMs = System.currentTimeMillis() + 250L;
            }

            // One successful placement is the complete engagement. Confirming
            // the world state is unnecessary for scheduling another block and
            // would only add latency, so finish immediately.
            result[blockIdx] = WallResult.CONFIRMED;
            state = S_COMPLETE;
            completeTicks = 0;
            confirmAccum = 0;
        } else {
            retryAccum++;
            if (retryAccum >= (int) maxRetries.getInput()) {
                result[blockIdx] = WallResult.FAILED; advance();
            } else {
                computeRotation(blockIdx);
                state = S_ROTATING;
            }
        }
    }

    private void tickConfirming() {
        confirmAccum++;
        Block actual = mc.theWorld.getBlockState(wallPos[blockIdx]).getBlock();
        if (actual == expectedBlock) {
            result[blockIdx] = WallResult.CONFIRMED;
            debugMsg("\u00a7aBlock " + (blockIdx + 1) + " confirmed");
            advance(); return;
        }
        long elapsed = mc.thePlayer.ticksExisted - placementStartTick;
        if (elapsed > PLACEMENT_TIMEOUT_TICKS || confirmAccum >= (int) confirmDelay.getInput()) {
            result[blockIdx] = WallResult.FAILED;
            debugMsg("\u00a7cBlock " + (blockIdx + 1) + " confirm timeout");
            advance();
        }
    }

    private void tickComplete() {
        completeTicks++;
        if (completeTicks > 1) { restoreSlot(); reset(); }
    }

    // ========================= ROTATION CONTROLLER =========================
    //
    // This is the SINGLE rotation controller. It sets BOTH layers:
    //   1. UpdateEvent (packet + model + direct field)
    //   2. LookEvent (camera look direction)
    //
    // Both are set EVERY tick while isActive().
    // The LookEvent handler runs during camera rendering and MUST have
    // current applied values available.
    //
    // This matches exactly how KillAura controls rotation in Ravn:
    //   - KillAura sets e.setYaw() + renderYawOffset + rotationYawHead in UpdateEvent
    //   - KillAura overrides LookEvent with target yaw/pitch
    //   - KillAura does NOT write mc.thePlayer.rotationYaw directly
    //   - The camera moves because LookEvent controls it

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre() || mc.thePlayer == null)
            return;

        if (!isActive()) return;

        float speed = (float) rotationSpeed.getInput();
        float tolerance = (float) rotationTolerance.getInput();

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        float dYaw = MathHelper.wrapAngleTo180_float(desiredYaw - curYaw);
        float dPitch = desiredPitch - curPitch;

        float newYaw = curYaw + MathHelper.clamp_float(dYaw, -speed, speed);
        float newPitch = MathHelper.clamp_float(
                curPitch + MathHelper.clamp_float(dPitch, -speed, speed),
                -90.0F, 90.0F);

        float prevYaw = hasApplied ? prevAppliedYaw : curYaw;
        float prevPitch = hasApplied ? prevAppliedPitch : curPitch;

        newYaw = maxAngleChange(prevYaw, newYaw, speed);
        newPitch = maxAngleChange(prevPitch, newPitch, speed);

        newYaw = applyGCD(newYaw, prevYaw);
        newPitch = applyGCD(newPitch, prevPitch);

        appliedYaw = newYaw;
        appliedPitch = newPitch;
        prevAppliedYaw = newYaw;
        prevAppliedPitch = newPitch;
        hasApplied = true;

        e.setYaw(appliedYaw);
        e.setPitch(appliedPitch);

        mc.thePlayer.renderYawOffset = appliedYaw;
        mc.thePlayer.rotationYawHead = appliedYaw;

        float errYaw = Math.abs(MathHelper.wrapAngleTo180_float(desiredYaw - appliedYaw));
        float errPitch = Math.abs(desiredPitch - appliedPitch);
        if (errYaw <= tolerance && errPitch <= tolerance) {
            if (!rotationReached) {
                rotationReached = true;
                debugMsg("\u00a7aRotation reached (err=" + String.format("%.2f", errYaw) + "," + String.format("%.2f", errPitch) + ")");
            }
        }
    }

    @Subscribe
    public void onLookEvent(LookEvent e) {
        if (mc.thePlayer == null) return;
        if (!isActive()) return;
        if (!hasApplied) return;

        e.setPrevYaw(prevAppliedYaw);
        e.setPrevPitch(prevAppliedPitch);
        e.setYaw(appliedYaw);
        e.setPitch(appliedPitch);
    }

    // ========================= REACH =========================

    private double getActualReach() {
        return mc.playerController.getBlockReachDistance() + placementReach.getInput();
    }

    private boolean isWithinActualReach(BlockPos pos) {
        if (mc.thePlayer == null) return false;
        double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
        double dy = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) <= getActualReach();
    }

    // ========================= PLACEMENT VALIDATION =========================

    private boolean validatePlacement(int i) {
        if (i < 0 || i >= 3) return false;
        if (target == null || target.isDead) return false;
        if (disableWhileBridging.isToggled() && isBridging()) return false;
        if (confidence < confidenceThreshold.getInput()) return false;
        if (wallPos[i] == null || supportPos[i] == null || face[i] == null || hitVec[i] == null) return false;
        if (wallPos[i].getY() <= 0) return false;
        if (supportPos[i].getY() <= 0) return false;
        if (!AutoBlockHelper.isBlockReplaceable(wallPos[i])) return false;
        if (!AutoBlockHelper.isChunkLoaded(wallPos[i])) return false;
        if (!isWithinActualReach(wallPos[i])) return false;
        if (!holdBlock()) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return false;
        if (((ItemBlock) held.getItem()).block != expectedBlock) return false;

        // Final timing gate: reject only when the enemy is already well inside
        // its attack envelope. This lets the module commit earlier instead of
        // waiting until the last tick, which is a common cause of ghost/stale
        // placements on latency-heavy servers.
        double nowDistance = horizontalDistance(target.posX, target.posZ, mc.thePlayer.posX, mc.thePlayer.posZ);
        double emergencyFloor = Math.max(2.65D, enemyAttackReach.getInput() - 0.20D);
        if (nowDistance < emergencyFloor) return false;

        Block sb = mc.theWorld.getBlockState(supportPos[i]).getBlock();
        if (!sb.isNormalCube() && !sb.isFullBlock()) return false;

        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eye, hitVec[i], false, false, true);
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return false;
        if (!mop.getBlockPos().equals(supportPos[i])) return false;
        if (mop.sideHit != face[i]) return false;

        EnumFacing curFace = AutoBlockHelper.findPlacementFace(wallPos[i], supportPos[i]);
        if (curFace == null || curFace != face[i]) return false;

        return true;
    }

    // ========================= STALE WALL =========================

    private boolean isWallStale() {
        if (mc.thePlayer == null || target == null) return true;
        double pd = Math.sqrt(
                (mc.thePlayer.posX - stalePlayerX) * (mc.thePlayer.posX - stalePlayerX) +
                (mc.thePlayer.posZ - stalePlayerZ) * (mc.thePlayer.posZ - stalePlayerZ));
        if (pd > 2.0) return true;
        if (directionChangeRecompute.isToggled()
                && AutoBlockHelper.isMoving(velX, velZ, 0.01D)
                && AutoBlockHelper.isMoving(staleVelX, staleVelZ, 0.01D)) {
            double a = Math.abs(Math.toDegrees(Math.atan2(velX, velZ) - Math.atan2(staleVelX, staleVelZ)));
            if (a > 180) a = 360 - a;
            if (a > directionChangeThreshold.getInput()) return true;
        }
        for (int i = 0; i < 3; i++)
            if (result[i] == WallResult.WAITING && wallPos[i] != null)
                if (!AutoBlockHelper.isChunkLoaded(wallPos[i]) || !AutoBlockHelper.isBlockReplaceable(wallPos[i]))
                    return true;
        return false;
    }

    // ========================= STATE ADVANCEMENT =========================

    private void advance() {
        retryAccum = 0;
        int next = nextWaiting(blockIdx + 1);
        if (next != -1) {
            blockIdx = next;
            if (mc.thePlayer != null && blockSlot >= 0 && blockSlot < 9)
                setSlot(blockSlot);
            computeRotation(blockIdx);
            state = S_ROTATING;
            confirmAccum = 0;
        } else {
            state = S_COMPLETE;
            completeTicks = 0;
        }
    }

    private int nextWaiting(int from) {
        for (int i = from; i < 3; i++)
            if (result[i] == WallResult.WAITING) return i;
        return -1;
    }

    // ========================= BLOCK PLACEMENT =========================

    private boolean doPlace(BlockPos target, BlockPos support, EnumFacing f, Vec3 hv) {
        if (mc.thePlayer == null || mc.theWorld == null) return false;
        if (placementConsumed || System.currentTimeMillis() < placementCooldownUntilMs) return false;
        if (!AutoBlockHelper.isBlockReplaceable(target)) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return false;
        // AutoBlock uses its own placement timing. It does not depend on
        // FastPlace/FastPlace+ to clear the controller's cooldown. This is a
        // single intentional click, not a click loop.
        if (independentPlaceTiming.isToggled())
            clearOwnPlacementCooldown();

        boolean placed = mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, held, support, f, hv);
        if (placed) {
            mc.thePlayer.swingItem();
            mc.getItemRenderer().resetEquippedProgress();
        }
        return placed;
    }

    private boolean holdBlock() {
        if (mc.thePlayer.inventory.currentItem != blockSlot) {
            setSlot(blockSlot);
        }
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock
                && ((ItemBlock) held.getItem()).block == expectedBlock;
    }

    private void computeRotation(int index) {
        if (hitVec[index] == null) { result[index] = WallResult.FAILED; advance(); return; }
        float[] r = AutoBlockHelper.calcRotation(hitVec[index]);
        desiredYaw = r[0];
        desiredPitch = r[1];
        rotationReached = false;
        hasApplied = false;
        confirmAccum = 0;
    }

    private boolean isEnemyOutsideSafetyRadius(EntityPlayer p) {
        if (p == null || mc.thePlayer == null) return false;
        double dx = p.posX - mc.thePlayer.posX;
        double dz = p.posZ - mc.thePlayer.posZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double dynamic = minEnemyDistance.getInput();
        if (adaptivePrediction.isToggled()) {
            double speed = Math.sqrt(velX * velX + velZ * velZ);
            dynamic = Math.max(dynamic, enemyAttackReach.getInput() + safetyMargin.getInput() + speed * 0.35D);
        }
        return horizontal >= dynamic;
    }

    private boolean isBridging() {
        try {
            if (mc.thePlayer == null || mc.gameSettings == null) return false;

            Module scaffold = keystrokesmod.client.main.Raven.moduleManager
                    .getModuleByClazz(keystrokesmod.client.module.modules.world.Scaffold.class);
            Module bridge = keystrokesmod.client.main.Raven.moduleManager
                    .getModuleByClazz(BridgeAssist.class);
            if (scaffold != null && scaffold.isEnabled()) return true;
            if (bridge != null && bridge.isEnabled()) return true;

            // Manual bridging heuristic: forward movement + held use + looking
            // substantially downward at a block below/behind the player.
            if (!mc.gameSettings.keyBindUseItem.isKeyDown()) return false;
            if (mc.thePlayer.rotationPitch < 55.0F) return false;
            if (mc.thePlayer.movementInput == null) return false;
            float forward = mc.thePlayer.movementInput.moveForward;
            float strafe = mc.thePlayer.movementInput.moveStrafe;
            if (Math.abs(forward) < 0.05F && Math.abs(strafe) < 0.05F) return false;

            MovingObjectPosition mop = mc.objectMouseOver;
            if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return false;
            BlockPos hit = mop.getBlockPos();
            double yDelta = mc.thePlayer.posY - (hit.getY() + 1.0D);
            boolean downwardPlacement = yDelta >= -0.25D && yDelta <= 1.5D;
            boolean lookingNearFeet = hit.getY() <= Math.floor(mc.thePlayer.posY);
            boolean moving = Math.abs(forward) > 0.05F || Math.abs(strafe) > 0.05F;
            return downwardPlacement && lookingNearFeet && moving;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean targetValid() {
        return target != null && !target.isDead && target.getHealth() > 0
                && mc.theWorld != null && mc.theWorld.getEntityByID(target.getEntityId()) != null;
    }

    private float maxAngleChange(float prev, float target, float maxTurn) {
        float dif = MathHelper.wrapAngleTo180_float(target - prev);
        if (dif > maxTurn) dif = maxTurn;
        if (dif < -maxTurn) dif = -maxTurn;
        return prev + dif;
    }

    // ========================= INVENTORY =========================

    private void restoreSlot() {
        if (savedSlot >= 0 && savedSlot < 9 && mc.thePlayer != null)
            setSlot(savedSlot);
        savedSlot = -1; blockSlot = -1;
    }

    // ========================= RESET =========================

    private void reset() {
        state = S_IDLE;
        target = null; hasVel = false; velX = velZ = 0;
        prevVelX = prevVelZ = 0.0D;
        hasPreviousVelocity = false;
        confidence = 0.0D;
        threatTimeTicks = Double.MAX_VALUE;
        threatDistance = Double.MAX_VALUE;
        rotationReached = false; hasApplied = false;
        tickAccum = confirmAccum = retryAccum = acquireTicks = completeTicks = 0;
        // Keep successfulPlacements across reset while rearmRequired is true so
        // a reset cannot silently start another placement burst.
        if (!placementConsumed && !rearmRequired) successfulPlacements = 0;
        blockIdx = -1; expectedBlock = null;
        lockedCandidate = null;
        lockedCandidateScore = Double.MAX_VALUE;
        candidateLockedUntilMs = 0L;
        for (int i = 0; i < 3; i++) {
            wallPos[i] = supportPos[i] = null;
            face[i] = null; hitVec[i] = null; result[i] = null;
        }
    }

    // ========================= DEBUG =========================

    private void debugMsg(String msg) {
        if (debug.isToggled())
            Utils.Player.sendMessageToSelf("[AB] " + msg);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (!debug.isToggled() || !Utils.Player.isPlayerInGame()) return;

        int y = 50;
        draw(y, "\u00a7dAutoBlock", "v2"); y += 12;

        if (target != null) {
            draw(y, "Target", target.getName()); y += 10;
            draw(y, "Distance", String.format("%.1f", mc.thePlayer.getDistanceToEntity(target))); y += 10;
            draw(y, "Velocity", String.format("%.3f, %.3f", velX, velZ)); y += 10;
            draw(y, "Direction", AutoBlockHelper.isMoving(velX, velZ, 0.01D)
                    ? AutoBlockHelper.directionName(velX, velZ) : "STATIC"); y += 10;
            draw(y, "Pred X/Z", String.format("%.2f / %.2f", predX, predZ)); y += 10;
            draw(y, "Confidence", String.format("%.2f", confidence)); y += 10;
            draw(y, "Threat", String.format("%.1f ticks / %.2f blocks", threatTimeTicks, threatDistance)); y += 10;
        }

        y += 4;
        draw(y, "State", stateName() + " | Rot: " + (rotationReached ? "DONE" : hasApplied ? "ACTIVE" : "NONE")); y += 10;
        if (blockIdx >= 0) {
            draw(y, "Block", (blockIdx + 1) + "/1"); y += 10;
            if (wallPos[blockIdx] != null)
                draw(y, "Pos", wallPos[blockIdx].getX() + "," + wallPos[blockIdx].getY() + "," + wallPos[blockIdx].getZ()); y += 10;
            if (supportPos[blockIdx] != null)
                draw(y, "Support", supportPos[blockIdx].getX() + "," + supportPos[blockIdx].getY() + "," + supportPos[blockIdx].getZ()); y += 10;
            if (face[blockIdx] != null) draw(y, "Face", face[blockIdx].getName()); y += 10;
            if (hitVec[blockIdx] != null)
                draw(y, "HitVec", String.format("%.2f,%.2f,%.2f", hitVec[blockIdx].xCoord, hitVec[blockIdx].yCoord, hitVec[blockIdx].zCoord)); y += 10;
        }
        y += 4;

        draw(y, "Des Yaw", String.format("%.2f", desiredYaw)); y += 10;
        draw(y, "Des Pitch", String.format("%.2f", desiredPitch)); y += 10;
        draw(y, "Applied Yaw", String.format("%.2f", appliedYaw)); y += 10;
        draw(y, "Applied Pitch", String.format("%.2f", appliedPitch)); y += 10;
        draw(y, "Player Yaw", String.format("%.2f", mc.thePlayer.rotationYaw)); y += 10;
        draw(y, "Player Pitch", String.format("%.2f", mc.thePlayer.rotationPitch)); y += 10;
        y += 4;

        float errYaw = Math.abs(MathHelper.wrapAngleTo180_float(desiredYaw - mc.thePlayer.rotationYaw));
        float errPitch = Math.abs(desiredPitch - mc.thePlayer.rotationPitch);
        draw(y, "Err Yaw/Pitch", String.format("%.2f / %.2f", errYaw, errPitch)); y += 10;
        draw(y, "RotationSync", errYaw < 5.0F ? "\u00a7aOK" : "\u00a7cDESYNC"); y += 10;
        y += 4;

        boolean los = validateLineOfSightSafe();
        boolean reach = blockIdx >= 0 && blockIdx < 3 && wallPos[blockIdx] != null
                && isWithinActualReach(wallPos[blockIdx]);
        draw(y, "LOS", los ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        draw(y, "Reach", reach ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        draw(y, "Held", holdBlock() ? "\u00a7aYES" : "\u00a7cNO"); y += 10;
        y += 4;

        String[] names = {"LEFT", "CENTER", "RIGHT"};
        for (int i = 0; i < 3; i++) {
            String s; int c;
            if (result[i] == null) { s = "\u00a77N/A"; c = 0x808080; }
            else switch (result[i]) {
                case CONFIRMED:    s = "\u00a7aCONFIRMED";  c = 0x55FF55; break;
                case WAITING:      s = "\u00a7eWAITING";    c = 0xFFFF55; break;
                case NO_SUPPORT:   s = "\u00a7cNO_SUPPORT"; c = 0xFF5555; break;
                case FAILED:       s = "\u00a7cFAILED";     c = 0xFF5555; break;
                case OUT_OF_REACH: s = "\u00a7cOOR";        c = 0xFF5555; break;
                default:           s = "\u00a77" + result[i].name(); c = 0xAAAAAA;
            }
            mc.fontRendererObj.drawStringWithShadow("  \u00a77" + names[i] + ": " + s, 4, y, c);
            y += 10;
        }
    }

    private boolean validateLineOfSightSafe() {
        if (blockIdx < 0 || blockIdx >= 3 || hitVec[blockIdx] == null || supportPos[blockIdx] == null) return false;
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eye, hitVec[blockIdx], false, false, true);
        return mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK
                && mop.getBlockPos().equals(supportPos[blockIdx]) && mop.sideHit == face[blockIdx];
    }

    private void draw(int y, String label, String value) {
        mc.fontRendererObj.drawStringWithShadow("\u00a77" + label + ": \u00a7f" + value, 4, y, 0xFFFFFF);
    }

    private String stateName() {
        switch (state) {
            case S_IDLE:       return "IDLE";
            case S_ACQUIRING:  return "ACQUIRING";
            case S_COMPUTING:  return "COMPUTING";
            case S_ROTATING:   return "ROTATING";
            case S_PLACING:    return "PLACING";
            case S_CONFIRMING: return "CONFIRMING";
            case S_COMPLETE:   return "COMPLETE";
            default:           return "?";
        }
    }

    // ========================= WORLD RENDERING =========================

    @Subscribe
    public void onRenderWorldLast(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof RenderWorldLastEvent)) return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null) return;

        if (debug.isToggled()) renderDebugWorld();
        if (blockPreview.isToggled() && isActive()) renderPreview();
    }

    private void renderDebugWorld() {
        if (renderTarget.isToggled() && target != null)
            Utils.HUD.re(new BlockPos((int) Math.floor(target.posX), (int) Math.floor(target.posY),
                    (int) Math.floor(target.posZ)), 0xFFFF0000, true);
        if (renderPredicted.isToggled() && hasVel)
            Utils.HUD.re(new BlockPos((int) Math.floor(predX),
                    (int) Math.floor(target.posY),
                    (int) Math.floor(predZ)), 0xFF00FF00, true);
        if (renderBlocks.isToggled()) {
            for (int i = 0; i < 3; i++) {
                if (wallPos[i] == null) continue;
                int c;
                switch (result[i] != null ? result[i] : WallResult.WAITING) {
                    case CONFIRMED: c = 0xFF00FF00; break;
                    case WAITING:   c = 0xFFFFFF00; break;
                    default:        c = 0xFFFF0000; break;
                }
                Utils.HUD.re(wallPos[i], c, true);
            }
        }
    }

    private void renderPreview() {
        float lw = (float) previewLineWidth.getInput();
        float alpha = (float) previewAlpha.getInput();

        for (int i = 0; i < 3; i++) {
            if (wallPos[i] == null || result[i] == null) continue;
            if (result[i] == WallResult.FAILED || result[i] == WallResult.OUT_OF_REACH) continue;
            if (result[i] == WallResult.CONFIRMED && !renderConfirmed.isToggled()) continue;

            int color; float a;
            if (i == blockIdx && result[i] == WallResult.WAITING) { color = 0xFFFF0000; a = alpha; }
            else if (result[i] == WallResult.CONFIRMED) { color = 0xFF00FF00; a = alpha * 0.6F; }
            else { color = 0xFFFFFFFF; a = alpha * 0.3F; }

            drawBlockOutline(wallPos[i], color, a, lw);
        }
    }

    private void drawBlockOutline(BlockPos pos, int color, float alpha, float lw) {
        float r = (float) ((color >> 16) & 255) / 255.0F;
        float g = (float) ((color >> 8) & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;
        double rx = pos.getX() - mc.getRenderManager().viewerPosX;
        double ry = pos.getY() - mc.getRenderManager().viewerPosY;
        double rz = pos.getZ() - mc.getRenderManager().viewerPosZ;
        AxisAlignedBB bb = new AxisAlignedBB(rx, ry, rz, rx + 1, ry + 1, rz + 1);

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glLineWidth(lw);
        GL11.glColor4f(r, g, b, alpha);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private static final class PredictionProfile {
        final double futureX, futureY, futureZ;
        final double futureVX, futureVZ;
        final double threatTicks, threatDistance;
        final double confidence, horizonTicks;

        PredictionProfile(double futureX, double futureY, double futureZ,
                          double futureVX, double futureVZ, double threatTicks,
                          double threatDistance, double confidence, double horizonTicks) {
            this.futureX = futureX;
            this.futureY = futureY;
            this.futureZ = futureZ;
            this.futureVX = futureVX;
            this.futureVZ = futureVZ;
            this.threatTicks = threatTicks;
            this.threatDistance = threatDistance;
            this.confidence = confidence;
            this.horizonTicks = horizonTicks;
        }
    }

    private static final class CandidatePlan {
        final BlockPos pos;
        final BlockPos support;
        final EnumFacing face;
        final Vec3 hitVec;
        final float yaw, pitch;
        final double score, confidence, sampleTicks, enemyDistance;
        final boolean bodyIntersects, corridorHit;

        CandidatePlan(BlockPos pos, BlockPos support, EnumFacing face, Vec3 hitVec,
                      float yaw, float pitch, double score, double confidence,
                      double sampleTicks, double enemyDistance, boolean bodyIntersects,
                      boolean corridorHit) {
            this.pos = pos;
            this.support = support;
            this.face = face;
            this.hitVec = hitVec;
            this.yaw = yaw;
            this.pitch = pitch;
            this.score = score;
            this.confidence = confidence;
            this.sampleTicks = sampleTicks;
            this.enemyDistance = enemyDistance;
            this.bodyIntersects = bodyIntersects;
            this.corridorHit = corridorHit;
        }
    }

    private enum WallResult {
        WAITING, CONFIRMED, FAILED, NO_SUPPORT, OUT_OF_REACH
    }
}
