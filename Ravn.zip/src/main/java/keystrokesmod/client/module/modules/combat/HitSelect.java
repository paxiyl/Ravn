package keystrokesmod.client.module.modules.combat;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.MovingObjectPosition;

import java.util.Random;

/**
 * HitSelect - latency-aware click filter.
 * Lets clicks through when they are predicted to deal damage,
 * cancels the ones that would be eaten by hurt immunity.
 * Ported from FDPClient's HitSelect for Raven.
 */
public class HitSelect extends Module {

    public static ComboSetting<Mode> mode;
    public static ComboSetting<FakeSwingMode> fakeSwing;
    public static TickSetting pingCompensation;
    public static SliderSetting cancelRate, missedSwingCancel, burstCount, pauseDuration, pingBuffer;

    private static final Random random = new Random();
    private static final int MAX_HURT_RESISTANT_TIME = 20;

    private static int currentTargetId = -1;
    private static int burstHits = 0;
    private static boolean bursting = false;

    public HitSelect() {
        super("HitSelect", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Filters out clicks that wouldn't deal damage"));
        this.registerSetting(mode = new ComboSetting<>("Mode", Mode.Burst));
        this.registerSetting(fakeSwing = new ComboSetting<>("Fake swing", FakeSwingMode.Off));
        this.registerSetting(cancelRate = new SliderSetting("Cancel rate (%)", 100.0D, 0.0D, 100.0D, 5.0D));
        this.registerSetting(missedSwingCancel = new SliderSetting("Missed swing cancel (%)", 100.0D, 0.0D, 100.0D, 5.0D));
        this.registerSetting(burstCount = new SliderSetting("Burst count", 1.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(pauseDuration = new SliderSetting("Pause duration (ticks)", 10.0D, 0.0D, 20.0D, 1.0D));
        this.registerSetting(pingCompensation = new TickSetting("Ping compensation", true));
        this.registerSetting(pingBuffer = new SliderSetting("Ping buffer (ticks)", 0.0D, 0.0D, 5.0D, 1.0D));
    }

    @Override
    public void onDisable() {
        burstHits = 0;
        bursting = false;
        currentTargetId = -1;
    }

    /**
     * Called from MixinPlayerControllerMP before every entity attack.
     * Returns true to cancel the attack.
     */
    public static boolean shouldCancelAttack(EntityLivingBase target) {
        Module self = Raven.moduleManager.getModuleByClazz(HitSelect.class);
        if (self == null || !self.isEnabled())
            return false;

        if (!Utils.Player.isPlayerInGame())
            return false;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())
            return false;

        EntityPlayerSP player = mc.thePlayer;
        if (target == null || target == player || target.isDead || !target.isEntityAlive())
            return false;

        if (Targets.isAFriend(target))
            return false;

        handleTargetSwitch(target);

        boolean allow;
        if (mode.getMode() == Mode.Criticals && isInCriticalPosition(player)) {
            allow = true;
        }
        else {
            allow = evaluateBurstClick(target);
        }

        if (!allow)
            performFakeSwing();

        return !allow;
    }

    /**
     * Called from MixinMinecraft before every left click.
     * Only rolls for true air swings - block breaking is never touched.
     */
    public static boolean shouldCancelAirClick(MovingObjectPosition objectMouseOver) {
        Module self = Raven.moduleManager.getModuleByClazz(HitSelect.class);
        if (self == null || !self.isEnabled())
            return false;

        if (!Utils.Player.isPlayerInGame())
            return false;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())
            return false;

        if (objectMouseOver != null && objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.MISS)
            return false;

        double chance = missedSwingCancel.getInput();
        if (chance <= 0.0D)
            return false;

        if (random.nextInt(100) >= chance)
            return false;

        performFakeSwing();
        return true;
    }

    private static boolean evaluateBurstClick(EntityLivingBase target) {
        boolean canDamage = target.hurtResistantTime - effectivePingTicks()
                <= Math.max(0, MAX_HURT_RESISTANT_TIME - (int) pauseDuration.getInput());

        if (canDamage || bursting) {
            burstHits++;
            bursting = true;
            if (burstHits >= (int) burstCount.getInput()) {
                bursting = false;
                burstHits = 0;
            }
            return true;
        }

        return random.nextInt(100) < (int) cancelRate.getInput();
    }

    private static boolean isInCriticalPosition(EntityPlayerSP player) {
        return player.motionY < 0.0D && !player.onGround && player.fallDistance > 0.0F
                && !player.isOnLadder() && !player.isInWater() && !player.isRiding();
    }

    private static int effectivePingTicks() {
        int pingTicks = pingCompensation.isToggled() ? getPingTicks() : 0;
        return pingTicks + (int) pingBuffer.getInput();
    }

    private static int getPingTicks() {
        try {
            EntityPlayerSP p = mc.thePlayer;
            net.minecraft.client.network.NetworkPlayerInfo info =
                    mc.getNetHandler().getPlayerInfo(p.getUniqueID());
            if (info != null)
                return Math.min(info.getResponseTime() / 50, 10);
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static void handleTargetSwitch(EntityLivingBase target) {
        if (target.getEntityId() == currentTargetId)
            return;
        currentTargetId = target.getEntityId();
        burstHits = 0;
        bursting = false;
    }

    private static void performFakeSwing() {
        if (!Utils.Player.isPlayerInGame())
            return;
        switch (fakeSwing.getMode()) {
            case Client:
                mc.thePlayer.swingProgressInt = -1;
                mc.thePlayer.isSwingInProgress = true;
                break;
            case Server:
                mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
                break;
            default:
        }
    }

    public enum Mode {
        Burst, Criticals
    }

    public enum FakeSwingMode {
        Off, Client, Server
    }
}
