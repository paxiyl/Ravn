package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;

public class FastPlacePlus extends Module {
    public static SliderSetting mode;
    public static SliderSetting minCps;
    public static SliderSetting maxCps;
    public static SliderSetting initialDelay;
    public static TickSetting onlyHolding;
    public static TickSetting blocksOnly;
    public static TickSetting blacklistObsidian;
    public static TickSetting legit;

    private long nextClickTime = 0;
    private long lastCpsUpdate = 0;
    private long startHoldingTime = 0;
    private double currentTargetCps = 0;
    private boolean butterflySecondClick = false;
    private int slowClicksRemaining = 0;

    private static final Field rightClickDelayTimerField;
    private static final Field blockHitDelayField;

    static {
        Field rcdt = null;
        try {
            rcdt = net.minecraftforge.fml.relauncher.ReflectionHelper.findField(
                    net.minecraft.client.Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        } catch (Exception ignored) {
        }
        rightClickDelayTimerField = rcdt;
        if (rightClickDelayTimerField != null)
            rightClickDelayTimerField.setAccessible(true);

        Field bhd = null;
        try {
            for (String name : new String[]{"field_78778_q", "blockHitDelay"}) {
                try {
                    Field f = net.minecraft.client.multiplayer.PlayerControllerMP.class.getDeclaredField(name);
                    if (f.getType() == int.class) {
                        f.setAccessible(true);
                        bhd = f;
                        break;
                    }
                } catch (NoSuchFieldException ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        blockHitDelayField = bhd;
        if (blockHitDelayField != null)
            blockHitDelayField.setAccessible(true);
    }

    public FastPlacePlus() {
        super("FastPlace+", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Advanced fast place with multiple modes"));
        this.registerSetting(mode = new SliderSetting("Mode", 0.0D, 0.0D, 3.0D, 1.0D));
        this.registerSetting(minCps = new SliderSetting("Min CPS", 25.0D, 1.0D, 50.0D, 1.0D));
        this.registerSetting(maxCps = new SliderSetting("Max CPS", 30.0D, 1.0D, 50.0D, 1.0D));
        this.registerSetting(initialDelay = new SliderSetting("Initial delay", 120.0D, 5.0D, 1000.0D, 1.0D));
        this.registerSetting(onlyHolding = new TickSetting("Only holding", true));
        this.registerSetting(blocksOnly = new TickSetting("Blocks only", true));
        this.registerSetting(blacklistObsidian = new TickSetting("Blacklist obsidian", true));
        this.registerSetting(legit = new TickSetting("Legit", false));
    }

    @Override
    public void onEnable() {
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    private void resetState() {
        nextClickTime = 0;
        lastCpsUpdate = 0;
        startHoldingTime = 0;
        butterflySecondClick = false;
        slowClicksRemaining = 0;
        currentTargetCps = 0;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;

        boolean isHolding = mc.gameSettings.keyBindUseItem.isKeyDown();

        if (onlyHolding.isToggled() && !isHolding) {
            resetState();
            return;
        }

        if (!onlyHolding.isToggled() && !isHolding) {
            isHolding = true;
        }

        if (blocksOnly.isToggled()) {
            ItemStack item = mc.thePlayer.getHeldItem();
            if (item == null || !(item.getItem() instanceof ItemBlock)) {
                resetState();
                return;
            }
        }

        if (blacklistObsidian.isToggled()) {
            if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK) {
                Block lookedAt = mc.theWorld.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock();
                if (lookedAt == Blocks.obsidian) {
                    resetState();
                    return;
                }
            }
            ItemStack held = mc.thePlayer.getHeldItem();
            if (held != null && held.getItem() instanceof ItemBlock) {
                Block heldBlock = ((ItemBlock) held.getItem()).getBlock();
                if (heldBlock == Blocks.obsidian) {
                    resetState();
                    return;
                }
            }
        }

        long now = System.currentTimeMillis();

        if (startHoldingTime == 0) {
            startHoldingTime = now;
            double initDelay = initialDelay.getInput();
            nextClickTime = startHoldingTime + (long) initDelay + calculateDelay();
        }

        if (now >= nextClickTime) {
            int modeVal = (int) mode.getInput();
            boolean legitMode = legit.isToggled();

            if (modeVal == 2) {
                if (butterflySecondClick) {
                    doRightClick();
                    butterflySecondClick = false;
                    nextClickTime = now + (legitMode ? randomInt(10, 25) : 20);
                } else {
                    doRightClick();
                    butterflySecondClick = true;
                    nextClickTime = now + calculateDelay();
                }
            } else {
                doRightClick();
                nextClickTime = now + calculateDelay();
            }
        }
    }

    private void doRightClick() {
        if (rightClickDelayTimerField != null) {
            try {
                rightClickDelayTimerField.set(mc, 0);
            } catch (Exception ignored) {
            }
        }
        if (blockHitDelayField != null && mc.playerController != null) {
            try {
                blockHitDelayField.set(mc.playerController, 0);
            } catch (Exception ignored) {
            }
        }
    }

    private long calculateDelay() {
        long now = System.currentTimeMillis();
        int modeVal = (int) mode.getInput();
        boolean legitMode = legit.isToggled();

        if (currentTargetCps == 0 || (legitMode && now - lastCpsUpdate > randomInt(800, 2000))) {
            double min = minCps.getInput();
            double max = maxCps.getInput();
            if (min > max) {
                double temp = min;
                min = max;
                max = temp;
            }
            currentTargetCps = min + Math.random() * (max - min);
            lastCpsUpdate = now;
        }

        long baseDelay = (long) (1000.0 / currentTargetCps);

        if (!legitMode) {
            return baseDelay;
        }

        if (modeVal == 3) {
            return randomInt(33, 45);
        }

        long extraDelay = 0;
        if (slowClicksRemaining > 0) {
            extraDelay = randomInt(20, 50);
            slowClicksRemaining--;
        } else {
            double slowChance = (modeVal == 1) ? 0.04 : 0.06;
            if (Math.random() < slowChance) {
                slowClicksRemaining = randomInt(1, 3);
            }
        }

        long delay = baseDelay + extraDelay;

        if (modeVal == 1) {
            delay += randomInt(-2, 6);
        } else {
            delay += randomInt(-5, 12);
        }

        if (delay < 34) {
            delay = 34;
        }

        return delay;
    }

    private static int randomInt(int min, int max) {
        return min + (int) (Math.random() * (max - min));
    }
}
