package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.client.Minecraft;

public class SprintController {

    public enum Technique {
        NONE,
        W_TAP,
        S_TAP,
        SHIFT_TAP
    }

    private Technique activeTechnique = Technique.NONE;
    private boolean techniqueActive = false;
    private int techniqueDuration = 0;
    private int techniqueTimer = 0;
    private boolean shouldResetSprint = false;

    public void reset() {
        activeTechnique = Technique.NONE;
        techniqueActive = false;
        techniqueDuration = 0;
        techniqueTimer = 0;
        shouldResetSprint = false;
    }

    public void requestTechnique(Technique technique, int duration) {
        if (technique == Technique.NONE) return;
        activeTechnique = technique;
        techniqueDuration = duration;
        techniqueTimer = 0;
        techniqueActive = true;
    }

    public void requestSprintReset() {
        shouldResetSprint = true;
    }

    public void tick() {
        if (techniqueActive) {
            techniqueTimer++;
            if (techniqueTimer >= techniqueDuration) {
                techniqueActive = false;
                activeTechnique = Technique.NONE;
            }
        }

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (techniqueActive) {
            switch (activeTechnique) {
                case W_TAP:
                    mc.thePlayer.setSprinting(false);
                    break;
                case S_TAP:
                    mc.thePlayer.setSprinting(false);
                    mc.thePlayer.moveForward = -0.1f;
                    break;
                case SHIFT_TAP:
                    mc.thePlayer.setSneaking(true);
                    break;
                default:
                    break;
            }
        } else if (activeTechnique == Technique.SHIFT_TAP) {
            mc.thePlayer.setSneaking(false);
        }

        if (shouldResetSprint) {
            mc.thePlayer.setSprinting(false);
            shouldResetSprint = false;
        }
    }

    public Technique getActiveTechnique() { return activeTechnique; }
    public boolean isTechniqueActive() { return techniqueActive; }
    public int getTechniqueTimer() { return techniqueTimer; }
}
