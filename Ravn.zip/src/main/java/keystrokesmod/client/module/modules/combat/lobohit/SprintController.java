package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.client.Minecraft;

public class SprintController {

    public enum Technique {
        NONE,
        W_TAP,
        S_TAP,
        SHIFT_TAP
    }

    private Technique activeTechnique = Technique.NONE;
    private boolean techniqueActive = false;
    private int techniqueDuration = 0;
    private int techniqueTimer = 0;
    private boolean shouldResetSprint = false;
    private int resetCooldown = 0;

    public void reset() {
        activeTechnique = Technique.NONE;
        techniqueActive = false;
        techniqueDuration = 0;
        techniqueTimer = 0;
        shouldResetSprint = false;
        resetCooldown = 0;
    }

    public void requestTechnique(Technique technique, int duration) {
        if (resetCooldown > 0) return;
        if (technique == Technique.NONE) return;
        activeTechnique = technique;
        techniqueDuration = duration;
        techniqueTimer = 0;
        techniqueActive = true;
    }

    public void requestSprintReset() {
        if (resetCooldown > 0) return;
        shouldResetSprint = true;
    }

    public void tick() {
        if (resetCooldown > 0) {
            resetCooldown--;
        }

        if (techniqueActive) {
            techniqueTimer++;
            if (techniqueTimer >= techniqueDuration) {
                techniqueActive = false;
                activeTechnique = Technique.NONE;
                resetCooldown = 4;
            }
        }

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (techniqueActive) {
            switch (activeTechnique) {
                case W_TAP:
                    mc.thePlayer.setSprinting(false);
                    break;
                case S_TAP:
                    mc.thePlayer.setSprinting(false);
                    break;
                case SHIFT_TAP:
                    mc.thePlayer.setSneaking(true);
                    break;
                default:
                    break;
            }
        } else if (activeTechnique == Technique.SHIFT_TAP) {
            mc.thePlayer.setSneaking(false);
        }

        if (shouldResetSprint) {
            mc.thePlayer.setSprinting(false);
            shouldResetSprint = false;
            resetCooldown = 3;
        }
    }

    public Technique getActiveTechnique() { return activeTechnique; }
    public boolean isTechniqueActive() { return techniqueActive; }
    public int getTechniqueTimer() { return techniqueTimer; }
}
