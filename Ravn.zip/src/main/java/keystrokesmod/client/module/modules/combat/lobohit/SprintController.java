package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.client.Minecraft;

public class SprintController {
    private static final float SPRINT_SPEED = 0.2873f;
    private static final float WALK_SPEED = 0.21586f;

    private boolean sprintActive = false;
    private boolean wtapQueued = false;
    private boolean stapQueued = false;
    private boolean shiftTapQueued = false;
    private int sprintResetTicks = 0;
    private int wtapCooldown = 0;
    private int stapCooldown = 0;
    private int shiftTapCooldown = 0;
    private int currentTapDuration = 0;
    private int maxTapDuration = 0;
    private boolean tapActive = false;
    private SprintTapMode activeTapMode = SprintTapMode.NONE;

    public enum SprintTapMode {
        NONE,
        W_TAP,
        S_TAP,
        SHIFT_TAP
    }

    public void reset() {
        sprintActive = false;
        wtapQueued = false;
        stapQueued = false;
        shiftTapQueued = false;
        sprintResetTicks = 0;
        wtapCooldown = 0;
        stapCooldown = 0;
        shiftTapCooldown = 0;
        currentTapDuration = 0;
        maxTapDuration = 0;
        tapActive = false;
        activeTapMode = SprintTapMode.NONE;
    }

    public void onSprintReset(int duration) {
        sprintResetTicks = duration;
        sprintActive = false;
    }

    public void queueWTap(int duration) {
        if (wtapCooldown <= 0) {
            wtapQueued = true;
            maxTapDuration = duration;
            currentTapDuration = 0;
            tapActive = false;
            activeTapMode = SprintTapMode.W_TAP;
        }
    }

    public void queueSTap(int duration) {
        if (stapCooldown <= 0) {
            stapQueued = true;
            maxTapDuration = duration;
            currentTapDuration = 0;
            tapActive = false;
            activeTapMode = SprintTapMode.S_TAP;
        }
    }

    public void queueShiftTap(int duration) {
        if (shiftTapCooldown <= 0) {
            shiftTapQueued = true;
            maxTapDuration = duration;
            currentTapDuration = 0;
            tapActive = false;
            activeTapMode = SprintTapMode.SHIFT_TAP;
        }
    }

    public void tick(CombatState state) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (sprintResetTicks > 0) {
            sprintResetTicks--;
            mc.thePlayer.setSprinting(false);
        }

        if (wtapQueued || stapQueued || shiftTapQueued) {
            if (!tapActive) {
                tapActive = true;
                mc.thePlayer.setSprinting(false);
            }
            currentTapDuration++;
            if (currentTapDuration >= maxTapDuration) {
                tapActive = false;
                mc.thePlayer.setSprinting(true);
                if (wtapQueued) {
                    wtapCooldown = 4;
                    wtapQueued = false;
                } else if (stapQueued) {
                    stapCooldown = 4;
                    stapQueued = false;
                } else if (shiftTapQueued) {
                    shiftTapCooldown = 4;
                    shiftTapQueued = false;
                }
                activeTapMode = SprintTapMode.NONE;
            }
        }

        if (wtapCooldown > 0) wtapCooldown--;
        if (stapCooldown > 0) stapCooldown--;
        if (shiftTapCooldown > 0) shiftTapCooldown--;

        if (mc.thePlayer.onGround && !sprintActive && sprintResetTicks <= 0 && !tapActive) {
            mc.thePlayer.setSprinting(true);
            sprintActive = true;
        }

        state.setPlayerSprintResetActive(sprintResetTicks > 0 || tapActive);
        state.setPlayerWtapActive(activeTapMode == SprintTapMode.W_TAP && tapActive);
    }

    public boolean isApplyingSprintReset() {
        return sprintResetTicks > 0 || tapActive;
    }

    public SprintTapMode getActiveTapMode() {
        return activeTapMode;
    }

    public boolean isSprintActive() {
        return sprintActive;
    }

    public void forceSprint(boolean sprint) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) {
            mc.thePlayer.setSprinting(sprint);
            sprintActive = sprint;
        }
    }

    public float getSpeedMultiplier() {
        if (tapActive) {
            switch (activeTapMode) {
                case W_TAP: return 0.85f;
                case S_TAP: return 0.7f;
                case SHIFT_TAP: return 0.6f;
                default: return 1.0f;
            }
        }
        return sprintActive ? SPRINT_SPEED / WALK_SPEED : 1.0f;
    }
}
