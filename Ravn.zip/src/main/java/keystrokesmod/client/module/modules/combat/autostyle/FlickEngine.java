package keystrokesmod.client.module.modules.combat.autostyle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class FlickEngine {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private FlickTrajectory trajectory;
    private long flickStart = 0;
    private boolean flicking = false;
    private boolean lastLeft = false;

    public boolean isFlicking() { return flicking; }

    public void reset() {
        trajectory = null;
        flicking = false;
    }

    public void startFlick(
        EntityPlayer target,
        double intensity,
        double pitchAmount
    ) {
        if (mc.thePlayer == null || target == null) return;

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        float desiredYaw = getDesiredYaw(target);
        float desiredPitch = getDesiredPitch(target);

        double distance = mc.thePlayer.getDistanceToEntity(target);
        double distFactor = Math.min(1.0, distance / 3.0);

        double amplitude = (25.0 + intensity * 0.55) * distFactor;
        double jitter = 1.0 + (Math.random() - 0.5) * 0.25;
        amplitude *= jitter;

        boolean left = computeDirection(target);
        float sign = left ? -1.0F : 1.0F;

        float peakYaw = curYaw + sign * (float) amplitude;
        float peakPitch = Rotation.clampPitch(curPitch + sign * (float)(pitchAmount * 0.3));

        long flickNs = (long) (65_000_000 + Math.random() * 40_000_000);
        long returnNs = (long) (flickNs * (0.8 + Math.random() * 0.4));

        trajectory = new FlickTrajectory(
            curYaw, curPitch,
            peakYaw, peakPitch,
            desiredYaw, Rotation.clampPitch(desiredPitch),
            flickNs, returnNs
        );

        flickStart = System.nanoTime();
        flicking = true;
        lastLeft = left;
    }

    public Rotation evaluate() {
        if (!flicking || trajectory == null) return null;

        long elapsed = System.nanoTime() - flickStart;
        Rotation rot = trajectory.evaluate(elapsed);

        if (trajectory.isComplete(elapsed)) {
            flicking = false;
            trajectory = null;
        }

        return rot;
    }

    public long getCooldownNanos() {
        return (long) (250_000_000 + Math.random() * 200_000_000);
    }

    public long getTrajectoryDurationNanos() {
        return trajectory != null ? trajectory.getTotalNanos() : 0;
    }

    private boolean computeDirection(EntityPlayer target) {
        MovementAnalyzer.StrafeDirection strafe = MovementAnalyzer.getPlayerStrafe();

        boolean preferLeft;
        switch (strafe) {
            case LEFT: preferLeft = true; break;
            case RIGHT: preferLeft = false; break;
            default:
                double relAngle = MovementAnalyzer.getRelativeAngleToTarget(target);
                preferLeft = relAngle > 0;
                break;
        }

        if (Math.random() < 0.35) preferLeft = !preferLeft;
        return preferLeft;
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.5) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }
}
