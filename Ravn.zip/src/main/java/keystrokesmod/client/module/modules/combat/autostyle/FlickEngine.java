package keystrokesmod.client.module.modules.combat.autostyle;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class FlickEngine {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public enum State {
        IDLE,
        TARGET_ACQUIRED,
        TRACKING,
        PRE_FLICK,
        FLICK,
        OVERSHOOT,
        RECOVERY,
        REACQUIRE,
        COOLDOWN
    }

    private State state = State.IDLE;
    private FlickTrajectory currentTrajectory = null;
    private long flickStartTime = 0;
    private long cooldownEndTime = 0;
    private boolean lastFlickLeft = false;
    private float savedYaw = 0;
    private float savedPitch = 0;
    private boolean hasSavedRotation = false;

    public State getState() { return state; }

    public boolean isFlicking() {
        return state == State.FLICK || state == State.OVERSHOOT || state == State.RECOVERY;
    }

    public void reset() {
        state = State.IDLE;
        currentTrajectory = null;
        flickStartTime = 0;
        cooldownEndTime = 0;
        hasSavedRotation = false;
    }

    public void cancelFlick() {
        if (isFlicking() && hasSavedRotation) {
            mc.thePlayer.rotationYaw = savedYaw;
            mc.thePlayer.rotationPitch = savedPitch;
        }
        state = State.TRACKING;
        currentTrajectory = null;
        hasSavedRotation = false;
    }

    public void onTargetFound() {
        if (state == State.IDLE) {
            state = State.TARGET_ACQUIRED;
        }
    }

    public void onTargetLost() {
        cancelFlick();
        state = State.IDLE;
    }

    public boolean canFlick(long nowNanos) {
        return state == State.TRACKING && nowNanos >= cooldownEndTime;
    }

    public void startFlick(
        EntityPlayer target,
        StyleProfile profile,
        double intensity,
        double movementInfluence
    ) {
        if (mc.thePlayer == null || target == null) return;

        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;

        double yawError = Math.abs(Rotation.angleDiff(currentYaw, getDesiredYaw(target)));
        double amplitude = computeAmplitude(yawError, profile, intensity, movementInfluence);
        boolean direction = computeDirection(target, profile, intensity);

        float pitchTarget = getDesiredPitch(target);
        float pitchDiff = pitchTarget - currentPitch;
        float pitchAmplitude = (float) (pitchDiff * profile.pitchInfluence + (Math.random() - 0.5) * profile.pitchMax);

        long baseDuration = (long) (90_000_000 / profile.flickSpeedMultiplier);
        double timingJitter = 1.0 + (Math.random() - 0.5) * profile.timingVariation;
        long flickDuration = (long) (baseDuration * timingJitter);

        currentTrajectory = FlickTrajectory.create(
            currentYaw, currentPitch,
            getDesiredYaw(target), pitchTarget,
            (float) amplitude, pitchAmplitude,
            direction,
            profile.overshootPercent, profile.overshootAngleMax,
            profile.flickSpeedMultiplier, profile.recoverySpeedMultiplier,
            flickDuration
        );

        savedYaw = currentYaw;
        savedPitch = currentPitch;
        hasSavedRotation = true;
        flickStartTime = System.nanoTime();
        lastFlickLeft = direction;
        state = State.FLICK;
    }

    public Rotation evaluateFlick() {
        if (currentTrajectory == null || state == State.IDLE || state == State.TRACKING) return null;

        long elapsed = System.nanoTime() - flickStartTime;

        if (state == State.FLICK && elapsed >= currentTrajectory.flickDurationNanos) {
            state = State.OVERSHOOT;
        }
        if (state == State.OVERSHOOT && elapsed >= currentTrajectory.flickDurationNanos + currentTrajectory.overshootDurationNanos) {
            state = State.RECOVERY;
        }

        Rotation rot = currentTrajectory.evaluate(elapsed);

        if (currentTrajectory.isComplete(elapsed)) {
            state = State.REACQUIRE;
            currentTrajectory = null;
            hasSavedRotation = false;
        }

        return rot;
    }

    public void onReacquire() {
        state = State.COOLDOWN;
        cooldownEndTime = System.nanoTime() + (long) (200_000_000 + Math.random() * 150_000_000);
    }

    public void onCooldownComplete() {
        if (state == State.COOLDOWN) {
            state = State.TRACKING;
        }
    }

    public void transitionToTracking() {
        if (state == State.TARGET_ACQUIRED || state == State.REACQUIRE || state == State.COOLDOWN) {
            state = State.TRACKING;
        }
    }

    private double computeAmplitude(double yawError, StyleProfile profile, double intensity, double movementInfluence) {
        double base = profile.flickAmplitudeMin +
            (profile.flickAmplitudeMax - profile.flickAmplitudeMin) * (intensity / 100.0);

        double errorBonus = Math.min(yawError * 0.3, 20.0);
        double movementBonus = movementInfluence * profile.movementInfluence * 10.0;
        double variation = 1.0 + (Math.random() - 0.5) * profile.amplitudeVariation;

        return Math.max(profile.flickAmplitudeMin, Math.min(profile.flickAmplitudeMax, (base + errorBonus + movementBonus) * variation));
    }

    private boolean computeDirection(EntityPlayer target, StyleProfile profile, double intensity) {
        MovementAnalyzer.StrafeDirection strafe = MovementAnalyzer.getPlayerStrafe();

        boolean preferLeft;
        switch (strafe) {
            case LEFT:
                preferLeft = true;
                break;
            case RIGHT:
                preferLeft = false;
                break;
            default:
                double relativeAngle = MovementAnalyzer.getRelativeAngleToTarget(target);
                preferLeft = relativeAngle > 0;
                break;
        }

        boolean variationFlip = MovementAnalyzer.shouldAlternateDirection(lastFlickLeft, profile.directionVariation);
        if (variationFlip) preferLeft = !preferLeft;

        return preferLeft;
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.55) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return (float) Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }

    public boolean getLastFlickLeft() { return lastFlickLeft; }
    public FlickTrajectory getCurrentTrajectory() { return currentTrajectory; }
    public long getFlickStartTime() { return flickStartTime; }
}
