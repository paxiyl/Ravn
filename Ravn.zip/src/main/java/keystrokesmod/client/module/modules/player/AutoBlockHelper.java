package keystrokesmod.client.module.modules.player;

import keystrokesmod.client.utils.InventoryUtils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * Stateless utility methods for AutoBlock target tracking, wall geometry,
 * placement face detection, rotation calculation, and inventory management.
 * All methods are pure and side-effect-free unless noted.
 */
public final class AutoBlockHelper {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private AutoBlockHelper() {
    }

    // ========================= TARGET TRACKING =========================

    /**
     * Find the closest valid target player within range.
     * Ignores the local player, dead entities, and out-of-range entities.
     * Requires line of sight.
     */
    public static EntityPlayer findTarget(double range) {
        if (mc.theWorld == null || mc.thePlayer == null)
            return null;

        EntityPlayer best = null;
        double bestDist = Double.MAX_VALUE;

        for (Object obj : mc.theWorld.loadedEntityList) {
            if (!(obj instanceof EntityPlayer))
                continue;
            EntityPlayer player = (EntityPlayer) obj;
            if (player == mc.thePlayer || player.isDead || player.getHealth() <= 0)
                continue;
            double dist = mc.thePlayer.getDistanceToEntity(player);
            if (dist > range || dist < 1.0D)
                continue;
            if (!mc.thePlayer.canEntityBeSeen(player))
                continue;
            if (dist < bestDist) {
                bestDist = dist;
                best = player;
            }
        }
        return best;
    }

    /**
     * Calculate horizontal velocity from position delta.
     * Call once per tick to update velocity.
     */
    public static double[] calcVelocity(EntityPlayer target, double prevX, double prevZ) {
        return new double[]{
                target.posX - prevX,
                target.posZ - prevZ
        };
    }

    /**
     * Check if target is moving (horizontal velocity above threshold).
     */
    public static boolean isMoving(double velX, double velZ, double threshold) {
        return Math.sqrt(velX * velX + velZ * velZ) > threshold;
    }

    // ========================= MOVEMENT PREDICTION =========================

    /**
     * Predict future horizontal position based on current velocity.
     */
    public static double predictX(double current, double velocity, double ticks) {
        return current + velocity * ticks;
    }

    public static double predictZ(double current, double velocity, double ticks) {
        return current + velocity * ticks;
    }

    /**
     * Predict future Y position with vertical velocity decay.
     */
    public static double predictY(EntityPlayer target, double ticks) {
        double velY = target.posY - target.prevPosY;
        return target.posY + velY * ticks * 0.5D;
    }

    // ========================= WALL GEOMETRY =========================

    /**
     * Compute the perpendicular direction to a movement vector.
     * For direction (dx, dz), perpendicular is (-dz, dx).
     */
    public static double[] perpendicular(double dx, double dz) {
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-6D)
            return new double[]{0, 0};
        return new double[]{-dz / len, dx / len};
    }

    /**
     * Calculate three horizontal wall block positions perpendicular to movement.
     * Returns [left, center, right] BlockPos array.
     */
    public static BlockPos[] calcWall(double predX, double predZ, int wallY,
                                      double velX, double velZ,
                                      double spacing, double frontDist) {
        double velLen = Math.sqrt(velX * velX + velZ * velZ);
        if (velLen < 0.01D)
            return null;

        double dirX = velX / velLen;
        double dirZ = velZ / velLen;
        double[] perp = perpendicular(dirX, dirZ);

        double frontX = predX + dirX * frontDist;
        double frontZ = predZ + dirZ * frontDist;

        BlockPos[] wall = new BlockPos[3];
        wall[0] = new BlockPos(
                (int) Math.floor(frontX - perp[0] * spacing),
                wallY,
                (int) Math.floor(frontZ - perp[1] * spacing));
        wall[1] = new BlockPos(
                (int) Math.floor(frontX),
                wallY,
                (int) Math.floor(frontZ));
        wall[2] = new BlockPos(
                (int) Math.floor(frontX + perp[0] * spacing),
                wallY,
                (int) Math.floor(frontZ + perp[1] * spacing));

        return wall;
    }

    // ========================= PLACEMENT FACE FINDING =========================

    /**
     * Find a solid support block adjacent to the target position.
     * Searches in order: below, north, south, east, west, above.
     * Returns null if no support found.
     */
    public static BlockPos findSupportBlock(BlockPos targetPos) {
        if (mc.theWorld == null)
            return null;

        EnumFacing[] searchOrder = {
                EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.SOUTH,
                EnumFacing.EAST, EnumFacing.WEST, EnumFacing.UP
        };

        for (EnumFacing facing : searchOrder) {
            BlockPos neighbor = targetPos.offset(facing);
            // Skip void positions
            if (neighbor.getY() <= 0) continue;
            Block block = mc.theWorld.getBlockState(neighbor).getBlock();
            if (block.isNormalCube() || block.isFullBlock()) {
                return neighbor;
            }
        }
        return null;
    }

    /**
     * Determine which face of the support block faces the target position.
     * Returns the face to right-click for placement.
     */
    public static EnumFacing findPlacementFace(BlockPos targetPos, BlockPos supportPos) {
        double dx = (targetPos.getX() + 0.5) - (supportPos.getX() + 0.5);
        double dy = (targetPos.getY() + 0.5) - (supportPos.getY() + 0.5);
        double dz = (targetPos.getZ() + 0.5) - (supportPos.getZ() + 0.5);

        double absDx = Math.abs(dx);
        double absDy = Math.abs(dy);
        double absDz = Math.abs(dz);

        if (absDx > absDy && absDx > absDz) {
            return dx > 0 ? EnumFacing.EAST : EnumFacing.WEST;
        } else if (absDy > absDz) {
            return dy > 0 ? EnumFacing.UP : EnumFacing.DOWN;
        } else {
            return dz > 0 ? EnumFacing.SOUTH : EnumFacing.NORTH;
        }
    }

    /**
     * Compute the precise hit vector on a placement face.
     * The hit point is on the face surface, slightly inset toward the block center.
     */
    public static Vec3 computeHitVec(BlockPos targetPos, EnumFacing face) {
        double x = targetPos.getX() + 0.5;
        double y = targetPos.getY() + 0.5;
        double z = targetPos.getZ() + 0.5;

        switch (face) {
            case DOWN:  y = targetPos.getY();       break;
            case UP:    y = targetPos.getY() + 1.0;  break;
            case NORTH: z = targetPos.getZ();         break;
            case SOUTH: z = targetPos.getZ() + 1.0;   break;
            case WEST:  x = targetPos.getX();         break;
            case EAST:  x = targetPos.getX() + 1.0;   break;
        }

        double inset = 0.499D;
        x -= face.getFrontOffsetX() * inset;
        y -= face.getFrontOffsetY() * inset;
        z -= face.getFrontOffsetZ() * inset;

        return new Vec3(x, y, z);
    }

    // ========================= ROTATION CALCULATION =========================

    /**
     * Calculate yaw and pitch to look from the player's eye position to a target Vec3.
     * Returns float[2] = {yaw, pitch} in degrees.
     */
    public static float[] calcRotation(Vec3 target) {
        double dx = target.xCoord - mc.thePlayer.posX;
        double dy = target.yCoord - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.zCoord - mc.thePlayer.posZ;

        float yaw = (float) (Math.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        float pitch = (float) (-(Math.atan2(dy, horizontalDist) * (180.0D / Math.PI)));

        yaw = MathHelper.wrapAngleTo180_float(yaw);
        pitch = MathHelper.clamp_float(pitch, -90.0F, 90.0F);

        return new float[]{yaw, pitch};
    }

    /**
     * Calculate yaw to look from the player toward a target position (horizontal only).
     */
    public static float calcYawTo(double targetX, double targetZ) {
        double dx = targetX - mc.thePlayer.posX;
        double dz = targetZ - mc.thePlayer.posZ;
        return (float) (Math.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
    }

    // ========================= VALIDATION =========================

    /**
     * Check if a block position is replaceable (air, tall grass, etc.).
     */
    public static boolean isBlockReplaceable(BlockPos pos) {
        if (mc.theWorld == null)
            return false;
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block.isReplaceable(mc.theWorld, pos);
    }

    /**
     * Check if the chunk containing the position is loaded.
     */
    public static boolean isChunkLoaded(BlockPos pos) {
        if (mc.theWorld == null)
            return false;
        return mc.theWorld.getChunkProvider().chunkExists(pos.getX() >> 4, pos.getZ() >> 4);
    }

    /**
     * Check if a position is within the player's placement reach.
     */
    public static boolean isWithinReach(BlockPos pos, double maxReach) {
        if (mc.thePlayer == null)
            return false;
        double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
        double dy = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        return dist <= maxReach;
    }

    /**
     * Calculate 3D distance from player eye to a position.
     */
    public static double distToPlayer(BlockPos pos) {
        if (mc.thePlayer == null)
            return Double.MAX_VALUE;
        double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
        double dy = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ========================= INVENTORY =========================

    /**
     * Find the first hotbar slot containing a valid block.
     * Returns -1 if no block found.
     */
    public static int findBlockInHotbar() {
        if (mc.thePlayer == null)
            return -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack != null && stack.getItem() instanceof ItemBlock
                    && InventoryUtils.isGoodBlockStack(stack)
                    && stack.stackSize > 0) {
                return slot;
            }
        }
        return -1;
    }

    /**
     * Check if the player's current held item is a valid placement block.
     */
    public static boolean isHoldingBlock() {
        if (mc.thePlayer == null)
            return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock
                && InventoryUtils.isGoodBlockStack(held);
    }

    /**
     * Get the Block that an ItemStack would place when right-clicked.
     * Returns null if the stack is not an ItemBlock.
     */
    public static Block getBlockFromStack(ItemStack stack) {
        if (stack == null || !(stack.getItem() instanceof ItemBlock))
            return null;
        return ((ItemBlock) stack.getItem()).block;
    }

    // ========================= MOVEMENT DIRECTION =========================

    /**
     * Get a human-readable direction name from velocity components.
     */
    public static String directionName(double velX, double velZ) {
        double angle = Math.toDegrees(Math.atan2(-velX, velZ));
        if (angle < 0) angle += 360;

        if (angle < 22.5 || angle >= 337.5) return "SOUTH";
        if (angle < 67.5)  return "SOUTH-WEST";
        if (angle < 112.5) return "WEST";
        if (angle < 157.5) return "NORTH-WEST";
        if (angle < 202.5) return "NORTH";
        if (angle < 247.5) return "NORTH-EAST";
        if (angle < 292.5) return "EAST";
        return "SOUTH-EAST";
    }

    /**
     * Get the movement angle in degrees (compass heading).
     */
    public static double directionDegrees(double velX, double velZ) {
        return Math.toDegrees(Math.atan2(-velX, velZ));
    }
}
