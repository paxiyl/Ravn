package keystrokesmod.client.module.modules.combat.lobohit;

import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.ModuleCategory;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.ArrayDeque;

import com.google.common.eventbus.Subscribe;

public class LoboHit extends Module {
    // --- Mode Selection ---
    public static ComboSetting<Mode> mode;
    public enum Mode { NORMAL, PREDICTIVE, ADAPTIVE }

    // --- Timing ---
    public static SliderSetting attackDelay;
    public static SliderSetting sprintResetDelay;
    public static SliderSetting comboWindow;
    public static SliderSetting kbWindow;

    // --- Sprint Reset ---
    public static ComboSetting<SprintResetMode> sprintResetMode;
    public enum SprintResetMode { NONE, W_TAP, S_TAP, SHIFT_TAP, EXHAUSTION }

    public static SliderSetting sprintResetDuration;
    public static SliderSetting sprintResetWindow;
    public static TickSetting adaptiveSprintReset;

    // --- Combo ---
    public static SliderSetting maxComboLength;
    public static SliderSetting comboResetThreshold;
    public static TickSetting adaptiveCombo;
    public static TickSetting forceComboOnGround;
    public static SliderSetting comboHealthThreshold;

    // --- Spacing ---
    public static SliderSetting optimalDistance;
    public static SliderSetting aggressiveDistance;
    public static SliderSetting defensiveDistance;
    public static SliderSetting maxDistance;
    public static TickSetting dynamicSpacing;
    public static SliderSetting spacingTolerance;

    // --- Anti-KB ---
    public static TickSetting smartAntiKB;
    public static SliderSetting kbPredictionWindow;
    public static SliderSetting kbThreshold;
    public static TickSetting preKBStrafe;

    // --- Position ---
    public static TickSetting enablePredictions;
    public static SliderSetting predictionTicks;
    public static TickSetting autoJumpReset;
    public static TickSetting jumpResetInCombo;
    public static SliderSetting jumpResetHeight;
    public static TickSetting smartJump;
    public static TickSetting smoothMovement;
    public static SliderSetting smoothFactor;

    // --- Trading ---
    public static TickSetting smartTrading;
    public static SliderSetting tradeDamageThreshold;
    public static TickSetting prioritizeCombo;

    // --- Health ---
    public static SliderSetting healthThreshold;
    public static TickSetting runBelowHealth;
    public static TickSetting shieldBash;

    // --- Debug ---
    public static TickSetting debugMode;
    public static TickSetting debugOverlay;

    // --- Engine State ---
    private final CombatState combatState = new CombatState();
    private final TargetAnalyzer targetAnalyzer = new TargetAnalyzer();
    private final SprintController sprintController = new SprintController();
    private final SpacingController spacingController = new SpacingController();
    private EntityPlayer currentTarget;
    private EntityPlayer lastTarget;
    private int attackCooldown = 0;
    private int sprintResetCooldown = 0;
    private int comboCounter = 0;
    private int missedHits = 0;
    private float lastHealth = 20;
    private boolean wasOnGround = true;
    private int ticksInCombat = 0;
    private int ticksSinceLastAttack = 0;
    private final ArrayDeque<Float> recentDistances = new ArrayDeque<>();
    private final ArrayDeque<Float> recentAngles = new ArrayDeque<>();
    private float targetLastHealth = 20;
    private boolean targetWasGrounded = true;
    private long lastAttackTime = 0;
    private int strafeTimer = 0;
    private int strafeDirection = 1;
    private boolean wasTargetHurt = false;
    private float lastTargetMotionX = 0;
    private float lastTargetMotionZ = 0;
    private float lastPlayerMotionX = 0;
    private float lastPlayerMotionZ = 0;
    private int jumpsSinceReset = 0;
    private boolean waitingForServerConfirm = false;
    private int serverConfirmTicks = 0;

    public LoboHit() {
        super("LoboHit", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Adaptive PvP Combo Controller"));

        // Mode
        this.registerSetting(mode = new ComboSetting<>("Mode", Mode.ADAPTIVE));

        // Timing
        this.registerSetting(new DescriptionSetting("--- Timing ---"));
        this.registerSetting(attackDelay = new SliderSetting("Attack Delay (ms)", 180, 0, 500, 10));
        this.registerSetting(sprintResetDelay = new SliderSetting("Sprint Reset Delay", 1, 0, 3, 1));
        this.registerSetting(comboWindow = new SliderSetting("Combo Window (ms)", 800, 200, 2000, 50));
        this.registerSetting(kbWindow = new SliderSetting("KB Window (ms)", 400, 100, 1000, 50));

        // Sprint Reset
        this.registerSetting(new DescriptionSetting("--- Sprint Reset ---"));
        this.registerSetting(sprintResetMode = new ComboSetting<>("Sprint Reset Mode", SprintResetMode.W_TAP));
        this.registerSetting(sprintResetDuration = new SliderSetting("Reset Duration", 2, 1, 5, 1));
        this.registerSetting(sprintResetWindow = new SliderSetting("Reset Window (ticks)", 4, 1, 8, 1));
        this.registerSetting(adaptiveSprintReset = new TickSetting("Adaptive Sprint Reset", true));

        // Combo
        this.registerSetting(new DescriptionSetting("--- Combo ---"));
        this.registerSetting(maxComboLength = new SliderSetting("Max Combo Length", 5, 2, 15, 1));
        this.registerSetting(comboResetThreshold = new SliderSetting("Combo Reset Threshold", 3, 1, 8, 1));
        this.registerSetting(adaptiveCombo = new TickSetting("Adaptive Combo", true));
        this.registerSetting(forceComboOnGround = new TickSetting("Force Combo On Ground", true));
        this.registerSetting(comboHealthThreshold = new SliderSetting("Combo Health Threshold", 10, 1, 20, 1));

        // Spacing
        this.registerSetting(new DescriptionSetting("--- Spacing ---"));
        this.registerSetting(optimalDistance = new SliderSetting("Optimal Distance", 3.0, 2.0, 5.0, 0.1));
        this.registerSetting(aggressiveDistance = new SliderSetting("Aggressive Distance", 2.5, 1.5, 4.0, 0.1));
        this.registerSetting(defensiveDistance = new SliderSetting("Defensive Distance", 3.5, 2.5, 6.0, 0.1));
        this.registerSetting(maxDistance = new SliderSetting("Max Distance", 4.5, 3.0, 6.0, 0.1));
        this.registerSetting(dynamicSpacing = new TickSetting("Dynamic Spacing", true));
        this.registerSetting(spacingTolerance = new SliderSetting("Spacing Tolerance", 0.5, 0.1, 2.0, 0.1));

        // Anti-KB
        this.registerSetting(new DescriptionSetting("--- Anti-KB ---"));
        this.registerSetting(smartAntiKB = new TickSetting("Smart Anti-KB", true));
        this.registerSetting(kbPredictionWindow = new SliderSetting("KB Prediction Window", 200, 50, 500, 10));
        this.registerSetting(kbThreshold = new SliderSetting("KB Threshold", 0.3, 0.1, 1.0, 0.05));
        this.registerSetting(preKBStrafe = new TickSetting("Pre-KB Strafe", true));

        // Position
        this.registerSetting(new DescriptionSetting("--- Position ---"));
        this.registerSetting(enablePredictions = new TickSetting("Enable Predictions", true));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction Ticks", 3, 1, 10, 1));
        this.registerSetting(autoJumpReset = new TickSetting("Auto Jump Reset", true));
        this.registerSetting(jumpResetInCombo = new TickSetting("Jump Reset In Combo", true));
        this.registerSetting(jumpResetHeight = new SliderSetting("Jump Reset Height", 0.42, 0.1, 1.0, 0.01));
        this.registerSetting(smartJump = new TickSetting("Smart Jump", true));
        this.registerSetting(smoothMovement = new TickSetting("Smooth Movement", true));
        this.registerSetting(smoothFactor = new SliderSetting("Smooth Factor", 0.7, 0.1, 0.95, 0.05));

        // Trading
        this.registerSetting(new DescriptionSetting("--- Trading ---"));
        this.registerSetting(smartTrading = new TickSetting("Smart Trading", true));
        this.registerSetting(tradeDamageThreshold = new SliderSetting("Trade Damage Threshold", 3.0, 1.0, 10.0, 0.5));
        this.registerSetting(prioritizeCombo = new TickSetting("Prioritize Combo", true));

        // Health
        this.registerSetting(new DescriptionSetting("--- Health ---"));
        this.registerSetting(healthThreshold = new SliderSetting("Health Threshold", 8, 2, 20, 1));
        this.registerSetting(runBelowHealth = new TickSetting("Run Below Health", true));
        this.registerSetting(shieldBash = new TickSetting("Shield Bash", false));

        // Debug
        this.registerSetting(new DescriptionSetting("--- Debug ---"));
        this.registerSetting(debugMode = new TickSetting("Debug Mode", false));
        this.registerSetting(debugOverlay = new TickSetting("Debug Overlay", false));
    }

    @Override
    public void onEnable() {
        combatState.reset();
        targetAnalyzer.reset();
        sprintController.reset();
        spacingController.reset();
        currentTarget = null;
        lastTarget = null;
        attackCooldown = 0;
        sprintResetCooldown = 0;
        comboCounter = 0;
        missedHits = 0;
        ticksInCombat = 0;
        ticksSinceLastAttack = 0;
        recentDistances.clear();
        recentAngles.clear();
        jumpsSinceReset = 0;
        waitingForServerConfirm = false;
        serverConfirmTicks = 0;
    }

    @Override
    public void onDisable() {
        combatState.reset();
        targetAnalyzer.reset();
        sprintController.reset();
        spacingController.reset();
        currentTarget = null;
        lastTarget = null;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        combatState.tick();
        ticksSinceLastAttack++;
        if (attackCooldown > 0) attackCooldown--;
        if (sprintResetCooldown > 0) sprintResetCooldown--;

        updateTarget();
        updateCombatState();

        if (currentTarget != null) {
            ticksInCombat++;
            targetAnalyzer.update(currentTarget, mc.thePlayer);
            targetAnalyzer.tickUpdate(currentTarget);
            spacingController.update(combatState, targetAnalyzer, mc.thePlayer);
            sprintController.tick(combatState);
            runDecisionEngine();
        } else {
            if (ticksInCombat > 0) {
                ticksInCombat = 0;
                comboCounter = 0;
                missedHits = 0;
            }
            combatState.setState(CombatState.State.IDLE);
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (currentTarget == null) return;

        updateStatePre();

        if (enablePredictions.getInput() && combatState.getState() != CombatState.State.IDLE) {
            handlePredictions(e);
        }

        if (smoothMovement.getInput() && combatState.getState() != CombatState.State.IDLE) {
            handleSmoothMovement(e);
        }
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isOutgoing()) {
            if (e.getPacket() instanceof C03PacketPlayer) {
                C03PacketPlayer packet = (C03PacketPlayer) e.getPacket();
                if (packet instanceof C03PacketPlayer.C05PacketPlayerLook
                    || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
                    lastPlayerMotionX = (float)(mc.thePlayer.posX - mc.thePlayer.prevPosX);
                    lastPlayerMotionZ = (float)(mc.thePlayer.posZ - mc.thePlayer.prevPosZ);
                }
            }
        }

        if (e.isIncoming() && e.getPacket() instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity packet = (S12PacketEntityVelocity) e.getPacket();
            if (packet.getEntityID() == mc.thePlayer.getEntityId()) {
                handleOwnVelocity(packet);
            }
            if (currentTarget != null && packet.getEntityID() == currentTarget.getEntityId()) {
                handleTargetVelocity(packet);
            }
        }
    }

    private void updateTarget() {
        EntityPlayer target = Targets.getTarget();
        if (target != currentTarget) {
            lastTarget = currentTarget;
            currentTarget = target;
            if (target != null) {
                targetAnalyzer.reset();
                targetLastHealth = target.getHealth();
                comboCounter = 0;
                missedHits = 0;
            } else {
                combatState.reset();
                sprintController.reset();
            }
        }

        if (currentTarget != null) {
            combatState.setTargetHealth(currentTarget.getHealth());
            combatState.setTargetHurtTime(currentTarget.hurtTime);
            combatState.setTargetGrounded(currentTarget.onGround);
            combatState.setTargetMoving(Math.abs(currentTarget.motionX) > 0.05 || Math.abs(currentTarget.motionZ) > 0.05);

            float healthDelta = targetLastHealth - currentTarget.getHealth();
            if (healthDelta > 0) {
                targetAnalyzer.onTargetHurt(currentTarget.hurtTime, healthDelta, mc.thePlayer);
                combatState.recordHealthDelta(healthDelta);
                combatState.recordHurtTime(currentTarget.hurtTime);
                waitingForServerConfirm = true;
                serverConfirmTicks = 0;
            }
            targetLastHealth = currentTarget.getHealth();

            if (currentTarget.hurtTime > 0) {
                wasTargetHurt = true;
            }
        }
    }

    private void updateCombatState() {
        if (mc.thePlayer == null) return;

        combatState.setPlayerHealth(mc.thePlayer.getHealth());
        combatState.setPlayerGrounded(mc.thePlayer.onGround);
        combatState.setPlayerAttackCooldown(ticksSinceLastAttack);
        combatState.setPlayerTicksSinceLastHit(ticksSinceLastAttack);

        if (currentTarget != null) {
            float dist = mc.thePlayer.getDistanceToEntity(currentTarget);
            combatState.setTargetDistance(dist);
            combatState.setTargetDistanceDelta(dist - combatState.getTargetDistance());
            combatState.recordDistance(dist);
        }

        combatState.setPlayerVulnerable(mc.thePlayer.onGround && mc.thePlayer.getHealth() > 4);
        combatState.setPingMs(Utils.Player.serverResponseTime());
        combatState.setTargetLocked(comboCounter > 0);

        if (waitingForServerConfirm) {
            serverConfirmTicks++;
            if (serverConfirmTicks > 10) {
                waitingForServerConfirm = false;
                combatState.setServerConfirmedCombo(true);
            }
        }

        if (comboCounter == 0) {
            combatState.setServerConfirmedCombo(false);
        }

        wasOnGround = mc.thePlayer.onGround;
    }

    private void updateStatePre() {
        if (currentTarget == null) return;

        if (combatState.getState() == CombatState.State.IDLE) {
            combatState.setState(CombatState.State.APPROACH);
        }
    }

    private void runDecisionEngine() {
        if (mc.thePlayer == null || currentTarget == null) return;

        CombatState.State newState = determineState();
        combatState.setState(newState);

        executeState(newState);
    }

    private CombatState.State determineState() {
        Minecraft mc = Minecraft.getMinecraft();
        float health = mc.thePlayer.getHealth();
        float targetHealth = currentTarget.getHealth();
        float distance = combatState.getTargetDistance();
        boolean onGround = mc.thePlayer.onGround;
        boolean targetOnGround = currentTarget.onGround;
        float distanceDelta = combatState.getTargetDistanceDelta();
        int hurtTime = currentTarget.hurtTime;
        int comboLen = comboCounter;
        float ping = combatState.getPingMs();

        if (runBelowHealth.getInput() && health < healthThreshold.getInput()) {
            return CombatState.State.DEFENSIVE;
        }

        if (health < 4 && targetHealth > health) {
            return CombatState.State.STUNNED;
        }

        if (distance > maxDistance.getInput()) {
            return CombatState.State.APPROACH;
        }

        if (comboLen >= maxComboLength.getInput()) {
            return CombatState.State.EXITING;
        }

        if (comboLen > 0) {
            if (onGround && autoJumpReset.getInput() && jumpResetInCombo.getInput() && jumpsSinceReset < 2) {
                if (targetOnGround && distance < optimalDistance.getInput() + 0.3f) {
                    return CombatState.State.JUMP_COMBO;
                }
            }

            if (onGround && targetOnGround && distance < aggressiveDistance.getInput()) {
                return CombatState.State.COMBO;
            }

            if (!onGround && !targetOnGround) {
                if (Math.abs(currentTarget.motionY) > 0.1) {
                    return CombatState.State.AIR_CONTROL;
                }
                return CombatState.State.PLANE_COMBO;
            }

            if (distance < aggressiveDistance.getInput() + 0.3f) {
                return CombatState.State.COMBO;
            }

            return CombatState.State.SPACING;
        }

        if (distance < aggressiveDistance.getInput() && attackCooldown <= 0) {
            if (onGround) {
                return CombatState.State.COMBO;
            }
            return CombatState.State.APPROACH;
        }

        if (distance < defensiveDistance.getInput()) {
            return CombatState.State.SPACING;
        }

        if (targetHealth < comboHealthThreshold.getInput() && distance < aggressiveDistance.getInput()) {
            return CombatState.State.FINISHER;
        }

        return CombatState.State.APPROACH;
    }

    private void executeState(CombatState.State state) {
        switch (state) {
            case APPROACH:
                handleApproach();
                break;
            case COMBO:
                handleCombo();
                break;
            case FINISHER:
                handleFinisher();
                break;
            case DEFENSIVE:
                handleDefensive();
                break;
            case SPACING:
                handleSpacing();
                break;
            case KB_RECOVERY:
                handleKBRecovery();
                break;
            case JUMP_COMBO:
                handleJumpCombo();
                break;
            case PLANE_COMBO:
                handlePlaneCombo();
                break;
            case AIR_CONTROL:
                handleAirControl();
                break;
            case TRADING:
                handleTrading();
                break;
            case STUNNED:
                handleStunned();
                break;
            case EXITING:
                handleExiting();
                break;
            default:
                break;
        }
    }

    // --- State Handlers ---

    private void handleApproach() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        float distance = combatState.getTargetDistance();
        boolean onGround = mc.thePlayer.onGround;

        if (onGround && smartJump.getInput() && distance > optimalDistance.getInput() + 0.5f) {
            mc.thePlayer.jump();
        }

        if (onGround && sprintController.isSprintActive() && distance < optimalDistance.getInput() + 1.0f && sprintResetCooldown <= 0) {
            queueSprintReset();
        }
    }

    private void handleCombo() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        float health = mc.thePlayer.getHealth();
        int hurtTime = currentTarget.hurtTime;

        if (distance > maxDistance.getInput()) {
            return;
        }

        if (hurtTime > 0 && hurtTime < 5) {
            return;
        }

        performAttack();

        comboCounter++;
        missedHits = 0;
        combatState.setLastHitRegistered(true);

        if (sprintResetMode.getMode() != SprintResetMode.NONE && sprintResetCooldown <= 0) {
            queueSprintReset();
        }

        if (adaptiveCombo.getInput()) {
            adaptCombo();
        }

        if (autoJumpReset.getInput() && onGround() && shouldJumpReset()) {
            mc.thePlayer.jump();
            jumpsSinceReset++;
        }
    }

    private void handleFinisher() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        int hurtTime = currentTarget.hurtTime;

        if (distance > maxDistance.getInput()) return;
        if (hurtTime > 0 && hurtTime < 3) return;

        performAttack();
        comboCounter++;

        if (sprintResetMode.getMode() != SprintResetMode.NONE) {
            queueSprintReset();
        }
    }

    private void handleDefensive() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (mc.thePlayer.onGround && mc.thePlayer.getHealth() < healthThreshold.getInput()) {
            float distance = combatState.getTargetDistance();
            if (distance < defensiveDistance.getInput()) {
                mc.thePlayer.setSprinting(false);
            }
        }
    }

    private void handleSpacing() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        SpacingController.MovementInput input = spacingController.calculateMovementInput(mc.thePlayer, targetAnalyzer, combatState);

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        int hurtTime = currentTarget.hurtTime;

        if (distance > maxDistance.getInput()) return;

        if (input.forward != 0 || input.strafe != 0) {
            applyMovementInput(input);
        }

        if (distance < aggressiveDistance.getInput() && attackCooldown <= 0 && hurtTime <= 0) {
            performAttack();
            comboCounter++;
            queueSprintReset();
        }
    }

    private void handleKBRecovery() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (preKBStrafe.getInput()) {
            strafeTimer++;
            if (strafeTimer > 3) {
                strafeDirection *= -1;
                strafeTimer = 0;
            }
        }
    }

    private void handleJumpCombo() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        if (distance > maxDistance.getInput()) return;

        performAttack();
        comboCounter++;

        if (mc.thePlayer.onGround) {
            mc.thePlayer.jump();
            jumpsSinceReset++;
        }

        queueSprintReset();
    }

    private void handlePlaneCombo() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        if (distance > maxDistance.getInput()) return;

        if (currentTarget.hurtTime > 0 && currentTarget.hurtTime < 3) return;

        performAttack();
        comboCounter++;
        queueSprintReset();
    }

    private void handleAirControl() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        float distance = combatState.getTargetDistance();
        if (distance > maxDistance.getInput()) return;

        performAttack();
        comboCounter++;
        queueSprintReset();
    }

    private void handleTrading() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        if (attackCooldown > 0) return;

        performAttack();
        comboCounter++;
        queueSprintReset();
    }

    private void handleStunned() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (mc.thePlayer.onGround) {
            mc.thePlayer.setSprinting(false);
        }
    }

    private void handleExiting() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        if (mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }
        comboCounter = 0;
        combatState.setState(CombatState.State.APPROACH);
    }

    // --- Actions ---

    private void performAttack() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        mc.playerController.attackEntity(mc.thePlayer, currentTarget);
        mc.thePlayer.swingItem();

        attackCooldown = (int)(attackDelay.getInput() / 50.0);
        ticksSinceLastAttack = 0;
        lastAttackTime = System.currentTimeMillis();
    }

    private void queueSprintReset() {
        SprintResetMode sprintMode = sprintResetMode.getMode();
        int duration = (int) sprintResetDuration.getInput();

        switch (sprintMode) {
            case W_TAP:
                sprintController.queueWTap(duration);
                break;
            case S_TAP:
                sprintController.queueSTap(duration);
                break;
            case SHIFT_TAP:
                sprintController.queueShiftTap(duration);
                break;
            case EXHAUSTION:
                sprintController.onSprintReset(duration);
                break;
            default:
                break;
        }

        sprintResetCooldown = (int) sprintResetWindow.getInput();
    }

    private void adaptCombo() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        float playerHealth = mc.thePlayer.getHealth();
        float targetHealth = currentTarget.getHealth();
        float distance = combatState.getTargetDistance();

        if (playerHealth < targetHealth * 0.5f && comboCounter > 2) {
            combatState.setPlayerVulnerable(true);
        }

        if (distance < aggressiveDistance.getInput() && targetHealth < comboHealthThreshold.getInput()) {
            attackDelay.setValue(Math.max(50, attackDelay.getInput() - 10));
        }
    }

    private boolean shouldJumpReset() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return false;

        if (jumpsSinceReset >= 2) return false;

        float distance = combatState.getTargetDistance();
        boolean targetGrounded = currentTarget.onGround;

        return targetGrounded && distance < optimalDistance.getInput() + 0.3f;
    }

    private boolean onGround() {
        return mc.thePlayer != null && mc.thePlayer.onGround;
    }

    private void handlePredictions(UpdateEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        float pingTicks = combatState.getPingMs() / 50.0f;
        Vec3 predicted = targetAnalyzer.getPredictedPosition((int)predictionTicks.getInput() + (int)pingTicks);

        if (predicted != null) {
            float dx = (float)(predicted.xCoord - currentTarget.posX);
            float dy = (float)(predicted.yCoord - currentTarget.posY);
            float dz = (float)(predicted.zCoord - currentTarget.posZ);
            float dist = MathHelper.sqrt_float(dx * dx + dy * dy + dz * dz);

            if (dist < 0.5f) {
                combatState.setTargetPositionConfidence(0.9f);
            } else if (dist < 1.5f) {
                combatState.setTargetPositionConfidence(0.6f);
            } else {
                combatState.setTargetPositionConfidence(0.3f);
            }
        }
    }

    private void handleSmoothMovement(UpdateEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return;

        float factor = smoothFactor.getInput();
        float targetYaw = getTargetYaw();

        float yawDiff = targetYaw - mc.thePlayer.rotationYaw;
        while (yawDiff > 180) yawDiff -= 360;
        while (yawDiff < -180) yawDiff += 360;

        if (Math.abs(yawDiff) > 0.5f) {
            mc.thePlayer.rotationYaw += yawDiff * (1.0f - factor);
        }
    }

    private float getTargetYaw() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || currentTarget == null) return mc.thePlayer.rotationYaw;

        double dx = currentTarget.posX - mc.thePlayer.posX;
        double dz = currentTarget.posZ - mc.thePlayer.posZ;
        return (float)(Math.toDegrees(Math.atan2(-dx, dz)));
    }

    private void applyMovementInput(SpacingController.MovementInput input) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        float yaw = mc.thePlayer.rotationYaw;
        float forward = input.forward;
        float strafe = input.strafe;

        float cos = (float)Math.cos(Math.toRadians(yaw));
        float sin = (float)Math.sin(Math.toRadians(yaw));

        mc.thePlayer.motionX = (forward * -sin + strafe * cos) * 0.26;
        mc.thePlayer.motionZ = (forward * cos + strafe * sin) * 0.26;

        if (input.jump && mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }
    }

    private void handleOwnVelocity(S12PacketEntityVelocity packet) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        float vx = packet.motionX / 8000.0f;
        float vy = packet.motionY / 8000.0f;
        float vz = packet.motionZ / 8000.0f;

        float kbMagnitude = MathHelper.sqrt_float(vx * vx + vy * vy + vz * vz);
        if (kbMagnitude > kbThreshold.getInput()) {
            combatState.setKbEstimate(kbMagnitude);
            combatState.setState(CombatState.State.KB_RECOVERY);
        }
    }

    private void handleTargetVelocity(S12PacketEntityVelocity packet) {
        if (currentTarget == null) return;

        float vx = packet.motionX / 8000.0f;
        float vy = packet.motionY / 8000.0f;
        float vz = packet.motionZ / 8000.0f;

        lastTargetMotionX = vx;
        lastTargetMotionZ = vz;

        float kbMagnitude = MathHelper.sqrt_float(vx * vx + vy * vy + vz * vz);
        if (kbMagnitude > kbThreshold.getInput()) {
            combatState.setKbEstimate(kbMagnitude);
        }
    }

    public CombatState getCombatState() {
        return combatState;
    }

    public TargetAnalyzer getTargetAnalyzer() {
        return targetAnalyzer;
    }

    public SprintController getSprintController() {
        return sprintController;
    }

    public SpacingController getSpacingController() {
        return spacingController;
    }

    public EntityPlayer getCurrentTarget() {
        return currentTarget;
    }

    public int getComboCounter() {
        return comboCounter;
    }

    public int getMissedHits() {
        return missedHits;
    }
}
