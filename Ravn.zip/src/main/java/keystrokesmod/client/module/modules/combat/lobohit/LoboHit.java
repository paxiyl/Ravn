package keystrokesmod.client.module.modules.combat.lobohit;

import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.MathHelper;

import com.google.common.eventbus.Subscribe;

public class LoboHit extends Module {

    public static ComboSetting<CorrectionStrength> correctionStrength;
    public enum CorrectionStrength { LOW, MEDIUM, HIGH }

    public static ComboSetting<SprintResetMode> sprintResetMode;
    public enum SprintResetMode { W_TAP, S_TAP, NONE }

    public static TickSetting debug;

    private final CombatState combatState = new CombatState();
    private final TargetAnalyzer targetAnalyzer = new TargetAnalyzer();
    private final SprintController sprintController = new SprintController();
    private final SpacingController spacingController = new SpacingController();

    private EntityPlayer currentTarget = null;
    private boolean trackingCombat = false;
    private int ticksSincePlayerSwing = 999;
    private float prevDistance = 0;

    public LoboHit() {
        super("LoboHit", Module.ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Adaptive combo-spacing assistant"));
        this.registerSetting(new DescriptionSetting("Player controls aim & attack."));
        this.registerSetting(correctionStrength = new ComboSetting<>("Correction", CorrectionStrength.MEDIUM));
        this.registerSetting(sprintResetMode = new ComboSetting<>("Sprint Reset", SprintResetMode.W_TAP));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public void onEnable() {
        combatState.reset();
        targetAnalyzer.reset();
        sprintController.reset();
        spacingController.reset();
        currentTarget = null;
        trackingCombat = false;
        ticksSincePlayerSwing = 999;
    }

    @Override
    public void onDisable() {
        combatState.reset();
        targetAnalyzer.reset();
        sprintController.reset();
        spacingController.reset();
        currentTarget = null;
        trackingCombat = false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) {
            mc.thePlayer.setSneaking(false);
        }
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        combatState.tick();
        ticksSincePlayerSwing++;

        detectTarget();
        updateCombatState();
        analyze();

        if (trackingCombat && currentTarget != null) {
            runSpacingEngine();
        } else {
            combatState.setState(CombatState.State.IDLE);
        }

        sprintController.tick();
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isOutgoing() && e.getPacket() instanceof C0APacketAnimation) {
            onPlayerSwung();
        }

        if (e.isIncoming() && e.getPacket() instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity pkt = (S12PacketEntityVelocity) e.getPacket();
            if (pkt.getEntityID() == mc.thePlayer.getEntityId()) {
                float mag = MathHelper.sqrt_float(
                    pkt.motionX * pkt.motionX + pkt.motionY * pkt.motionY + pkt.motionZ * pkt.motionZ
                ) / 8000.0f;
                combatState.setPlayerWasHit(true);
                combatState.setPlayerKbReceived(mag);
            }
            if (currentTarget != null && pkt.getEntityID() == currentTarget.getEntityId()) {
                float mag = MathHelper.sqrt_float(
                    pkt.motionX * pkt.motionX + pkt.motionY * pkt.motionY + pkt.motionZ * pkt.motionZ
                ) / 8000.0f;
                combatState.setRecentKnockback(mag);
                targetAnalyzer.recordKnockback(mag);
            }
        }
    }

    private void detectTarget() {
        EntityPlayer target = Targets.getTarget();
        if (target != currentTarget) {
            if (target != null) {
                if (currentTarget == null) {
                    targetAnalyzer.reset();
                    trackingCombat = false;
                }
                currentTarget = target;
            } else {
                currentTarget = null;
                trackingCombat = false;
                combatState.setState(CombatState.State.IDLE);
            }
        }
    }

    private void updateCombatState() {
        if (mc.thePlayer == null) return;

        combatState.setPlayerHealth(mc.thePlayer.getHealth());
        combatState.setPlayerGrounded(mc.thePlayer.onGround);
        combatState.setPlayerMoving(
            Math.abs(mc.thePlayer.motionX) > 0.03 || Math.abs(mc.thePlayer.motionZ) > 0.03
        );

        float playerSpeed = MathHelper.sqrt_float(
            (float)(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ)
        ) * 20;
        combatState.setPlayerVelocity(playerSpeed);

        try {
            combatState.setPingMs(mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime());
        } catch (Exception ignored) {
            combatState.setPingMs(50);
        }

        if (currentTarget != null) {
            float dist = mc.thePlayer.getDistanceToEntity(currentTarget);
            combatState.setCurrentDistance(dist);
            combatState.setDistanceDelta(dist - prevDistance);
            prevDistance = dist;

            combatState.setTargetHealth(currentTarget.getHealth());
            combatState.setTargetGrounded(currentTarget.onGround);
            combatState.setTargetMoving(
                Math.abs(currentTarget.motionX) > 0.03 || Math.abs(currentTarget.motionZ) > 0.03
            );

            float targetSpeed = MathHelper.sqrt_float(
                (float)(currentTarget.motionX * currentTarget.motionX + currentTarget.motionZ * currentTarget.motionZ)
            ) * 20;
            combatState.setTargetVelocity(targetSpeed);
            combatState.setRelativeVelocity(targetSpeed - playerSpeed);
        }
    }

    private void analyze() {
        if (currentTarget == null) return;

        targetAnalyzer.update(currentTarget);
        targetAnalyzer.tickUpdate(currentTarget);

        combatState.setEstimatedKnockback(targetAnalyzer.getAverageKnockback());

        if (targetAnalyzer.getExtrapolatedPosition() != null) {
            float confidence = 1.0f;
            if (targetAnalyzer.isTargetChangedDirection()) confidence *= 0.4f;
            confidence *= (1.0f - combatState.getSmoothedPing() / 600.0f);
            combatState.setPredictionConfidence(confidence);
        } else {
            combatState.setPredictionConfidence(0.3f);
        }
    }

    private void runSpacingEngine() {
        if (mc.thePlayer == null || currentTarget == null) return;

        if (combatState.getState() == CombatState.State.IDLE) {
            combatState.setState(CombatState.State.COMBAT_DETECTED);
        }

        if (ticksSincePlayerSwing < 5) {
            combatState.setState(CombatState.State.POST_HIT);
        } else if (combatState.getState() == CombatState.State.POST_HIT && combatState.getStateTicks() > 8) {
            combatState.setState(CombatState.State.SPACING_CONTROL);
        } else if (combatState.getState() == CombatState.State.COMBAT_DETECTED && combatState.getStateTicks() > 3) {
            combatState.setState(CombatState.State.FOLLOW_TARGET);
        } else if (combatState.getState() == CombatState.State.FOLLOW_TARGET) {
            combatState.setState(CombatState.State.SPACING_CONTROL);
        }

        spacingController.update(combatState, targetAnalyzer);
        CombatState.SpacingDecision decision = spacingController.decide(combatState, targetAnalyzer);
        combatState.setDecision(decision);

        applySubtleCorrection(decision);
        decideSprintReset(decision);
    }

    private void applySubtleCorrection(CombatState.SpacingDecision decision) {
        if (mc.thePlayer == null || decision == CombatState.SpacingDecision.MAINTAIN) return;

        float strength = getCorrectionMultiplier();
        float forward = spacingController.getForwardAdjustment(decision) * strength;
        if (Math.abs(forward) < 0.02f) return;

        float yaw = mc.thePlayer.rotationYaw;
        mc.thePlayer.motionX += -Math.sin(Math.toRadians(yaw)) * forward * 0.06;
        mc.thePlayer.motionZ += Math.cos(Math.toRadians(yaw)) * forward * 0.06;
    }

    private void decideSprintReset(CombatState.SpacingDecision decision) {
        if (sprintController.isTechniqueActive()) return;

        SprintResetMode mode = sprintResetMode.getMode();
        if (mode == SprintResetMode.NONE) return;

        float error = combatState.getCurrentDistance() - spacingController.getCurrentIdealDistance();

        boolean justHit = ticksSincePlayerSwing < 3;
        boolean playerOvershooting = combatState.getPlayerVelocity() > 3.0f && error < 0.3f;

        if (justHit && playerOvershooting) {
            if (mode == SprintResetMode.S_TAP) {
                sprintController.requestTechnique(SprintController.Technique.S_TAP, 2);
            } else {
                sprintController.requestTechnique(SprintController.Technique.W_TAP, 1);
            }
            return;
        }

        if (decision == CombatState.SpacingDecision.BACK_OFF && combatState.getPlayerVelocity() > 3.0f) {
            sprintController.requestSprintReset();
        }

        if (decision == CombatState.SpacingDecision.BACK_OFF && error < -0.4f) {
            if (mode == SprintResetMode.S_TAP) {
                sprintController.requestTechnique(SprintController.Technique.S_TAP, 2);
            } else {
                sprintController.requestTechnique(SprintController.Technique.W_TAP, 1);
            }
        } else if (decision == CombatState.SpacingDecision.CLOSE && error > 0.5f) {
            sprintController.requestTechnique(SprintController.Technique.W_TAP, 1);
        }
    }

    private void onPlayerSwung() {
        ticksSincePlayerSwing = 0;
        if (currentTarget != null) {
            trackingCombat = true;
            combatState.setLastHitTimestamp(System.currentTimeMillis());
            combatState.resetTicksSinceLastHit();
            combatState.setCurrentDistance(mc.thePlayer.getDistanceToEntity(currentTarget));
        }
    }

    private float getCorrectionMultiplier() {
        switch (correctionStrength.getMode()) {
            case LOW: return 0.5f;
            case HIGH: return 1.2f;
            default: return 0.85f;
        }
    }

    public CombatState getCombatState() { return combatState; }
    public TargetAnalyzer getTargetAnalyzer() { return targetAnalyzer; }
    public SpacingController getSpacingController() { return spacingController; }
    public SprintController getSprintController() { return sprintController; }
    public EntityPlayer getCurrentTarget() { return currentTarget; }
}
