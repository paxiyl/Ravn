package keystrokesmod.client.module.modules.world;

import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import com.google.common.eventbus.Subscribe;

public class LegitTelly extends Module {

    public static SliderSetting clickDelay;
    public static TickSetting autoSwap;
    public static TickSetting antiSway;

    private boolean running = false;
    private int cyclePhase = 0;
    private float baseYaw = 0;
    private int setupTick = 0;

    private double antiSwayLane = 0;
    private float antiSwayYawOffset = 0;
    private boolean antiSwayTapUsed = false;

    private long lastClickTime = 0;
    private long lastPlaceTime = 0;
    private boolean useHeld = false;

    private float scriptedYaw = 0;
    private float scriptedPitch = 0;
    private float targetYaw = 0;
    private float targetPitch = 0;
    private boolean rotationActive = false;

    private static final float[] YAW_CURVE = {
        91.68f, 98.88f, 78.94f, 37.45f, 1.61f, -21.69f, -33.98f,
        -35.80f, -34.64f, -33.85f, -33.06f, -31.55f, -29.26f, -26.65f,
        -24.19f, -21.07f, -18.84f, -17.06f, -8.87f, 2.61f, 41.94f
    };

    private static final float[] PITCH_CURVE = {
        64.31f, 59.95f, 60.57f, 61.46f, 60.64f, 58.89f, 56.91f,
        56.63f, 58.65f, 61.63f, 64.20f, 66.74f, 68.69f, 70.64f,
        73.01f, 75.37f, 77.46f, 78.56f, 78.90f, 77.22f, 72.25f
    };

    private static final float[] FORWARD_CURVE = {
        1.0f, 1.0f, 0.0f, 0.0f, -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f
    };

    private static final float[] STRAFE_CURVE = {
        -1.0f, -1.0f, -1.0f, -1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, -1.0f, -1.0f, -1.0f, -1.0f
    };

    public LegitTelly() {
        super("LegitTelly", ModuleCategory.world);
        this.registerSetting(new DescriptionSetting("Automated telly bridging"));
        this.registerSetting(new DescriptionSetting("By NeverBeBanned (open source)"));
        this.registerSetting(clickDelay = new SliderSetting("Click delay (ms)", 50, 20, 100, 5));
        this.registerSetting(autoSwap = new TickSetting("Auto swap blocks", true));
        this.registerSetting(antiSway = new TickSetting("Anti-sway", true));
    }

    @Override
    public void onEnable() {
        running = false;
        cyclePhase = 0;
        setupTick = 0;
        useHeld = false;
        rotationActive = false;
    }

    @Override
    public void onDisable() {
        running = false;
        useHeld = false;
        rotationActive = false;
        if (mc.thePlayer != null) {
            mc.thePlayer.setSneaking(false);
        }
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (!running) {
            if (mc.thePlayer.isSneaking() && isLookingDown() && isHoldingBlock() && isAtEdge()) {
                startAutomation();
            }
            return;
        }

        if (!isHoldingBlock()) {
            stopAutomation();
            return;
        }

        if (mc.thePlayer.fallDistance > 3.0f) {
            stopAutomation();
            return;
        }

        if (autoSwap.isToggled()) {
            handleAutoSwap();
        }

        if (antiSway.isToggled()) {
            applyAntiSway();
        }

        executeCycle();
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isIncoming() && e.getPacket() instanceof S08PacketPlayerPosLook) {
            if (running) {
                stopAutomation();
            }
        }

        if (e.isOutgoing() && e.getPacket() instanceof C0APacketAnimation) {
            lastClickTime = System.currentTimeMillis();
        }
    }

    private void startAutomation() {
        if (!isYawAligned(mc.thePlayer.rotationYaw)) return;

        baseYaw = mc.thePlayer.rotationYaw;
        int[] travel = travelDirectionFromYaw(baseYaw);
        double pos = travel[0] != 0 ? mc.thePlayer.posX : mc.thePlayer.posZ;
        antiSwayLane = pos;
        antiSwayYawOffset = 0;
        antiSwayTapUsed = false;

        running = true;
        setupTick = 0;
        cyclePhase = 19;
        scriptedYaw = baseYaw;
        scriptedPitch = mc.thePlayer.rotationPitch;
    }

    private void stopAutomation() {
        running = false;
        useHeld = false;
        rotationActive = false;
        mc.thePlayer.setSneaking(false);
    }

    private void executeCycle() {
        if (setupTick >= 0 && setupTick < 12) {
            executeSetup();
            return;
        }

        if (setupTick >= 12) {
            setupTick = -1;
            cyclePhase = 19;
        }

        int phase = cyclePhase;
        float forward = FORWARD_CURVE[phase];
        float strafe = STRAFE_CURVE[phase];
        boolean jumping = phase >= 1 && phase <= 19;
        boolean sprinting = phase == 0 || phase == 1;
        boolean use = phase >= 7;

        applyMovement(forward, strafe, jumping, sprinting);

        long now = System.currentTimeMillis();
        if (use && now - lastPlaceTime > (long) clickDelay.getInput()) {
            placeBlock();
            lastPlaceTime = now;
        }

        int nextPhase = (phase + 1) % YAW_CURVE.length;
        targetYaw = baseYaw + YAW_CURVE[nextPhase];
        targetPitch = PITCH_CURVE[nextPhase];
        rotationActive = true;

        cyclePhase = nextPhase;
    }

    private void executeSetup() {
        applyMovement(-1.0f, -1.0f, setupTick >= 6, false);

        if (setupTick == 11) {
            targetYaw = baseYaw + YAW_CURVE[19];
            targetPitch = PITCH_CURVE[19];
        } else {
            targetYaw = baseYaw;
            targetPitch = 74.52f;
        }
        rotationActive = true;
        setupTick++;
    }

    private void applyMovement(float forward, float strafe, boolean jump, boolean sprint) {
        if (mc.thePlayer == null) return;

        mc.thePlayer.moveForward = forward;
        mc.thePlayer.moveStrafing = strafe;

        if (jump && mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }

        mc.thePlayer.setSprinting(sprint);
    }

    private void applyRotation() {
        if (!rotationActive || mc.thePlayer == null) return;

        float yaw = mc.thePlayer.rotationYaw;
        float pitch = mc.thePlayer.rotationPitch;

        float yawDiff = MathHelper.wrapAngleTo180_float(targetYaw - yaw);
        float pitchDiff = targetPitch - pitch;

        float step = 8.0f;
        yaw += MathHelper.clamp_float(yawDiff, -step, step);
        pitch += MathHelper.clamp_float(pitchDiff, -step, step);

        mc.thePlayer.rotationYaw = yaw;
        mc.thePlayer.rotationPitch = MathHelper.clamp_float(pitch, -90, 90);

        scriptedYaw = yaw;
        scriptedPitch = pitch;
    }

    private void placeBlock() {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        BlockPos pos = getPlacePosition();
        if (pos == null) return;

        EnumFacing facing = getPlaceFacing(pos);
        if (facing == null) return;

        mc.thePlayer.sendQueue.addToSendQueue(
            new C08PacketPlayerBlockPlacement(pos, facing.getIndex(), mc.thePlayer.getHeldItem(), 0, 0.5f, 0)
        );
    }

    private BlockPos getPlacePosition() {
        if (mc.thePlayer == null) return null;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 look = mc.thePlayer.getLook(1.0f);
        Vec3 reach = eyes.addVector(look.xCoord * 4.5, look.yCoord * 4.5, look.zCoord * 4.5);

        net.minecraft.util.MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyes, reach, false);
        if (mop == null || mop.getBlockPos() == null) return null;

        BlockPos hit = mop.getBlockPos();
        if (mc.theWorld.getBlockState(hit).getBlock() != Blocks.air) {
            return hit.offset(mop.sideHit);
        }
        return hit;
    }

    private EnumFacing getPlaceFacing(BlockPos pos) {
        if (mc.thePlayer == null) return null;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        double bestDist = Double.MAX_VALUE;
        EnumFacing bestFace = null;

        for (EnumFacing face : EnumFacing.values()) {
            BlockPos neighbor = pos.offset(face);
            if (!mc.theWorld.getBlockState(neighbor).getBlock().isFullBlock()) continue;

            Vec3 hitVec = new Vec3(
                neighbor.getX() + 0.5 + face.getFrontOffsetX() * 0.5,
                neighbor.getY() + 0.5 + face.getFrontOffsetY() * 0.5,
                neighbor.getZ() + 0.5 + face.getFrontOffsetZ() * 0.5
            );
            double dist = eyes.distanceTo(hitVec);
            if (dist < bestDist) {
                bestDist = dist;
                bestFace = face.getOpposite();
            }
        }
        return bestFace;
    }

    private void handleAutoSwap() {
        if (mc.thePlayer == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        int heldCount = (held != null && held.getItem() instanceof ItemBlock) ? held.stackSize : 0;

        if (heldCount > 5) return;

        int bestSlot = -1;
        int bestSize = heldCount;
        for (int slot = 0; slot <= 8; slot++) {
            if (slot == mc.thePlayer.inventory.currentItem) continue;
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack == null || !(stack.getItem() instanceof ItemBlock)) continue;
            if (stack.stackSize > bestSize) {
                bestSize = stack.stackSize;
                bestSlot = slot;
            }
        }

        if (bestSlot != -1) {
            mc.thePlayer.inventory.currentItem = bestSlot;
        }
    }

    private void applyAntiSway() {
        if (mc.thePlayer == null || !running) return;

        int[] travel = travelDirectionFromYaw(baseYaw);
        double currentPos = travel[0] != 0 ? mc.thePlayer.posX : mc.thePlayer.posZ;
        double laneCenter = antiSwayLane;
        double deviation = currentPos - laneCenter;

        double threshold = 0.15;
        if (Math.abs(deviation) > threshold && !antiSwayTapUsed) {
            antiSwayYawOffset = (float) MathHelper.clamp_double(deviation * 2.0, -5.0, 5.0);
            antiSwayTapUsed = true;
        }

        if (Math.abs(deviation) < 0.05) {
            antiSwayYawOffset *= 0.8f;
            if (Math.abs(antiSwayYawOffset) < 0.1f) {
                antiSwayYawOffset = 0;
                antiSwayTapUsed = false;
            }
        }
    }

    private boolean isLookingDown() {
        return mc.thePlayer != null && mc.thePlayer.rotationPitch >= 60.0f;
    }

    private boolean isHoldingBlock() {
        if (mc.thePlayer == null) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock;
    }

    private boolean isAtEdge() {
        if (mc.thePlayer == null) return false;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 look = mc.thePlayer.getLook(1.0f);
        Vec3 down = new Vec3(0, -1, 0);
        Vec3 reach = eyes.addVector(look.xCoord * 3, -2.5, look.zCoord * 3);

        net.minecraft.util.MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyes, reach, false);
        if (mop == null) return false;

        BlockPos pos = mop.getBlockPos();
        return mc.theWorld.getBlockState(pos).getBlock() != Blocks.air;
    }

    private boolean isYawAligned(float yaw) {
        float nearestDiagonal = Math.round((yaw - 45.0f) / 90.0f) * 90.0f + 45.0f;
        return Math.abs(MathHelper.wrapAngleTo180_float(yaw - nearestDiagonal)) <= 2.0f;
    }

    private int[] travelDirectionFromYaw(float yaw) {
        double radians = Math.toRadians(yaw);
        double rawX = Math.sin(radians) - Math.cos(radians);
        double rawZ = -Math.cos(radians) - Math.sin(radians);
        if (Math.abs(rawX) >= Math.abs(rawZ)) return new int[]{rawX >= 0 ? 1 : -1, 0};
        return new int[]{0, rawZ >= 0 ? 1 : -1};
    }
}
