package keystrokesmod.client.module.modules.world;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import com.google.common.eventbus.Subscribe;

public class LegitTelly extends Module {

    public static SliderSetting activationDelay;
    public static TickSetting autoSwap;

    private boolean armed = false;
    private boolean running = false;
    private long activatePromptAt = 0;
    private int setupTick = -1;
    private int cyclePhase = 19;
    private float baseYaw = 0;
    private int travelX = 0;
    private int travelZ = 0;

    private double antiSwayLane = 0;
    private float antiSwayYawOffset = 0;
    private boolean antiSwayTapUsed = false;

    private float scriptedYaw = 0;
    private float scriptedPitch = 0;

    private boolean rotationActive = false;
    private long rotationStartedAt = 0;
    private long rotationDuration = 50;
    private float rotationStartYaw = 0;
    private float rotationStartPitch = 0;
    private float rotationTargetYaw = 0;
    private float rotationTargetPitch = 0;
    private int rotationStepCounter = 0;

    private boolean useWindow = false;
    private BlockPos lastSupportPos = null;
    private int lastSupportFace = -1;
    private BlockPos lastPlacedPos = null;
    private long lastFreezeCheck = 0;

    private static final double SENSITIVITY_QUANTUM = 0.03404715;
    private static final int[] YAW_NUDGE_PATTERN = {0, 1, -1, 2, -2};

    private static final float[] YAW_CURVE = {
        91.68f, 98.88f, 78.94f, 37.45f, 1.61f, -21.69f, -33.98f,
        -35.80f, -34.64f, -33.85f, -33.06f, -31.55f, -29.26f, -26.65f,
        -24.19f, -21.07f, -18.84f, -17.06f, -8.87f, 2.61f, 41.94f
    };

    private static final float[] PITCH_CURVE = {
        64.31f, 59.95f, 60.57f, 61.46f, 60.64f, 58.89f, 56.91f,
        56.63f, 58.65f, 61.63f, 64.20f, 66.74f, 68.69f, 70.64f,
        73.01f, 75.37f, 77.46f, 78.56f, 78.90f, 77.22f, 72.25f
    };

    private static final float[] FORWARD_CURVE = {
        1.0f, 1.0f, 0.0f, 0.0f, -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f
    };

    private static final float[] STRAFE_CURVE = {
        -1.0f, -1.0f, -1.0f, -1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, -1.0f, -1.0f, -1.0f, -1.0f
    };

    public LegitTelly() {
        super("LegitTelly", ModuleCategory.world);
        this.registerSetting(new DescriptionSetting("Automated telly bridging"));
        this.registerSetting(new DescriptionSetting("By NeverBeBanned (open source)"));
        this.registerSetting(activationDelay = new SliderSetting("Activate delay (ms)", 1000, 500, 2000, 50));
        this.registerSetting(autoSwap = new TickSetting("Auto swap blocks", true));
    }

    @Override
    public void onEnable() {
        armed = true;
        running = false;
        activatePromptAt = 0;
        setupTick = 0;
        cyclePhase = 19;
        rotationActive = false;
        lastFreezeCheck = 0;
        useWindow = false;
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;
    }

    @Override
    public void onDisable() {
        stopAutomation(false);
    }

    // TickEvent: activation prompt + safety checks only
    // Fires AFTER movement physics (onUpdateWalkingPlayer line 109)
    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (running) {
            long now = System.currentTimeMillis();
            if (lastFreezeCheck != 0 && now - lastFreezeCheck > 300) {
                stopAutomation(true);
                return;
            }
            lastFreezeCheck = now;

            if (mc.thePlayer.fallDistance > 7.0f) {
                stopAutomation(true);
                return;
            }

            if (!isHoldingBlock()) {
                stopAutomation(true);
                return;
            }

            if (autoSwap.isToggled()) {
                handleAutoSwap();
            }

            mc.gameSettings.keyBindAttack.pressed = false;
        } else if (armed) {
            updateActivationPrompt();
        }
    }

    // LivingUpdateEvent: cycle logic, rotation, movement, placement
    // Fires BEFORE movement physics (super.onLivingUpdate at line 335 of mixin)
    // AFTER keybind read (movementInput.updatePlayerMoveState at line 239)
    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof LivingEvent.LivingUpdateEvent)) return;
        if (mc.thePlayer == null) return;

        if (running) {
            mc.gameSettings.keyBindSneak.pressed = false;
            mc.thePlayer.setSneaking(false);

            applySmoothedRotation();
            cycleTick();
        } else if (armed) {
            updateActivationPrompt();
        }
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isIncoming() && e.getPacket() instanceof S08PacketPlayerPosLook) {
            if (running) {
                stopAutomation(true);
            }
        }
    }

    private void updateActivationPrompt() {
        EntityPlayer player = mc.thePlayer;
        if (player == null) return;

        boolean lookingDown = player.rotationPitch >= 75.0f;
        boolean atEdge = lookingDown && isAtEdge();
        boolean sneaking = mc.gameSettings.keyBindSneak.isKeyDown();

        if (sneaking && atEdge) {
            if (activatePromptAt == 0) {
                activatePromptAt = System.currentTimeMillis();
            }

            long elapsed = System.currentTimeMillis() - activatePromptAt;
            if (elapsed >= (long) activationDelay.getInput()) {
                if (mc.gameSettings.keyBindUseItem.isKeyDown() && isYawAligned(player.rotationYaw)) {
                    beginAutomation();
                    return;
                }
            }
        } else {
            activatePromptAt = 0;
        }
    }

    private void beginAutomation() {
        EntityPlayer player = mc.thePlayer;
        if (player == null || !isHoldingBlock()) return;
        if (!isYawAligned(player.rotationYaw)) return;

        baseYaw = player.rotationYaw;
        calculateTravelDirection(baseYaw);

        Vec3 pos = player.getPositionVector();
        antiSwayLane = travelX != 0 ? pos.zCoord : pos.xCoord;
        antiSwayYawOffset = 0;
        antiSwayTapUsed = false;

        running = true;
        armed = false;
        setupTick = 0;
        cyclePhase = 19;
        scriptedYaw = baseYaw;
        scriptedPitch = player.rotationPitch;
        lastFreezeCheck = System.currentTimeMillis();
        useWindow = true;
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;
    }

    private void stopAutomation(boolean rearm) {
        running = false;
        armed = rearm;
        activatePromptAt = 0;
        setupTick = rearm ? 0 : -1;
        cyclePhase = 19;
        rotationActive = false;
        antiSwayYawOffset = 0;
        useWindow = false;
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;

        if (mc.thePlayer != null) {
            mc.thePlayer.moveForward = 0;
            mc.thePlayer.moveStrafing = 0;
            mc.thePlayer.setSprinting(false);
            mc.thePlayer.setSneaking(false);
        }

        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
        mc.gameSettings.keyBindUseItem.pressed = false;
    }

    // All cycle logic runs here, in LivingUpdateEvent, BEFORE movement physics
    private void cycleTick() {
        if (mc.thePlayer == null) return;

        // Setup phase: ticks 0-11 no jump, ticks 12-19 with jump
        if (setupTick >= 0 && setupTick < 20) {
            boolean jumping = setupTick >= 12;

            setRotationTarget(
                setupTick == 19 ? baseYaw + YAW_CURVE[19] : baseYaw,
                setupTick == 19 ? PITCH_CURVE[19] : 74.52f,
                50
            );

            mc.thePlayer.movementInput.moveForward = -1.0f;
            mc.thePlayer.movementInput.moveStrafe = -1.0f;
            mc.thePlayer.movementInput.jump = jumping;
            mc.thePlayer.setSprinting(false);
            useWindow = true;
            mc.gameSettings.keyBindUseItem.pressed = false;

            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), true);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), true);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), jumping);

            setupTick++;
            return;
        }

        // Transition from setup to cycle
        if (setupTick >= 20) {
            setupTick = -1;
            cyclePhase = 19;
        }

        int phase = cyclePhase;
        float forward = FORWARD_CURVE[phase];
        float strafe = STRAFE_CURVE[phase];
        boolean jumping = (phase >= 3 && phase <= 6) || phase == 12;
        boolean sprinting = phase == 9 || phase == 13 || phase == 14 || phase == 15;

        // Anti-sway: pass queued values, get strafe correction
        float strafeCorrection = getAntiSwayCorrection(forward, strafe);
        strafe += strafeCorrection;

        // Apply movement input BEFORE physics
        mc.thePlayer.movementInput.moveForward = forward;
        mc.thePlayer.movementInput.moveStrafe = strafe;
        mc.thePlayer.movementInput.jump = jumping;
        mc.thePlayer.setSprinting(sprinting);

        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), forward > 0.03f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), forward < -0.03f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), strafe > 0.5f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), strafe < -0.5f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), jumping);

        // Use key
        useWindow = phase >= 7;
        mc.gameSettings.keyBindUseItem.pressed = useWindow;

        // Rotation for NEXT phase
        int nextPhase = (phase + 1) % YAW_CURVE.length;
        setRotationTarget(baseYaw + YAW_CURVE[nextPhase], PITCH_CURVE[nextPhase], 50);

        // Placement
        if (useWindow && mc.thePlayer.getHeldItem() != null) {
            attemptDirectPlacement();
        }

        cyclePhase = nextPhase;
    }

    private void attemptDirectPlacement() {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return;

        int playerBlockX = floor(mc.thePlayer.posX);
        int playerBlockY = floor(mc.thePlayer.posY - 0.01);
        int playerBlockZ = floor(mc.thePlayer.posZ);

        int targetY = playerBlockY - 1;
        BlockPos placePos = new BlockPos(playerBlockX, targetY, playerBlockZ);
        if (!isReplaceable(placePos)) return;

        BlockPos supportPos = findBestSupport(placePos);
        if (supportPos == null) return;

        int face = findSupportFace(supportPos, placePos);
        if (face < 2 || face > 5) return;

        EnumFacing enumFace = getEnumFacing(face);
        Vec3 hitVec = getFaceHitVec(supportPos, face, 0.5, 0.5);

        C08PacketPlayerBlockPlacement packet = new C08PacketPlayerBlockPlacement(
            supportPos, face, held, (float) hitVec.xCoord, (float) hitVec.yCoord, (float) hitVec.zCoord
        );
        mc.getNetHandler().addToSendQueue(packet);
        mc.thePlayer.swingItem();

        lastSupportPos = supportPos;
        lastSupportFace = face;
        lastPlacedPos = placePos;
    }

    private BlockPos findBestSupport(BlockPos placePos) {
        int face = getTravelFace();
        if (face < 0) return null;

        BlockPos travelSupport = placePos.offset(getEnumFacing(face).getOpposite());
        if (isSupportBlock(travelSupport)) return travelSupport;

        BlockPos belowSupport = placePos.offset(EnumFacing.DOWN);
        if (isSupportBlock(belowSupport)) return belowSupport;

        for (EnumFacing f : EnumFacing.HORIZONTALS) {
            BlockPos neighbor = placePos.offset(f);
            if (isSupportBlock(neighbor)) return neighbor;
        }

        BlockPos downFromTravel = placePos.down().offset(getEnumFacing(face).getOpposite());
        if (isSupportBlock(downFromTravel)) return downFromTravel;

        return null;
    }

    private int findSupportFace(BlockPos support, BlockPos place) {
        int dx = place.getX() - support.getX();
        int dy = place.getY() - support.getY();
        int dz = place.getZ() - support.getZ();

        if (dx == 1) return 5;
        if (dx == -1) return 4;
        if (dz == 1) return 3;
        if (dz == -1) return 2;
        if (dy == 1) return 1;
        if (dy == -1) return 0;
        return -1;
    }

    private int getTravelFace() {
        if (travelX > 0) return 5;
        if (travelX < 0) return 4;
        if (travelZ > 0) return 3;
        if (travelZ < 0) return 2;
        return -1;
    }

    private EnumFacing getEnumFacing(int face) {
        switch (face) {
            case 0: return EnumFacing.DOWN;
            case 1: return EnumFacing.UP;
            case 2: return EnumFacing.NORTH;
            case 3: return EnumFacing.SOUTH;
            case 4: return EnumFacing.WEST;
            case 5: return EnumFacing.EAST;
            default: return EnumFacing.NORTH;
        }
    }

    private Vec3 getFaceHitVec(BlockPos pos, int face, double hx, double hz) {
        switch (face) {
            case 2: return new Vec3(pos.getX() + hx, pos.getY() + 0.5, pos.getZ() + 0.001);
            case 3: return new Vec3(pos.getX() + hx, pos.getY() + 0.5, pos.getZ() + 0.999);
            case 4: return new Vec3(pos.getX() + 0.001, pos.getY() + 0.5, pos.getZ() + hz);
            case 5: return new Vec3(pos.getX() + 0.999, pos.getY() + 0.5, pos.getZ() + hz);
            default: return new Vec3(pos.getX() + hx, pos.getY() + 0.999, pos.getZ() + hz);
        }
    }

    private boolean isSupportBlock(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block != Blocks.air && block != Blocks.water && block != Blocks.flowing_water
            && block != Blocks.lava && block != Blocks.flowing_lava && block != Blocks.fire;
    }

    private boolean isReplaceable(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block == Blocks.air || block == Blocks.water || block == Blocks.flowing_water
            || block == Blocks.lava || block == Blocks.flowing_lava || block == Blocks.fire;
    }

    private void setRotationTarget(float targetYaw, float targetPitch, long duration) {
        if (mc.thePlayer == null) return;

        mc.thePlayer.rotationYaw = scriptedYaw;
        mc.thePlayer.rotationPitch = scriptedPitch;

        rotationStartYaw = scriptedYaw;
        rotationStartPitch = scriptedPitch;

        float correctedYaw = targetYaw + antiSwayYawOffset;
        rotationStepCounter++;
        correctedYaw += (float) (SENSITIVITY_QUANTUM * YAW_NUDGE_PATTERN[rotationStepCounter % 5]);

        rotationTargetYaw = correctedYaw;
        rotationTargetPitch = MathHelper.clamp_float(targetPitch, -90, 90);

        rotationStartedAt = System.currentTimeMillis();
        rotationDuration = Math.max(1, duration);
        rotationActive = true;
    }

    private void applySmoothedRotation() {
        if (!rotationActive || mc.thePlayer == null) return;

        double progress = (double) (System.currentTimeMillis() - rotationStartedAt) / (double) rotationDuration;
        if (progress < 0) progress = 0;
        if (progress > 1) progress = 1;

        float desiredYaw = rotationStartYaw + wrapAngle(rotationTargetYaw - rotationStartYaw) * (float) progress;
        float desiredPitch = rotationStartPitch + (rotationTargetPitch - rotationStartPitch) * (float) progress;

        float quantizedYaw = quantizeFrom(rotationStartYaw, desiredYaw);
        float quantizedPitch = quantizeFrom(rotationStartPitch, desiredPitch);

        mc.thePlayer.rotationYaw = quantizedYaw;
        mc.thePlayer.rotationPitch = MathHelper.clamp_float(quantizedPitch, -90, 90);

        scriptedYaw = mc.thePlayer.rotationYaw;
        scriptedPitch = mc.thePlayer.rotationPitch;

        if (progress >= 1.0) rotationActive = false;
    }

    private float quantizeFrom(float origin, float value) {
        double steps = Math.round((value - origin) / SENSITIVITY_QUANTUM);
        return (float) (origin + steps * SENSITIVITY_QUANTUM);
    }

    // Anti-sway: takes queued forward/strafe (raw input values, not post-physics Entity fields)
    private float getAntiSwayCorrection(float forward, float recordedStrafe) {
        if (mc.thePlayer == null || !running || !setupDone()) {
            antiSwayTapUsed = false;
            antiSwayYawOffset *= 0.65f;
            if (Math.abs(antiSwayYawOffset) < 0.03f) antiSwayYawOffset = 0;
            return 0.0f;
        }

        if (mc.thePlayer.onGround) {
            Vec3 pos = mc.thePlayer.getPositionVector();
            Vec3 motion = new Vec3(mc.thePlayer.motionX, mc.thePlayer.motionY, mc.thePlayer.motionZ);

            double lanePosition = travelX != 0 ? pos.zCoord : pos.xCoord;
            double laneVelocity = travelX != 0 ? motion.zCoord : motion.xCoord;
            double error = antiSwayLane - lanePosition;

            if (Math.abs(error) < 0.015 && Math.abs(laneVelocity) < 0.008) {
                antiSwayTapUsed = false;
                antiSwayYawOffset *= 0.65f;
                if (Math.abs(antiSwayYawOffset) < 0.03f) antiSwayYawOffset = 0;
                return 0.0f;
            }

            double desiredLaneVelocity = error * 0.42 - laneVelocity * 0.78;
            if (desiredLaneVelocity > 0.16) desiredLaneVelocity = 0.16;
            if (desiredLaneVelocity < -0.16) desiredLaneVelocity = -0.16;
            double velocityCorrection = desiredLaneVelocity - laneVelocity;

            double radians = Math.toRadians(mc.thePlayer.rotationYaw);
            double sin = Math.sin(radians);
            double cos = Math.cos(radians);
            double yawLaneDerivative = travelX != 0
                    ? -forward * sin + recordedStrafe * cos
                    : -forward * cos - recordedStrafe * sin;

            double desiredYawOffset = 0;
            if (Math.abs(yawLaneDerivative) >= 0.12) {
                desiredYawOffset = Math.toDegrees(velocityCorrection * 0.55 / yawLaneDerivative);
            }
            if (desiredYawOffset > 2.25) desiredYawOffset = 2.25;
            if (desiredYawOffset < -2.25) desiredYawOffset = -2.25;
            antiSwayYawOffset = antiSwayYawOffset * 0.60f + (float) desiredYawOffset * 0.40f;

            double strafeLaneAxis = travelX != 0 ? sin : cos;
            boolean tapHelps = Math.abs(strafeLaneAxis) >= 0.20 && velocityCorrection * strafeLaneAxis > 0;
            if (tapHelps && !antiSwayTapUsed && Math.abs(velocityCorrection) >= 0.03) {
                antiSwayTapUsed = true;
                return 1.0f;
            }
        }

        return 0.0f;
    }

    private boolean setupDone() {
        return setupTick == -1;
    }

    private void handleAutoSwap() {
        if (mc.thePlayer == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        int heldCount = (held != null && held.getItem() instanceof ItemBlock) ? held.stackSize : 0;
        if (heldCount > 5) return;

        int bestSlot = -1;
        int bestSize = heldCount;
        for (int slot = 0; slot <= 8; slot++) {
            if (slot == mc.thePlayer.inventory.currentItem) continue;
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack == null || !(stack.getItem() instanceof ItemBlock)) continue;
            if (stack.stackSize > bestSize) {
                bestSize = stack.stackSize;
                bestSlot = slot;
            }
        }

        if (bestSlot != -1) {
            mc.thePlayer.inventory.currentItem = bestSlot;
        }
    }

    private boolean isHoldingBlock() {
        if (mc.thePlayer == null) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock;
    }

    private boolean isAtEdge() {
        if (mc.thePlayer == null) return false;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 look = mc.thePlayer.getLook(1.0f);

        Vec3 end = eyes.addVector(look.xCoord * 3, -2.5, look.zCoord * 3);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyes, end, false);
        if (mop == null) return false;

        BlockPos pos = mop.getBlockPos();
        return mc.theWorld.getBlockState(pos).getBlock() != Blocks.air;
    }

    private boolean isYawAligned(float yaw) {
        float nearestDiagonal = Math.round((yaw - 45.0f) / 90.0f) * 90.0f + 45.0f;
        return Math.abs(wrapAngle(yaw - nearestDiagonal)) <= 2.0f;
    }

    private void calculateTravelDirection(float yaw) {
        double radians = Math.toRadians(yaw);
        double rawX = Math.sin(radians) - Math.cos(radians);
        double rawZ = -Math.cos(radians) - Math.sin(radians);

        if (Math.abs(rawX) >= Math.abs(rawZ)) {
            travelX = rawX >= 0 ? 1 : -1;
            travelZ = 0;
        } else {
            travelX = 0;
            travelZ = rawZ >= 0 ? 1 : -1;
        }
    }

    private float wrapAngle(float angle) {
        while (angle <= -180.0f) angle += 360.0f;
        while (angle > 180.0f) angle -= 360.0f;
        return angle;
    }

    private int floor(double value) {
        int i = (int) value;
        return value < i ? i - 1 : i;
    }
}
