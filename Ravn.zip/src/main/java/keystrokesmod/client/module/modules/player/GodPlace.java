package keystrokesmod.client.module.modules.player;

import java.lang.reflect.Field;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class GodPlace extends Module {

    public static SliderSetting delay;
    public static TickSetting faceLock;
    public static TickSetting cancelDownFace;
    public static TickSetting noJumpDelay;
    public static TickSetting alerts;
    public static TickSetting debug;

    private static final Field rightClickDelayTimerField;
    private static final Field blockHitDelayField;
    private static final Field jumpField;

    static {
        Field rcdt = null;
        try {
            rcdt = ReflectionHelper.findField(Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        } catch (Exception ignored) {
        }
        rightClickDelayTimerField = rcdt;
        if (rightClickDelayTimerField != null)
            rightClickDelayTimerField.setAccessible(true);

        Field bhd = null;
        try {
            for (String name : new String[] { "field_78778_q", "blockHitDelay" }) {
                try {
                    Field f = PlayerControllerMP.class.getDeclaredField(name);
                    if (f.getType() == int.class) {
                        f.setAccessible(true);
                        bhd = f;
                        break;
                    }
                } catch (NoSuchFieldException ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        blockHitDelayField = bhd;
        if (blockHitDelayField != null)
            blockHitDelayField.setAccessible(true);

        Field f = null;
        try {
            f = ReflectionHelper.findField(MovementInput.class, "field_78800_z", "jump");
        } catch (Exception ignored) {
        }
        jumpField = f;
        if (jumpField != null)
            jumpField.setAccessible(true);
    }

    private boolean locked = false;
    private EnumFacing lockedFace = null;
    private float lastValidYaw, lastValidPitch;
    private boolean hasLastValidAngle = false;
    private int validFrameCount = 0;

    public GodPlace() {
        super("GodPlace", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Fast block placement with instant face-lock."));
        this.registerSetting(delay = new SliderSetting("Delay", 0.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(faceLock = new TickSetting("Face lock", false));
        this.registerSetting(cancelDownFace = new TickSetting("Cancel down face", true));
        this.registerSetting(noJumpDelay = new TickSetting("No jump delay", false));
        this.registerSetting(alerts = new TickSetting("Alerts", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public boolean canBeEnabled() {
        return rightClickDelayTimerField != null;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        locked = false;
        lockedFace = null;
        hasLastValidAngle = false;
        validFrameCount = 0;
        if (alerts.isToggled())
            Utils.Player.sendMessageToSelf("\u00a75[GodPlace] \u00a7aON \u00a77(delay: " + (int) delay.getInput() + ")");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        locked = false;
        lockedFace = null;
        hasLastValidAngle = false;
        validFrameCount = 0;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;

        if (noJumpDelay.isToggled() && jumpField != null && mc.thePlayer != null
                && mc.gameSettings.keyBindJump.isKeyDown()) {
            try {
                jumpField.setBoolean(mc.thePlayer.movementInput, true);
            } catch (Exception ignored) {
            }
        }

        if (!mc.gameSettings.keyBindUseItem.isKeyDown()) {
            if (locked) {
                locked = false;
                lockedFace = null;
            }
            hasLastValidAngle = false;
            validFrameCount = 0;
        }
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;
        if (!mc.gameSettings.keyBindUseItem.isKeyDown())
            return;

        manageDelay();
    }

    private void manageDelay() {
        int d = (int) delay.getInput();

        boolean validTarget = hasValidPlacementTarget();

        if (validTarget) {
            float curYaw = mc.thePlayer.rotationYaw;
            float curPitch = mc.thePlayer.rotationPitch;
            if (hasLastValidAngle) {
                float yawDiff = Math.abs(curYaw - lastValidYaw);
                float pitchDiff = Math.abs(curPitch - lastValidPitch);
                if (yawDiff > 15.0F || pitchDiff > 15.0F) {
                    validFrameCount = 0;
                    validTarget = false;
                }
            }
            if (validTarget) {
                validFrameCount++;
                if (validFrameCount < 2)
                    validTarget = false;
            }
        }

        if (validTarget) {
            lastValidYaw = mc.thePlayer.rotationYaw;
            lastValidPitch = mc.thePlayer.rotationPitch;
            hasLastValidAngle = true;
        }

        if (rightClickDelayTimerField != null) {
            try {
                if (d == 0) {
                    if (validTarget)
                        rightClickDelayTimerField.set(mc, 0);
                    else
                        rightClickDelayTimerField.set(mc, 1);
                } else {
                    int current = rightClickDelayTimerField.getInt(mc);
                    if (current > d)
                        rightClickDelayTimerField.set(mc, d);
                }
            } catch (Exception ignored) {
            }
        }

        if (blockHitDelayField != null && mc.playerController != null) {
            try {
                if (d == 0) {
                    if (validTarget)
                        blockHitDelayField.set(mc.playerController, 0);
                    else
                        blockHitDelayField.set(mc.playerController, 1);
                } else {
                    int current = blockHitDelayField.getInt(mc.playerController);
                    if (current > d)
                        blockHitDelayField.set(mc.playerController, d);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private boolean hasValidPlacementTarget() {
        if (mc.objectMouseOver == null)
            return false;
        if (mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK)
            return false;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return false;

        BlockPos hitPos = mc.objectMouseOver.getBlockPos();
        EnumFacing hitFace = mc.objectMouseOver.sideHit;

        if (hitPos == null || hitFace == null)
            return false;

        BlockPos placePos = hitPos.offset(hitFace);
        if (placePos == null)
            return false;

        Block placeBlock = mc.theWorld.getBlockState(placePos).getBlock();
        if (placeBlock != Blocks.air && !(placeBlock instanceof BlockLiquid))
            return false;

        Block adjacentBlock = mc.theWorld.getBlockState(hitPos).getBlock();
        if (adjacentBlock == Blocks.air || adjacentBlock instanceof BlockLiquid)
            return false;

        AxisAlignedBB placeBB = new AxisAlignedBB(placePos, placePos.add(1, 1, 1));
        AxisAlignedBB playerBB = mc.thePlayer.getEntityBoundingBox();
        if (playerBB.intersectsWith(placeBB))
            return false;

        double distToAdjacent = mc.thePlayer.getDistance(
                hitPos.getX() + 0.5D, hitPos.getY() + 0.5D, hitPos.getZ() + 0.5D);
        if (distToAdjacent > 4.5D)
            return false;

        Vec3 eyePos = new Vec3(
                mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
        Vec3 hitVec = mc.objectMouseOver.hitVec;
        if (hitVec == null)
            return false;

        double hitDist = eyePos.distanceTo(hitVec);
        if (hitDist > 4.5D)
            return false;

        Vec3 lookVec = mc.thePlayer.getLook(1.0F);
        Vec3 endVec = eyePos.addVector(lookVec.xCoord * 4.5D, lookVec.yCoord * 4.5D, lookVec.zCoord * 4.5D);

        MovingObjectPosition intercept = placeBB.calculateIntercept(eyePos, endVec);
        if (intercept == null)
            return false;

        if (intercept.sideHit != hitFace)
            return false;

        return true;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!faceLock.isToggled())
            return;
        if (!(fe.getEvent() instanceof PlayerInteractEvent))
            return;

        PlayerInteractEvent event = (PlayerInteractEvent) fe.getEvent();
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK)
            return;
        if (event.entityPlayer != mc.thePlayer)
            return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return;

        EnumFacing hitFace = event.face;

        if (cancelDownFace.isToggled() && hitFace == EnumFacing.DOWN) {
            event.setCanceled(true);
            return;
        }

        if (!locked) {
            locked = true;
            lockedFace = hitFace;
            if (debug.isToggled())
                Utils.Player.sendMessageToSelf("\u00a78[GP-DEBUG] \u00a77LOCKED " + hitFace.name().toUpperCase());
            // don't cancel this first placement - just remember the face to lock to
        }

        if (hitFace != lockedFace) {
            event.setCanceled(true);
            if (debug.isToggled())
                Utils.Player.sendMessageToSelf(
                        "\u00a78[GP-DEBUG] \u00a77CANCELLED face " + hitFace.name().toUpperCase());
        }
    }
}
