package keystrokesmod.client.module.modules.player;

import java.lang.reflect.Field;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class GodPlace extends Module {

    public static SliderSetting delay;
    public static TickSetting faceLock;
    public static TickSetting cancelDownFace;
    public static TickSetting noJumpDelay;
    public static TickSetting alerts;
    public static TickSetting debug;

    private static final Field rightClickDelayTimerField;
    private static final Field blockHitDelayField;
    private static final Field jumpField;

    static {
        Field rcdt = null;
        try {
            rcdt = ReflectionHelper.findField(Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        } catch (Exception ignored) {
        }
        rightClickDelayTimerField = rcdt;
        if (rightClickDelayTimerField != null)
            rightClickDelayTimerField.setAccessible(true);

        Field bhd = null;
        try {
            for (String name : new String[] { "field_78778_q", "blockHitDelay" }) {
                try {
                    Field f = PlayerControllerMP.class.getDeclaredField(name);
                    if (f.getType() == int.class) {
                        f.setAccessible(true);
                        bhd = f;
                        break;
                    }
                } catch (NoSuchFieldException ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        blockHitDelayField = bhd;
        if (blockHitDelayField != null)
            blockHitDelayField.setAccessible(true);

        Field f = null;
        try {
            f = ReflectionHelper.findField(MovementInput.class, "field_78800_z", "jump");
        } catch (Exception ignored) {
        }
        jumpField = f;
        if (jumpField != null)
            jumpField.setAccessible(true);
    }

    // --- State machine ---
    private enum PlacementState {
        IDLE, CANDIDATE, LOCKED, GRACE
    }

    private PlacementState state = PlacementState.IDLE;

    // --- Locked target ---
    private BlockPos lockedSupportPos;
    private BlockPos lockedPlacePos;
    private EnumFacing lockedFace;
    private Vec3 lockedHitVec;
    private long lastValidTargetTime;

    // --- Candidate confirmation ---
    private BlockPos candidateSupportPos;
    private BlockPos candidatePlacePos;
    private EnumFacing candidateFace;
    private Vec3 candidateHitVec;
    private int candidateFrames;

    // --- Angle tracking for intent detection ---
    private float lastValidYaw;
    private float lastValidPitch;
    private boolean hasLastValidAngle;

    // --- Grace period ---
    private static final int GRACE_FRAMES = 4;
    private int graceFrames;

    // --- Bridging state ---
    private boolean bridgingActive;
    private int effectiveDelay;
    private long lastDelayRecalcNanoTime;

    // --- Debug ---

    // --- Static accessors for AimAssist integration ---
    private static boolean placementActive;
    private static BlockPos placementBlock;
    private static EnumFacing placementFace;
    private static Vec3 placementHitVec;

    public GodPlace() {
        super("GodPlace", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Fast block placement with smart target lock."));
        this.registerSetting(delay = new SliderSetting("Delay", 0.0D, 0.0D, 5.0D, 1.0D));
        this.registerSetting(faceLock = new TickSetting("Face lock", false));
        this.registerSetting(cancelDownFace = new TickSetting("Cancel down face", true));
        this.registerSetting(noJumpDelay = new TickSetting("No jump delay", false));
        this.registerSetting(alerts = new TickSetting("Alerts", true));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public boolean canBeEnabled() {
        return rightClickDelayTimerField != null;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetAllState();
        if (alerts.isToggled())
            Utils.Player.sendMessageToSelf("\u00a75[GodPlace] \u00a7aON \u00a77(delay: " + (int) delay.getInput() + ")");
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetAllState();
    }

    // --- Public API for AimAssist integration ---
    public static boolean isPlacementActive() {
        return placementActive;
    }

    public static BlockPos getPlacementBlock() {
        return placementBlock;
    }

    public static EnumFacing getPlacementFace() {
        return placementFace;
    }

    public static Vec3 getPlacementHitVec() {
        return placementHitVec;
    }

    // --- State reset ---
    private void resetAllState() {
        state = PlacementState.IDLE;
        lockedSupportPos = null;
        lockedPlacePos = null;
        lockedFace = null;
        lockedHitVec = null;
        lastValidTargetTime = 0;
        candidateSupportPos = null;
        candidatePlacePos = null;
        candidateFace = null;
        candidateHitVec = null;
        candidateFrames = 0;
        hasLastValidAngle = false;
        graceFrames = 0;
        bridgingActive = false;
        effectiveDelay = 0;
        lastDelayRecalcNanoTime = 0;
        placementActive = false;
        placementBlock = null;
        placementFace = null;
        placementHitVec = null;
    }

    private void resetLockState() {
        state = PlacementState.IDLE;
        lockedSupportPos = null;
        lockedPlacePos = null;
        lockedFace = null;
        lockedHitVec = null;
        lastValidTargetTime = 0;
        candidateSupportPos = null;
        candidatePlacePos = null;
        candidateFace = null;
        candidateHitVec = null;
        candidateFrames = 0;
        graceFrames = 0;
        bridgingActive = false;
        placementActive = false;
        placementBlock = null;
        placementFace = null;
        placementHitVec = null;
    }

    // --- Tick: no-jump-delay + use-release reset ---
    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;

        if (noJumpDelay.isToggled() && jumpField != null && mc.thePlayer != null
                && mc.gameSettings.keyBindJump.isKeyDown()) {
            try {
                jumpField.setBoolean(mc.thePlayer.movementInput, true);
            } catch (Exception ignored) {
            }
        }

        // Use key released: unlock everything
        if (!mc.gameSettings.keyBindUseItem.isKeyDown()) {
            if (state != PlacementState.IDLE) {
                debugTransition("\u00a7cUNLOCK use-released");
                resetLockState();
            }
            hasLastValidAngle = false;
        }
    }

    // --- Render2D: delay management + state machine tick ---
    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;
        if (!mc.gameSettings.keyBindUseItem.isKeyDown())
            return;

        // Evaluate current placement target
        PlacementTarget target = getPlacementTarget();

        // Tick state machine
        tickStateMachine(target);

        // Update static accessors for AimAssist
        updatePublicState();

        // Manage placement delay
        manageDelay(target);
    }

    // --- Forge event: face lock interaction cancellation ---
    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!faceLock.isToggled())
            return;
        if (!(fe.getEvent() instanceof PlayerInteractEvent))
            return;

        PlayerInteractEvent event = (PlayerInteractEvent) fe.getEvent();
        if (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK)
            return;
        if (event.entityPlayer != mc.thePlayer)
            return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return;

        EnumFacing hitFace = event.face;
        BlockPos eventPos = event.pos;

        if (cancelDownFace.isToggled() && hitFace == EnumFacing.DOWN) {
            event.setCanceled(true);
            return;
        }

        if (state == PlacementState.IDLE || state == PlacementState.CANDIDATE) {
            // Not locked yet: allow this interaction but start candidate tracking
            return;
        }

        // Locked: check if interaction matches our locked target
        if (lockedFace != null && lockedSupportPos != null) {
            // The interaction is on the support block with the locked face
            if (eventPos.equals(lockedSupportPos) && hitFace == lockedFace) {
                // Matches our lock: allow
                return;
            }
            // Mismatched face or position: cancel
            event.setCanceled(true);
            if (debug.isToggled())
                Utils.Player.sendMessageToSelf(
                        "\u00a78[GP-DEBUG] \u00a77CANCELLED " + hitFace.name().toUpperCase()
                                + " (locked " + lockedFace.name().toUpperCase() + ")");
        }
    }

    // --- State machine ---
    private void tickStateMachine(PlacementTarget target) {
        long nowNano = System.nanoTime();

        switch (state) {
            case IDLE:
                if (target != null && target.quality >= 0.5D) {
                    // Transition to CANDIDATE
                    candidateSupportPos = target.supportPos;
                    candidatePlacePos = target.placePos;
                    candidateFace = target.face;
                    candidateHitVec = target.hitVec;
                    candidateFrames = 1;
                    state = PlacementState.CANDIDATE;
                    debugTransition("\u00a7eCANDIDATE " + target.face.name().toUpperCase());
                }
                break;

            case CANDIDATE:
                if (target != null
                        && target.supportPos.equals(candidateSupportPos)
                        && target.face == candidateFace
                        && target.placePos.equals(candidatePlacePos)) {
                    candidateFrames++;
                    // Confirm after 2 consistent frames (prevents 1-frame false positives)
                    if (candidateFrames >= 2) {
                        // Transition to LOCKED
                        lockedSupportPos = candidateSupportPos;
                        lockedPlacePos = candidatePlacePos;
                        lockedFace = candidateFace;
                        lockedHitVec = candidateHitVec;
                        lastValidTargetTime = nowNano;
                        lastValidYaw = mc.thePlayer.rotationYaw;
                        lastValidPitch = mc.thePlayer.rotationPitch;
                        hasLastValidAngle = true;
                        bridgingActive = true;
                        state = PlacementState.LOCKED;
                        debugTransition("\u00a7aLOCKED " + lockedFace.name().toUpperCase());
                        // Clear candidate
                        candidateSupportPos = null;
                        candidatePlacePos = null;
                        candidateFace = null;
                        candidateHitVec = null;
                        candidateFrames = 0;
                    }
                } else {
                    // Target changed or disappeared: reset candidate
                    candidateSupportPos = null;
                    candidatePlacePos = null;
                    candidateFace = null;
                    candidateHitVec = null;
                    candidateFrames = 0;
                    state = PlacementState.IDLE;
                    debugTransition("\u00a7cIDLE candidate-lost");
                }
                break;

            case LOCKED:
                if (isTargetStillValid(target)) {
                    // Target valid: update stored data
                    lastValidTargetTime = nowNano;
                    lockedHitVec = target.hitVec;
                    // Update place pos if support moved (e.g. placed on different face of same block)
                    lockedPlacePos = target.placePos;
                    hasLastValidAngle = true;
                    lastValidYaw = mc.thePlayer.rotationYaw;
                    lastValidPitch = mc.thePlayer.rotationPitch;

                    // Update lock if geometry changed but is still valid
                    if (target.supportPos.equals(lockedSupportPos) && target.face == lockedFace) {
                        // Same target: strong continuity
                    } else if (!target.supportPos.equals(lockedSupportPos) || target.face != lockedFace) {
                        // Different support or face but valid: re-lock
                        if (isTargetClearlyDifferent(target)) {
                            // Genuinely different: unlock
                            debugTransition("\u00a7cIDLE target-changed");
                            resetLockState();
                            return;
                        }
                        // Slight difference: update lock
                        lockedSupportPos = target.supportPos;
                        lockedPlacePos = target.placePos;
                        lockedFace = target.face;
                        debugTransition("\u00a7eRELOCK " + lockedFace.name().toUpperCase());
                    }
                } else {
                    // Target invalid: enter grace period
                    graceFrames = GRACE_FRAMES;
                    state = PlacementState.GRACE;
                    debugTransition("\u00a76GRACE");
                }
                break;

            case GRACE:
                graceFrames--;
                if (isTargetStillValid(target)) {
                    // Recovered: back to LOCKED
                    lastValidTargetTime = nowNano;
                    lockedHitVec = target.hitVec;
                    lockedPlacePos = target.placePos;
                    hasLastValidAngle = true;
                    lastValidYaw = mc.thePlayer.rotationYaw;
                    lastValidPitch = mc.thePlayer.rotationPitch;
                    state = PlacementState.LOCKED;
                    debugTransition("\u00a7aLOCKED recovered");
                    graceFrames = 0;
                } else if (graceFrames <= 0) {
                    // Grace expired: unlock
                    debugTransition("\u00a7cIDLE grace-expired");
                    resetLockState();
                }
                break;
        }
    }

    // --- Target validation ---
    private boolean isTargetStillValid(PlacementTarget freshTarget) {
        // Fast path: if we have a fresh target that matches our lock, use it
        if (freshTarget != null
                && freshTarget.supportPos.equals(lockedSupportPos)
                && freshTarget.face == lockedFace) {
            return true;
        }

        // Fallback: manually validate the locked position is still valid
        if (lockedSupportPos == null || lockedPlacePos == null || lockedFace == null)
            return false;

        // Support block must still exist and be solid
        Block supportBlock = mc.theWorld.getBlockState(lockedSupportPos).getBlock();
        if (supportBlock == Blocks.air || supportBlock instanceof BlockLiquid)
            return false;

        // Placement position must still be replaceable
        Block placeBlock = mc.theWorld.getBlockState(lockedPlacePos).getBlock();
        if (placeBlock != Blocks.air && !(placeBlock instanceof BlockLiquid))
            return false;

        // Player must be within interaction range
        double dist = mc.thePlayer.getDistance(
                lockedSupportPos.getX() + 0.5D, lockedSupportPos.getY() + 0.5D, lockedSupportPos.getZ() + 0.5D);
        if (dist > 4.5D)
            return false;

        // Player must not collide with placement
        AxisAlignedBB placeBB = new AxisAlignedBB(lockedPlacePos, lockedPlacePos.add(1, 1, 1));
        if (mc.thePlayer.getEntityBoundingBox().intersectsWith(placeBB))
            return false;

        // Angle check: player hasn't turned too far away
        if (hasLastValidAngle) {
            float yawDiff = wrapDegrees(mc.thePlayer.rotationYaw - lastValidYaw);
            float pitchDiff = mc.thePlayer.rotationPitch - lastValidPitch;
            if (Math.abs(yawDiff) > 35.0F || Math.abs(pitchDiff) > 35.0F)
                return false;
        }

        return true;
    }

    private boolean isTargetClearlyDifferent(PlacementTarget target) {
        if (target == null) return true;
        if (lockedSupportPos == null) return true;

        // Different support block entirely
        if (!target.supportPos.equals(lockedSupportPos)) {
            // Check distance between support positions
            double dx = target.supportPos.getX() - lockedSupportPos.getX();
            double dy = target.supportPos.getY() - lockedSupportPos.getY();
            double dz = target.supportPos.getZ() - lockedSupportPos.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 1.5D) return true;
        }

        // Different face on same block: not clearly different (normal bridging)
        if (target.supportPos.equals(lockedSupportPos) && target.face != lockedFace) {
            return false;
        }

        return false;
    }

    // --- Target acquisition ---
    private PlacementTarget getPlacementTarget() {
        if (mc.objectMouseOver == null)
            return null;
        if (mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK)
            return null;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock))
            return null;

        BlockPos hitPos = mc.objectMouseOver.getBlockPos();
        EnumFacing hitFace = mc.objectMouseOver.sideHit;

        if (hitPos == null || hitFace == null)
            return null;

        BlockPos placePos = hitPos.offset(hitFace);
        if (placePos == null)
            return null;

        // Placement position must be replaceable
        Block placeBlock = mc.theWorld.getBlockState(placePos).getBlock();
        if (placeBlock != Blocks.air && !(placeBlock instanceof BlockLiquid))
            return null;

        // Support block must exist and be solid
        Block adjacentBlock = mc.theWorld.getBlockState(hitPos).getBlock();
        if (adjacentBlock == Blocks.air || adjacentBlock instanceof BlockLiquid)
            return null;

        // Player collision check
        AxisAlignedBB placeBB = new AxisAlignedBB(placePos, placePos.add(1, 1, 1));
        AxisAlignedBB playerBB = mc.thePlayer.getEntityBoundingBox();
        if (playerBB.intersectsWith(placeBB))
            return null;

        // Distance to support block
        double distToSupport = mc.thePlayer.getDistance(
                hitPos.getX() + 0.5D, hitPos.getY() + 0.5D, hitPos.getZ() + 0.5D);
        if (distToSupport > 4.5D)
            return null;

        // Distance to placement position
        double distToPlace = mc.thePlayer.getDistance(
                placePos.getX() + 0.5D, placePos.getY() + 0.5D, placePos.getZ() + 0.5D);
        if (distToPlace > 5.0D)
            return null;

        // Hit vector validation
        Vec3 hitVec = mc.objectMouseOver.hitVec;
        if (hitVec == null)
            return null;

        Vec3 eyePos = new Vec3(
                mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
        double hitDist = eyePos.distanceTo(hitVec);
        if (hitDist > 4.5D)
            return null;

        // Ray interception check
        Vec3 lookVec = mc.thePlayer.getLook(1.0F);
        Vec3 endVec = eyePos.addVector(lookVec.xCoord * 4.5D, lookVec.yCoord * 4.5D, lookVec.zCoord * 4.5D);
        MovingObjectPosition intercept = placeBB.calculateIntercept(eyePos, endVec);
        if (intercept == null)
            return null;

        // Face correctness
        if (intercept.sideHit != hitFace)
            return null;

        // Calculate quality score
        double quality = calculateQuality(hitPos, hitFace, placePos, distToSupport);

        return new PlacementTarget(hitPos, placePos, hitFace, hitVec, quality);
    }

    // --- Quality scoring ---
    private double calculateQuality(BlockPos supportPos, EnumFacing face, BlockPos placePos, double distance) {
        double score = 1.0;

        // Distance penalty: closer is better
        score -= Math.max(0, (distance - 2.0D) / 4.5D) * 0.3;

        // Angle bonus: looking roughly at the target
        if (hasLastValidAngle) {
            float yawDiff = Math.abs(wrapDegrees(mc.thePlayer.rotationYaw - lastValidYaw));
            float pitchDiff = Math.abs(mc.thePlayer.rotationPitch - lastValidPitch);
            // Small angle changes get a bonus
            if (yawDiff < 10.0F && pitchDiff < 10.0F) {
                score += 0.1;
            }
            // Large angle changes get penalized
            if (yawDiff > 30.0F || pitchDiff > 30.0F) {
                score -= 0.2;
            }
        }

        // Continuity bonus: same target as current lock
        if (state == PlacementState.LOCKED || state == PlacementState.GRACE) {
            if (supportPos.equals(lockedSupportPos) && face == lockedFace) {
                score += 0.3;
            }
        }

        return Math.max(0, Math.min(1.0, score));
    }

    // --- Adaptive delay ---
    private void manageDelay(PlacementTarget target) {
        int userDelay = (int) delay.getInput();
        long nowNano = System.nanoTime();

        // Determine current placement state
        boolean validTarget = false;
        if (state == PlacementState.LOCKED || state == PlacementState.GRACE) {
            validTarget = true;
        } else if (target != null && target.quality >= 0.5D) {
            validTarget = true;
        }

        // Recalculate effective delay only on state transitions (not every frame)
        if (nowNano - lastDelayRecalcNanoTime > 50_000_000L) { // At most once per 50ms
            lastDelayRecalcNanoTime = nowNano;
            effectiveDelay = calculateEffectiveDelay(userDelay, validTarget);
        }

        // Apply delay
        if (rightClickDelayTimerField != null) {
            try {
                if (effectiveDelay == 0) {
                    rightClickDelayTimerField.set(mc, 0);
                } else {
                    int current = rightClickDelayTimerField.getInt(mc);
                    if (current > effectiveDelay)
                        rightClickDelayTimerField.set(mc, effectiveDelay);
                }
            } catch (Exception ignored) {
            }
        }

        if (blockHitDelayField != null && mc.playerController != null) {
            try {
                if (effectiveDelay == 0) {
                    blockHitDelayField.set(mc.playerController, 0);
                } else {
                    int current = blockHitDelayField.getInt(mc.playerController);
                    if (current > effectiveDelay)
                        blockHitDelayField.set(mc.playerController, effectiveDelay);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private int calculateEffectiveDelay(int userDelay, boolean validTarget) {
        if (!validTarget) {
            // No valid target: use user's delay or vanilla (1)
            return userDelay > 0 ? userDelay : 1;
        }

        // Valid target exists
        if (userDelay == 0) {
            // User wants fastest: use 0 when target is strong
            if (state == PlacementState.LOCKED) {
                return 0;
            }
            // CANDIDATE or GRACE: slight safety
            return 1;
        }

        // User has configured a delay: respect it
        return userDelay;
    }

    // --- Public state update ---
    private void updatePublicState() {
        if (state == PlacementState.LOCKED && lockedSupportPos != null && lockedFace != null && lockedHitVec != null) {
            placementActive = bridgingActive;
            placementBlock = lockedPlacePos;
            placementFace = lockedFace;
            placementHitVec = lockedHitVec;
        } else {
            placementActive = false;
            placementBlock = null;
            placementFace = null;
            placementHitVec = null;
        }
    }

    // --- Angle wrapping ---
    private static float wrapDegrees(float degrees) {
        float d = degrees % 360.0F;
        if (d >= 180.0F) d -= 360.0F;
        else if (d < -180.0F) d += 360.0F;
        return d;
    }

    // --- Debug transitions only ---
    private void debugTransition(String message) {
        if (debug.isToggled()) {
            Utils.Player.sendMessageToSelf("\u00a78[GP-DEBUG] " + message);
        }
    }

    // --- Lightweight target data holder ---
    private static class PlacementTarget {
        final BlockPos supportPos;
        final BlockPos placePos;
        final EnumFacing face;
        final Vec3 hitVec;
        final double quality;

        PlacementTarget(BlockPos supportPos, BlockPos placePos, EnumFacing face, Vec3 hitVec, double quality) {
            this.supportPos = supportPos;
            this.placePos = placePos;
            this.face = face;
            this.hitVec = hitVec;
            this.quality = quality;
        }
    }
}
