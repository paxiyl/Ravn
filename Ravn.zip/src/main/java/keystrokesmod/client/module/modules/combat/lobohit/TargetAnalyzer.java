package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.concurrent.ConcurrentLinkedDeque;

public class TargetAnalyzer {

    private static final int MAX_HISTORY = 40;
    private static final int KB_HISTORY = 10;
    private static final float VELOCITY_SMOOTH = 0.35f;

    private final ConcurrentLinkedDeque<Vec3> positionHistory = new ConcurrentLinkedDeque<>();
    private final float[] speedBuffer = new float[MAX_HISTORY];
    private final float[] kbBuffer = new float[KB_HISTORY];
    private int historyIndex = 0;
    private int kbIndex = 0;

    private float smoothedSpeed = 0;
    private float smoothedYaw = 0;
    private Vec3 lastPosition = null;
    private float lastMotionX = 0;
    private float lastMotionY = 0;
    private float lastMotionZ = 0;
    private int ticksSinceLastPosition = 0;

    private float extrapolatedX, extrapolatedY, extrapolatedZ;
    private boolean extrapolationValid = false;

    private boolean targetChangedDirection = false;
    private float previousDirectionAngle = 0;

    public void reset() {
        positionHistory.clear();
        java.util.Arrays.fill(speedBuffer, 0);
        java.util.Arrays.fill(kbBuffer, 0);
        historyIndex = 0;
        kbIndex = 0;
        smoothedSpeed = 0;
        smoothedYaw = 0;
        lastPosition = null;
        lastMotionX = 0;
        lastMotionY = 0;
        lastMotionZ = 0;
        ticksSinceLastPosition = 0;
        extrapolationValid = false;
        targetChangedDirection = false;
        previousDirectionAngle = 0;
    }

    public void update(EntityPlayer target) {
        if (target == null) return;

        Vec3 pos = new Vec3(target.posX, target.posY, target.posZ);
        positionHistory.addLast(pos);
        if (positionHistory.size() > MAX_HISTORY) {
            positionHistory.removeFirst();
        }

        if (lastPosition != null) {
            float dx = (float)(target.posX - lastPosition.xCoord);
            float dz = (float)(target.posZ - lastPosition.zCoord);
            float rawSpeed = MathHelper.sqrt_float(dx * dx + dz * dz) * 20;
            smoothedSpeed += (rawSpeed - smoothedSpeed) * VELOCITY_SMOOTH;
            speedBuffer[historyIndex % MAX_HISTORY] = smoothedSpeed;

            float rawYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
            float yawDiff = rawYaw - smoothedYaw;
            while (yawDiff > 180) yawDiff -= 360;
            while (yawDiff < -180) yawDiff += 360;
            targetChangedDirection = Math.abs(yawDiff) > 30;
            smoothedYaw += yawDiff * VELOCITY_SMOOTH;
        }

        lastMotionX = (float)(target.posX - target.prevPosX);
        lastMotionY = (float)(target.posY - target.prevPosY);
        lastMotionZ = (float)(target.posZ - target.prevPosZ);

        ticksSinceLastPosition = 0;
        lastPosition = pos;
        historyIndex++;
    }

    public void tickUpdate(EntityPlayer target) {
        if (target == null) return;
        ticksSinceLastPosition++;
        if (ticksSinceLastPosition > 3) {
            extrapolationValid = false;
        } else {
            extrapolatePosition(target);
        }
    }

    private void extrapolatePosition(EntityPlayer target) {
        float futureTicks = 2.0f;
        extrapolatedX = (float)target.posX + lastMotionX * futureTicks;
        extrapolatedY = (float)target.posY + lastMotionY * futureTicks;
        extrapolatedZ = (float)target.posZ + lastMotionZ * futureTicks;
        extrapolationValid = true;
    }

    public void recordKnockback(float kbAmount) {
        kbBuffer[kbIndex % KB_HISTORY] = kbAmount;
        kbIndex++;
    }

    public float getAverageKnockback() {
        float sum = 0;
        int count = Math.min(kbIndex, KB_HISTORY);
        if (count == 0) return 0;
        for (int i = 0; i < count; i++) {
            sum += kbBuffer[i];
        }
        return sum / count;
    }

    public float getDistanceTo(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        double dx = player.posX - lastPosition.xCoord;
        double dy = player.posY - lastPosition.yCoord;
        double dz = player.posZ - lastPosition.zCoord;
        return MathHelper.sqrt_float((float)(dx * dx + dy * dy + dz * dz));
    }

    public float getHorizontalDistanceTo(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        double dx = player.posX - lastPosition.xCoord;
        double dz = player.posZ - lastPosition.zCoord;
        return MathHelper.sqrt_float((float)(dx * dx + dz * dz));
    }

    public float getVerticalDistanceTo(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        return (float)(player.posY - lastPosition.yCoord);
    }

    public float getSpeed() { return smoothedSpeed; }

    public float getMotionX() { return lastMotionX; }
    public float getMotionY() { return lastMotionY; }
    public float getMotionZ() { return lastMotionZ; }

    public boolean isTargetChangedDirection() { return targetChangedDirection; }

    public boolean isMovingTowards(EntityPlayer player) {
        if (lastPosition == null || player == null || positionHistory.size() < 2) return false;
        Vec3 older = positionHistory.getFirst();
        if (older == null) return false;
        double dx = lastPosition.xCoord - older.xCoord;
        double dz = lastPosition.zCoord - older.zCoord;
        double toPlayerX = player.posX - lastPosition.xCoord;
        double toPlayerZ = player.posZ - lastPosition.zCoord;
        return dx * toPlayerX + dz * toPlayerZ > 0;
    }

    public Vec3 getExtrapolatedPosition() {
        return extrapolationValid ? new Vec3(extrapolatedX, extrapolatedY, extrapolatedZ) : null;
    }

    public Vec3 getPredictedPosition(int ticksAhead) {
        if (lastPosition == null) return null;
        float tx = ticksAhead;
        return new Vec3(
            lastPosition.xCoord + lastMotionX * tx,
            lastPosition.yCoord + lastMotionY * tx,
            lastPosition.zCoord + lastMotionZ * tx
        );
    }

    public float getAngleTo(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        double dx = lastPosition.xCoord - player.posX;
        double dz = lastPosition.zCoord - player.posZ;
        return (float)Math.toDegrees(Math.atan2(-dx, dz));
    }

    public boolean isStrafing() {
        if (positionHistory.size() < 4) return false;
        Vec3[] pts = positionHistory.toArray(new Vec3[0]);
        int n = pts.length;
        float angle1 = (float)Math.atan2(pts[n-1].zCoord - pts[n-2].zCoord, pts[n-1].xCoord - pts[n-2].xCoord);
        float angle2 = (float)Math.atan2(pts[n-2].zCoord - pts[n-3].zCoord, pts[n-2].xCoord - pts[n-3].xCoord);
        float diff = angle1 - angle2;
        while (diff > (float)Math.PI) diff -= 2 * (float)Math.PI;
        while (diff < -(float)Math.PI) diff += 2 * (float)Math.PI;
        return Math.abs(diff) > 0.3f;
    }
}
