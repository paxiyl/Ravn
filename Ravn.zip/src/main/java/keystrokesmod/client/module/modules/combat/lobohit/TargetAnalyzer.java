package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.concurrent.ConcurrentLinkedDeque;

public class TargetAnalyzer {

    private static final int MAX_HISTORY = 60;
    private static final int PING_WINDOW = 20;
    private static final float SMOOTHING_FACTOR = 0.3f;

    private final ConcurrentLinkedDeque<Vec3> positionHistory = new ConcurrentLinkedDeque<>();
    private final float[] speedHistory = new float[MAX_HISTORY];
    private final float[] yawHistory = new float[MAX_HISTORY];
    private final float[] hurtTimeHistory = new float[PING_WINDOW];
    private final int[] hitConfirmHistory = new int[PING_WINDOW];
    private int historyIndex = 0;
    private int pingIndex = 0;

    private float smoothedSpeed = 0;
    private float smoothedYaw = 0;
    private float estimatedPing = 50;
    private float estimatedKb = 0;
    private float lastTargetHealth = 20;
    private int ticksSinceLastHurt = 0;
    private boolean targetWasHurt = false;
    private float targetMotionX, targetMotionY, targetMotionZ;
    private float prevTargetMotionX, prevTargetMotionY, prevTargetMotionZ;
    private Vec3 lastPosition = null;
    private int ticksSinceLastPosition = 0;
    private float extrapolatedX, extrapolatedY, extrapolatedZ;
    private boolean extrapolationValid = false;
    private int comboCount = 0;
    private long lastComboTime = 0;
    private float dps = 0;
    private final float[] damageInstances = new float[20];
    private final long[] damageTimes = new long[20];
    private int damageIndex = 0;

    public void reset() {
        positionHistory.clear();
        java.util.Arrays.fill(speedHistory, 0);
        java.util.Arrays.fill(yawHistory, 0);
        java.util.Arrays.fill(hurtTimeHistory, 0);
        java.util.Arrays.fill(hitConfirmHistory, 0);
        historyIndex = 0;
        pingIndex = 0;
        smoothedSpeed = 0;
        smoothedYaw = 0;
        estimatedPing = 50;
        estimatedKb = 0;
        lastTargetHealth = 20;
        ticksSinceLastHurt = 0;
        targetWasHurt = false;
        targetMotionX = targetMotionY = targetMotionZ = 0;
        prevTargetMotionX = prevTargetMotionY = prevTargetMotionZ = 0;
        lastPosition = null;
        ticksSinceLastPosition = 0;
        extrapolatedX = extrapolatedY = extrapolatedZ = 0;
        extrapolationValid = false;
        comboCount = 0;
        lastComboTime = 0;
        dps = 0;
        java.util.Arrays.fill(damageInstances, 0);
        java.util.Arrays.fill(damageTimes, 0);
        damageIndex = 0;
    }

    public void update(EntityPlayer target, EntityPlayer player) {
        if (target == null || player == null) return;

        Vec3 pos = new Vec3(target.posX, target.posY, target.posZ);
        positionHistory.addLast(pos);
        if (positionHistory.size() > MAX_HISTORY) {
            positionHistory.removeFirst();
        }

        if (lastPosition != null) {
            float dx = (float)(target.posX - lastPosition.xCoord);
            float dy = (float)(target.posY - lastPosition.yCoord);
            float dz = (float)(target.posZ - lastPosition.zCoord);
            float rawSpeed = MathHelper.sqrt_float(dx * dx + dy * dy + dz * dz) * 20;
            smoothedSpeed += (rawSpeed - smoothedSpeed) * SMOOTHING_FACTOR;
            speedHistory[historyIndex % MAX_HISTORY] = smoothedSpeed;

            float rawYaw = (float)(Math.toDegrees(Math.atan2(-dx, dz)));
            smoothedYaw = lerpAngle(smoothedYaw, rawYaw, SMOOTHING_FACTOR);
            yawHistory[historyIndex % MAX_HISTORY] = smoothedYaw;
        }

        targetMotionX = (float)(target.posX - target.prevPosX);
        targetMotionY = (float)(target.posY - target.prevPosY);
        targetMotionZ = (float)(target.posZ - target.prevPosZ);

        ticksSinceLastPosition = 0;
        lastPosition = pos;
        historyIndex++;
    }

    public void onTargetHurt(int hurtTime, float damage, EntityPlayer player) {
        if (hurtTime > 0) {
            targetWasHurt = true;
            ticksSinceLastHurt = 0;
        }

        if (damage > 0) {
            recordDamage(damage);
        }

        hurtTimeHistory[pingIndex % PING_WINDOW] = hurtTime;
        hitConfirmHistory[pingIndex % PING_WINDOW] = 1;
        pingIndex++;

        if (System.currentTimeMillis() - lastComboTime < 1000) {
            comboCount++;
        } else {
            comboCount = 1;
        }
        lastComboTime = System.currentTimeMillis();

        lastTargetHealth = player.getHealth();
    }

    public void onHitMissed() {
        hitConfirmHistory[pingIndex % PING_WINDOW] = 0;
        hurtTimeHistory[pingIndex % PING_WINDOW] = 0;
        pingIndex++;
    }

    private void recordDamage(float damage) {
        damageInstances[damageIndex % 20] = damage;
        damageTimes[damageIndex % 20] = System.currentTimeMillis();
        damageIndex++;

        long now = System.currentTimeMillis();
        float totalDamage = 0;
        int count = 0;
        for (int i = 0; i < Math.min(damageIndex, 20); i++) {
            if (now - damageTimes[i % 20] < 5000) {
                totalDamage += damageInstances[i % 20];
                count++;
            }
        }
        dps = count > 0 ? (totalDamage / (Math.min(damageIndex, 20) * 0.05f)) : 0;
    }

    public void tickUpdate(EntityPlayer target) {
        if (target == null) return;

        ticksSinceLastHurt++;
        ticksSinceLastPosition++;

        if (ticksSinceLastHurt > 40) {
            targetWasHurt = false;
        }

        if (ticksSinceLastPosition > 3) {
            extrapolationValid = false;
        } else {
            extrapolatePosition(target);
        }

        updatePingEstimate();
        updateKbEstimate(target);
    }

    private void extrapolatePosition(EntityPlayer target) {
        float futureTicks = estimatedPing / 50.0f;
        extrapolatedX = (float)target.posX + targetMotionX * futureTicks;
        extrapolatedY = (float)target.posY + targetMotionY * futureTicks;
        extrapolatedZ = (float)target.posZ + targetMotionZ * futureTicks;
        extrapolationValid = true;
    }

    private void updatePingEstimate() {
        int recentHits = 0;
        int recentMisses = 0;
        for (int i = 0; i < PING_WINDOW; i++) {
            if (hitConfirmHistory[i % PING_WINDOW] == 1) recentHits++;
            if (hurtTimeHistory[i % PING_WINDOW] > 0) recentMisses++;
        }
        if (recentHits > 0) {
            float avgHurtTime = 0;
            int count = 0;
            for (int i = 0; i < PING_WINDOW; i++) {
                if (hurtTimeHistory[i % PING_WINDOW] > 0) {
                    avgHurtTime += hurtTimeHistory[i % PING_WINDOW];
                    count++;
                }
            }
            if (count > 0) {
                avgHurtTime /= count;
                float estimated = avgHurtTime * 50.0f;
                estimatedPing += (estimated - estimatedPing) * 0.2f;
            }
        }
        estimatedPing = MathHelper.clamp_float(estimatedPing, 0, 500);
    }

    private void updateKbEstimate(EntityPlayer target) {
        float dx = (float)(targetMotionX - prevTargetMotionX);
        float dy = (float)(targetMotionY - prevTargetMotionY);
        float dz = (float)(targetMotionZ - prevTargetMotionZ);
        float kbMagnitude = MathHelper.sqrt_float(dx * dx + dy * dy + dz * dz);
        if (kbMagnitude > 0.1f) {
            estimatedKb += (kbMagnitude - estimatedKb) * 0.3f;
        } else {
            estimatedKb *= 0.9f;
        }
        prevTargetMotionX = targetMotionX;
        prevTargetMotionY = targetMotionY;
        prevTargetMotionZ = targetMotionZ;
    }

    public float getDistanceTo(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        float dx = (float)(player.posX - lastPosition.xCoord);
        float dy = (float)(player.posY - lastPosition.yCoord);
        float dz = (float)(player.posZ - lastPosition.zCoord);
        return MathHelper.sqrt_float(dx * dx + dy * dy + dz * dz);
    }

    public float getRelativeDistanceDelta(EntityPlayer player) {
        if (positionHistory.size() < 2 || player == null) return 0;
        Vec3 older = positionHistory.getFirst();
        Vec3 newer = positionHistory.getLast();
        if (older == null || newer == null) return 0;
        Vec3 playerPos = new Vec3(player.posX, player.posY, player.posZ);
        float oldDist = (float) playerPos.distanceTo(older);
        float newDist = (float) playerPos.distanceTo(newer);
        return newDist - oldDist;
    }

    public Vec3 getExtrapolatedPosition() {
        return extrapolationValid ? new Vec3(extrapolatedX, extrapolatedY, extrapolatedZ) : null;
    }

    public float getAngleToTarget(EntityPlayer player) {
        if (player == null || lastPosition == null) return 0;
        double dx = lastPosition.xCoord - player.posX;
        double dz = lastPosition.zCoord - player.posZ;
        return (float)(Math.toDegrees(Math.atan2(-dx, dz)));
    }

    public float getAngleDelta(EntityPlayer player) {
        float targetYaw = getAngleToTarget(player);
        float playerYaw = player.rotationYaw;
        float diff = targetYaw - playerYaw;
        while (diff > 180) diff -= 360;
        while (diff < -180) diff += 360;
        return Math.abs(diff);
    }

    public float getSpeed() { return smoothedSpeed; }

    public float getEstimatedPing() { return estimatedPing; }

    public float getEstimatedKb() { return estimatedKb; }

    public int getComboCount() { return comboCount; }

    public float getDps() { return dps; }

    public boolean isTargetWasHurt() { return targetWasHurt; }

    public int getTicksSinceLastHurt() { return ticksSinceLastHurt; }

    public Vec3 getLastPosition() { return lastPosition; }

    public boolean isMovingTowards(EntityPlayer player) {
        if (lastPosition == null || player == null || positionHistory.size() < 2) return false;
        Vec3 older = positionHistory.getFirst();
        Vec3 newer = positionHistory.getLast();
        if (older == null || newer == null) return false;

        double dx = newer.xCoord - older.xCoord;
        double dz = newer.zCoord - older.zCoord;
        double toPlayerX = player.posX - newer.xCoord;
        double toPlayerZ = player.posZ - newer.zCoord;
        return dx * toPlayerX + dz * toPlayerZ > 0;
    }

    public boolean isMovingAway(EntityPlayer player) {
        return !isMovingTowards(player);
    }

    public boolean isStrafing() {
        if (positionHistory.size() < 4) return false;
        Vec3[] pts = positionHistory.toArray(new Vec3[0]);
        int n = pts.length;
        float angle1 = (float)Math.atan2(pts[n-1].zCoord - pts[n-2].zCoord, pts[n-1].xCoord - pts[n-2].xCoord);
        float angle2 = (float)Math.atan2(pts[n-2].zCoord - pts[n-3].zCoord, pts[n-2].xCoord - pts[n-3].xCoord);
        float diff = angle1 - angle2;
        while (diff > (float)Math.PI) diff -= 2 * (float)Math.PI;
        while (diff < -(float)Math.PI) diff += 2 * (float)Math.PI;
        return Math.abs(diff) > 0.3f;
    }

    public float getTargetMotionX() { return targetMotionX; }
    public float getTargetMotionY() { return targetMotionY; }
    public float getTargetMotionZ() { return targetMotionZ; }

    public Vec3 getPredictedPosition(int ticksAhead) {
        if (lastPosition == null) return null;
        float tx = ticksAhead;
        return new Vec3(
            lastPosition.xCoord + targetMotionX * tx,
            lastPosition.yCoord + targetMotionY * tx,
            lastPosition.zCoord + targetMotionZ * tx
        );
    }

    private float lerpAngle(float a, float b, float t) {
        float diff = b - a;
        while (diff > 180) diff -= 360;
        while (diff < -180) diff += 360;
        return a + diff * t;
    }
}
