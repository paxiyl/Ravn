package keystrokesmod.client.module.modules.render;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;

/**
 * AimSmooth — manual camera input smoothing filter.
 * <p>
 * Intercepts MouseHelper.mouseXYChange() via mixin and applies
 * framerate-independent exponential smoothing to deltaX/deltaY.
 * No entity detection, no target tracking, no combat automation.
 */
public class AimSmooth extends Module {

    public static SliderSetting smoothing;
    public static TickSetting separateY;
    public static SliderSetting verticalSmoothing;

    // Filter state — all static so the mixin can call onMouseDelta() without an instance
    private static double filteredX = 0.0D;
    private static double filteredY = 0.0D;
    private static double residualX = 0.0D;
    private static double residualY = 0.0D;
    private static long lastTimeNanos = -1L;

    private static final int[] result = new int[2];

    public AimSmooth() {
        super("AimSmooth", ModuleCategory.render);
        this.registerSetting(new DescriptionSetting("Smooths manual camera/touch input jitter"));
        this.registerSetting(smoothing = new SliderSetting("Smoothing", 25.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(separateY = new TickSetting("Separate Y", false));
        this.registerSetting(verticalSmoothing = new SliderSetting("Vertical smoothing", 25.0D, 0.0D, 100.0D, 1.0D));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetState();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetState();
    }

    private static void resetState() {
        filteredX = 0.0D;
        filteredY = 0.0D;
        residualX = 0.0D;
        residualY = 0.0D;
        lastTimeNanos = -1L;
    }

    /**
     * Called by MixinMouseHelper at the end of MouseHelper.mouseXYChange().
     * Applies framerate-independent exponential smoothing and returns filtered deltas.
     * <p>
     * The returned int[] is a reused static array — do NOT store references to it.
     *
     * @param rawX raw deltaX from MouseHelper
     * @param rawY raw deltaY from MouseHelper
     * @return filtered [deltaX, deltaY]
     */
    public static int[] onMouseDelta(int rawX, int rawY) {
        Module m = Raven.moduleManager.getModuleByClazz(AimSmooth.class);
        if (m == null || !m.isEnabled()) {
            result[0] = rawX;
            result[1] = rawY;
            return result;
        }

        // Reset filter when any GUI is open — old movement must not carry over
        if (mc.currentScreen != null) {
            resetState();
            result[0] = rawX;
            result[1] = rawY;
            return result;
        }

        // Delta time
        long now = System.nanoTime();
        double dt;
        if (lastTimeNanos < 0L) {
            dt = 0.016D;
        }
        else {
            dt = (now - lastTimeNanos) * 1.0E-9D;
        }
        lastTimeNanos = now;
        if (dt < 0.001D) dt = 0.001D;
        else if (dt > 0.1D) dt = 0.1D;

        // Horizontal smoothing strength → time constant tau
        // tau = 0 → instant, tau = 0.5 → very smooth
        double hStrength = smoothing.getInput() / 100.0D;
        double hTau = hStrength * 0.5D + 0.001D;
        double hAlpha = 1.0D - Math.exp(-dt / hTau);

        filteredX += (rawX - filteredX) * hAlpha;

        // Vertical smoothing strength
        double vStrength;
        if (separateY.isToggled()) {
            vStrength = verticalSmoothing.getInput() / 100.0D;
        }
        else {
            vStrength = hStrength;
        }
        double vTau = vStrength * 0.5D + 0.001D;
        double vAlpha = 1.0D - Math.exp(-dt / vTau);

        filteredY += (rawY - filteredY) * vAlpha;

        // Subpixel accumulator — prevents tiny filtered values from being lost
        double outputX = filteredX + residualX;
        double outputY = filteredY + residualY;
        int finalX = (int) Math.round(outputX);
        int finalY = (int) Math.round(outputY);
        residualX = outputX - finalX;
        residualY = outputY - finalY;

        result[0] = finalX;
        result[1] = finalY;
        return result;
    }

    /**
     * Force-resets filter state. Called when the mouse is grabbed/ungrabbed
     * or the player enters/leaves a GUI screen.
     */
    public static void reset() {
        resetState();
    }
}
