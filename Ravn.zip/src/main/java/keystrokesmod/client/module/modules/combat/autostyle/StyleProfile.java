package keystrokesmod.client.module.modules.combat.autostyle;

public class StyleProfile {

    public final String name;

    public final double flickSpeedMultiplier;
    public final double flickAmplitudeMin;
    public final double flickAmplitudeMax;
    public final double overshootPercent;
    public final double overshootAngleMax;
    public final double recoverySpeedMultiplier;
    public final double pitchInfluence;
    public final double pitchMax;
    public final double trackingStrength;
    public final double maxTrackingSpeed;
    public final double cooldownMs;
    public final double timingVariation;
    public final double amplitudeVariation;
    public final double directionVariation;
    public final double movementInfluence;

    public StyleProfile(
        String name,
        double flickSpeedMultiplier,
        double flickAmplitudeMin,
        double flickAmplitudeMax,
        double overshootPercent,
        double overshootAngleMax,
        double recoverySpeedMultiplier,
        double pitchInfluence,
        double pitchMax,
        double trackingStrength,
        double maxTrackingSpeed,
        double cooldownMs,
        double timingVariation,
        double amplitudeVariation,
        double directionVariation,
        double movementInfluence
    ) {
        this.name = name;
        this.flickSpeedMultiplier = flickSpeedMultiplier;
        this.flickAmplitudeMin = flickAmplitudeMin;
        this.flickAmplitudeMax = flickAmplitudeMax;
        this.overshootPercent = overshootPercent;
        this.overshootAngleMax = overshootAngleMax;
        this.recoverySpeedMultiplier = recoverySpeedMultiplier;
        this.pitchInfluence = pitchInfluence;
        this.pitchMax = pitchMax;
        this.trackingStrength = trackingStrength;
        this.maxTrackingSpeed = maxTrackingSpeed;
        this.cooldownMs = cooldownMs;
        this.timingVariation = timingVariation;
        this.amplitudeVariation = amplitudeVariation;
        this.directionVariation = directionVariation;
        this.movementInfluence = movementInfluence;
    }

    public static StyleProfile subtle() {
        return new StyleProfile(
            "SUBTLE",
            1.5, 15.0, 35.0, 0.10, 5.0,
            1.2, 0.10, 5.0,
            0.6, 360.0, 350.0,
            0.10, 0.10, 0.15, 0.2
        );
    }

    public static StyleProfile clean() {
        return new StyleProfile(
            "CLEAN",
            2.0, 25.0, 55.0, 0.15, 10.0,
            1.5, 0.15, 8.0,
            0.7, 480.0, 300.0,
            0.15, 0.15, 0.20, 0.3
        );
    }

    public static StyleProfile aggressive() {
        return new StyleProfile(
            "AGGRESSIVE",
            3.0, 40.0, 80.0, 0.18, 15.0,
            2.0, 0.20, 12.0,
            0.8, 600.0, 250.0,
            0.20, 0.20, 0.25, 0.5
        );
    }

    public static StyleProfile boxing() {
        return new StyleProfile(
            "BOXING",
            3.5, 50.0, 90.0, 0.20, 18.0,
            2.2, 0.18, 10.0,
            0.85, 720.0, 200.0,
            0.25, 0.25, 0.30, 0.6
        );
    }

    public static StyleProfile reference() {
        return new StyleProfile(
            "REFERENCE",
            3.2, 45.0, 85.0, 0.20, 17.0,
            2.1, 0.20, 12.0,
            0.80, 660.0, 220.0,
            0.22, 0.22, 0.28, 0.55
        );
    }

    public static StyleProfile extreme() {
        return new StyleProfile(
            "EXTREME",
            4.5, 60.0, 110.0, 0.25, 25.0,
            2.8, 0.25, 15.0,
            0.9, 900.0, 180.0,
            0.30, 0.30, 0.35, 0.7
        );
    }

    public static StyleProfile forIntensity(double intensity) {
        if (intensity <= 15) return subtle();
        if (intensity <= 30) return clean();
        if (intensity <= 50) return aggressive();
        if (intensity <= 70) return boxing();
        if (intensity <= 85) return reference();
        return extreme();
    }

    public StyleProfile withIntensity(double intensity) {
        double t = intensity / 100.0;
        return new StyleProfile(
            name,
            flickSpeedMultiplier * (0.5 + t * 1.5),
            flickAmplitudeMin * (0.3 + t * 1.2),
            flickAmplitudeMax * (0.3 + t * 1.4),
            overshootPercent * (0.5 + t * 1.0),
            overshootAngleMax * (0.3 + t * 1.5),
            recoverySpeedMultiplier * (0.5 + t * 1.2),
            pitchInfluence * (0.3 + t * 1.4),
            pitchMax * (0.3 + t * 1.4),
            trackingStrength * (0.4 + t * 1.2),
            maxTrackingSpeed * (0.5 + t * 1.5),
            cooldownMs * (1.5 - t * 1.0),
            timingVariation * (0.3 + t * 1.4),
            amplitudeVariation * (0.3 + t * 1.4),
            directionVariation * (0.3 + t * 1.4),
            movementInfluence * (0.3 + t * 1.4)
        );
    }
}
