package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.InventoryUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * Simple one-block momentum stopper for Minecraft 1.8.9.
 *
 * Rule:
 * 1. Find the nearest moving enemy.
 * 2. Read the enemy's current facing direction (no path prediction).
 * 3. Select exactly the ground block two blocks in front of that direction.
 * 4. Optionally aim at it and/or place one block.
 * 5. After one successful placement, stay locked until the client sends an
 *    outgoing ATTACK packet for that same enemy.
 */
public class SmartBlockPlace extends Module {
    public static SliderSetting targetRange;
    public static SliderSetting blockDistance;
    public static SliderSetting rotationSpeed;
    public static TickSetting autoPlace;
    public static TickSetting aimAssist;
    public static TickSetting requireRightClick;
    public static TickSetting requireMoving;
    public static TickSetting previewDebug;

    private EntityPlayer target;
    private BlockPos recommendedPos;
    private BlockPos supportPos;
    private EnumFacing supportFace;
    private Vec3 hitVec;
    private float desiredYaw;
    private float desiredPitch;

    private boolean placementConsumed;

    public SmartBlockPlace() {
        super("SmartBlockPlace", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting(
                "Places one ground block exactly two blocks ahead of a moving target's facing direction."));
        this.registerSetting(targetRange = new SliderSetting("Target range", 12.0D, 3.0D, 16.0D, 0.5D));
        this.registerSetting(blockDistance = new SliderSetting("Block distance", 2.0D, 1.0D, 3.0D, 1.0D));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 720.0D, 120.0D, 1440.0D, 60.0D));
        this.registerSetting(autoPlace = new TickSetting("Auto place", false));
        this.registerSetting(aimAssist = new TickSetting("Aim assist", true));
        this.registerSetting(requireRightClick = new TickSetting("Require right-click", true));
        this.registerSetting(requireMoving = new TickSetting("Require moving target", true));
        this.registerSetting(previewDebug = new TickSetting("Debug", false));
        setVisableInHud(false);
    }

    @Override
    public void onEnable() {
        clearState();
    }

    @Override
    public void onDisable() {
        restoreCamera();
        clearState();
    }

    @Subscribe
    public void onUpdate(UpdateEvent event) {
        if (!event.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null) {
            restoreCamera();
            clearTargetData();
            return;
        }

        if (mc.currentScreen != null) {
            restoreCamera();
            clearTargetData();
            return;
        }

        target = findTarget();
        if (target == null) {
            restoreCamera();
            clearTargetData();
            return;
        }

        // Once a block has been placed, do not change the selected enemy or
        // issue any more placement attempts until the player hits that enemy.
        if (placementConsumed) {
            // Hard lock after one placement. The packet handler below re-arms
            // the module when an outgoing ATTACK packet is sent.
            return;
        }

        if (requireMoving.isToggled() && horizontalSpeed(target.motionX, target.motionZ) < 0.03D) {
            recommendedPos = null;
            restoreCamera();
            return;
        }

        buildRecommendation(target);
        if (recommendedPos == null) {
            restoreCamera();
            return;
        }

        if (aimAssist.isToggled() && (!requireRightClick.isToggled() || org.lwjgl.input.Mouse.isButtonDown(1))) {
            applyAim();
        } else {
            restoreCamera();
        }

        if (autoPlace.isToggled()
                && (!requireRightClick.isToggled() || org.lwjgl.input.Mouse.isButtonDown(1))) {
            tryPlace();
        }
    }

    @Subscribe
    public void onPacket(PacketEvent event) {
        if (!event.isOutgoing() || !placementConsumed) return;
        if (!(event.getPacket() instanceof C02PacketUseEntity)) return;

        C02PacketUseEntity packet = event.getPacket();
        if (packet.getAction() != C02PacketUseEntity.Action.ATTACK) return;

        // Re-arm only after the player sends an outgoing ATTACK packet.
        // C02PacketUseEntity in this 1.8.9 mapping does not expose getEntityId(),
        // so we deliberately do not depend on a non-existent accessor here.
        placementConsumed = false;
    }

    private EntityPlayer findTarget() {
        double rangeSq = targetRange.getInput() * targetRange.getInput();
        EntityPlayer closest = null;
        double closestSq = Double.MAX_VALUE;

        for (Object object : mc.theWorld.playerEntities) {
            if (!(object instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) object;
            if (player == mc.thePlayer || player.isDead || player.getHealth() <= 0.0F) continue;
            double distanceSq = player.getDistanceSqToEntity(mc.thePlayer);
            if (distanceSq > rangeSq || distanceSq >= closestSq) continue;
            closest = player;
            closestSq = distanceSq;
        }

        return closest;
    }

    private void buildRecommendation(EntityPlayer enemy) {
        recommendedPos = null;
        supportPos = null;
        supportFace = null;
        hitVec = null;

        int distance = Math.max(1, (int) Math.round(blockDistance.getInput()));
        EnumFacing facing = dominantHorizontalFacing(enemy.rotationYaw);

        // Exactly N blocks in front of the enemy's current facing. No lateral
        // candidate search and no future-position prediction.
        int x = MathHelper.floor_double(enemy.posX);
        int z = MathHelper.floor_double(enemy.posZ);
        BlockPos place = new BlockPos(x, MathHelper.floor_double(enemy.posY), z).offset(facing, distance);

        // Ground-only: the actual placed block must be on the same Y level as
        // the enemy's feet, with a solid block directly underneath it.
        if (!isValidGroundPlacement(place)) return;

        BlockPos support = place.down();
        Vec3 hit = new Vec3(
                support.getX() + 0.5D,
                support.getY() + 0.98D,
                support.getZ() + 0.5D
        );

        if (mc.thePlayer.getDistanceSq(hit.xCoord, hit.yCoord, hit.zCoord) > 5.5D * 5.5D) return;
        if (!mc.thePlayer.canPlayerEdit(place, EnumFacing.UP, mc.thePlayer.getHeldItem())) return;

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        double dx = hit.xCoord - eyes.xCoord;
        double dy = hit.yCoord - eyes.yCoord;
        double dz = hit.zCoord - eyes.zCoord;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        desiredYaw = wrapYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D));
        desiredPitch = MathHelper.clamp_float(
                (float) (-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);

        recommendedPos = place;
        supportPos = support;
        supportFace = EnumFacing.UP;
        hitVec = hit;
    }

    private boolean isValidGroundPlacement(BlockPos pos) {
        if (pos == null || mc.theWorld == null) return false;
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (!(block == Blocks.air || block.getMaterial().isReplaceable())) return false;

        Block below = mc.theWorld.getBlockState(pos.down()).getBlock();
        if (below == Blocks.air || below instanceof BlockLiquid) return false;
        if (below.getMaterial().isLiquid() || below.getMaterial().isReplaceable()) return false;

        // Do not try to place the block directly inside either player.
        net.minecraft.util.AxisAlignedBB blockBox = new net.minecraft.util.AxisAlignedBB(
                pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0D, pos.getY() + 1.0D, pos.getZ() + 1.0D);
        if (blockBox.intersectsWith(target.getEntityBoundingBox().expand(0.01D, 0.01D, 0.01D))) return false;
        if (blockBox.intersectsWith(mc.thePlayer.getEntityBoundingBox().expand(0.01D, 0.0D, 0.01D))) return false;
        return true;
    }

    private void tryPlace() {
        if (placementConsumed || target == null || recommendedPos == null || supportPos == null || hitVec == null) return;
        if (mc.playerController == null || !hasPlaceableBlock()) return;
        if (!mc.thePlayer.canPlayerEdit(recommendedPos, EnumFacing.UP, mc.thePlayer.getHeldItem())) return;

        ItemStack held = mc.thePlayer.getHeldItem();

        // Latch BEFORE the controller call so this module can never issue a
        // second placement from the same engagement, even if the call returns
        // unusually or another tick arrives immediately afterward.
        placementConsumed = true;

        mc.playerController.onPlayerRightClick(
                mc.thePlayer,
                mc.theWorld,
                held,
                supportPos,
                supportFace,
                hitVec
        );
    }

    private boolean hasPlaceableBlock() {
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null
                && held.getItem() instanceof ItemBlock
                && InventoryUtils.isGoodBlockStack(held);
    }

    private void applyAim() {
        if (mc.thePlayer == null) return;

        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;
        float yawDelta = wrapYaw(desiredYaw - currentYaw);
        float pitchDelta = desiredPitch - currentPitch;

        // Small dt-independent step. It tracks the moving two-block-ahead
        // point without any prediction model.
        float yawStep = clampFloat(yawDelta, (float) -rotationSpeed.getInput() / 20.0F,
                (float) rotationSpeed.getInput() / 20.0F);
        float pitchStep = clampFloat(pitchDelta, (float) -rotationSpeed.getInput() / 24.0F,
                (float) rotationSpeed.getInput() / 24.0F);

        mc.thePlayer.rotationYaw = currentYaw + yawStep;
        mc.thePlayer.rotationYawHead = mc.thePlayer.rotationYaw;
        mc.thePlayer.rotationPitch = MathHelper.clamp_float(currentPitch + pitchStep, -90.0F, 90.0F);
    }

    private EnumFacing dominantHorizontalFacing(float yaw) {
        float wrapped = wrapYaw(yaw);
        if (wrapped >= -45.0F && wrapped < 45.0F) return EnumFacing.SOUTH;
        if (wrapped >= 45.0F && wrapped < 135.0F) return EnumFacing.WEST;
        if (wrapped >= -135.0F && wrapped < -45.0F) return EnumFacing.EAST;
        return EnumFacing.NORTH;
    }

    private double horizontalSpeed(double x, double z) {
        return Math.sqrt(x * x + z * z);
    }

    private float wrapYaw(float yaw) {
        while (yaw >= 180.0F) yaw -= 360.0F;
        while (yaw < -180.0F) yaw += 360.0F;
        return yaw;
    }

    private float clampFloat(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void restoreCamera() {
        // This simplified version only changes rotation while actively assisting.
        // The next tick naturally follows the enemy's current facing again.
    }

    private void clearTargetData() {
        target = null;
        recommendedPos = null;
        supportPos = null;
        supportFace = null;
        hitVec = null;
    }

    private void clearState() {
        clearTargetData();
        placementConsumed = false;
    }

    public EntityPlayer getTarget() {
        return target;
    }

    public BlockPos getRecommendedBlock() {
        return recommendedPos;
    }

    public EnumFacing getRecommendedFace() {
        return supportFace;
    }

    public Vec3 getRecommendedHitVec() {
        return hitVec;
    }

    public boolean isPlacementConsumed() {
        return placementConsumed;
    }
}
