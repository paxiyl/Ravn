package keystrokesmod.client.module.modules.combat.autostyle;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class AutoStyle extends Module {

    private static final TargetManager targetManager = new TargetManager();
    private static final FlickEngine flickEngine = new FlickEngine();

    private static SliderSetting targetRange;
    private static SliderSetting fov;
    private static TickSetting playersOnly;
    private static TickSetting lineOfSight;
    private static ComboSetting<TargetManager.TargetPriority> targetPriority;
    private static ComboSetting<TargetManager.TargetPoint> targetPoint;

    private static SliderSetting trackingStrength;
    private static SliderSetting maxTrackingSpeed;
    private static SliderSetting predictionTime;

    private static SliderSetting styleIntensity;
    private static ComboSetting<StylePreset> stylePreset;
    private static SliderSetting flickSpeed;
    private static SliderSetting flickAmplitudeMin;
    private static SliderSetting flickAmplitudeMax;
    private static SliderSetting flickDuration;

    private static SliderSetting overshootAmount;
    private static SliderSetting overshootAngle;

    private static SliderSetting recoverySpeed;

    private static SliderSetting pitchInfluence;
    private static SliderSetting pitchLimit;

    private static SliderSetting movementInfluence;
    private static SliderSetting strafeInfluence;

    private static SliderSetting timingVariation;
    private static SliderSetting amplitudeVariation;
    private static SliderSetting directionVariation;

    private static TickSetting flickOnAttack;
    private static TickSetting flickOnHit;
    private static TickSetting manualTrigger;
    private static TickSetting debugMode;

    private StyleProfile activeProfile;
    private long lastAttackTime = 0;
    private int lastAttackTick = 0;

    public AutoStyle() {
        super("AutoStyle", ModuleCategory.combat);

        this.registerSetting(new DescriptionSetting("Combat styling flick system"));
        this.registerSetting(new DescriptionSetting("--- Target ---"));
        this.registerSetting(targetRange = new SliderSetting("Target range", 4.0D, 2.0D, 8.0D, 0.1D));
        this.registerSetting(fov = new SliderSetting("FOV", 180.0D, 30.0D, 360.0D, 1.0D));
        this.registerSetting(playersOnly = new TickSetting("Players only", true));
        this.registerSetting(lineOfSight = new TickSetting("Line of sight", false));
        this.registerSetting(targetPriority = new ComboSetting("Target priority", TargetManager.TargetPriority.COMBO_LOCK));
        this.registerSetting(targetPoint = new ComboSetting("Target point", TargetManager.TargetPoint.DYNAMIC));

        this.registerSetting(new DescriptionSetting("--- Tracking ---"));
        this.registerSetting(trackingStrength = new SliderSetting("Tracking strength", 0.75D, 0.1D, 1.0D, 0.01D));
        this.registerSetting(maxTrackingSpeed = new SliderSetting("Max tracking speed", 660.0D, 100.0D, 1200.0D, 10.0D));
        this.registerSetting(predictionTime = new SliderSetting("Prediction time", 0.08D, 0.0D, 0.3D, 0.01D));

        this.registerSetting(new DescriptionSetting("--- Style ---"));
        this.registerSetting(stylePreset = new ComboSetting("Style preset", StylePreset.REFERENCE));
        this.registerSetting(styleIntensity = new SliderSetting("Style intensity", 70.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(flickSpeed = new SliderSetting("Flick speed override", 0.0D, 0.0D, 5.0D, 0.1D));
        this.registerSetting(flickAmplitudeMin = new SliderSetting("Min amplitude", 0.0D, 5.0D, 90.0D, 1.0D));
        this.registerSetting(flickAmplitudeMax = new SliderSetting("Max amplitude", 0.0D, 10.0D, 120.0D, 1.0D));
        this.registerSetting(flickDuration = new SliderSetting("Flick duration ms", 0.0D, 30.0D, 300.0D, 5.0D));

        this.registerSetting(new DescriptionSetting("--- Overshoot ---"));
        this.registerSetting(overshootAmount = new SliderSetting("Overshoot %", 0.0D, 0.0D, 40.0D, 1.0D));
        this.registerSetting(overshootAngle = new SliderSetting("Max overshoot angle", 0.0D, 0.0D, 35.0D, 0.5D));

        this.registerSetting(new DescriptionSetting("--- Recovery ---"));
        this.registerSetting(recoverySpeed = new SliderSetting("Recovery speed", 0.0D, 0.5D, 3.0D, 0.1D));

        this.registerSetting(new DescriptionSetting("--- Vertical ---"));
        this.registerSetting(pitchInfluence = new SliderSetting("Pitch influence", 0.0D, 0.0D, 0.5D, 0.01D));
        this.registerSetting(pitchLimit = new SliderSetting("Max pitch", 0.0D, 2.0D, 25.0D, 0.5D));

        this.registerSetting(new DescriptionSetting("--- Movement ---"));
        this.registerSetting(movementInfluence = new SliderSetting("Movement influence", 0.5D, 0.0D, 1.0D, 0.05D));
        this.registerSetting(strafeInfluence = new SliderSetting("Strafe influence", 0.5D, 0.0D, 1.0D, 0.05D));

        this.registerSetting(new DescriptionSetting("--- Variation ---"));
        this.registerSetting(timingVariation = new SliderSetting("Timing variation", 0.2D, 0.0D, 0.5D, 0.01D));
        this.registerSetting(amplitudeVariation = new SliderSetting("Amplitude variation", 0.2D, 0.0D, 0.5D, 0.01D));
        this.registerSetting(directionVariation = new SliderSetting("Direction variation", 0.25D, 0.0D, 0.5D, 0.01D));

        this.registerSetting(new DescriptionSetting("--- Trigger ---"));
        this.registerSetting(flickOnAttack = new TickSetting("Flick on attack", true));
        this.registerSetting(flickOnHit = new TickSetting("Flick on hit", true));
        this.registerSetting(manualTrigger = new TickSetting("Manual trigger (R)", false));
        this.registerSetting(debugMode = new TickSetting("Debug mode", false));
    }

    @Override
    public void onEnable() {
        targetManager.reset();
        flickEngine.reset();
        activeProfile = buildProfile();
        lastAttackTime = 0;
        lastAttackTick = 0;
    }

    @Override
    public void onDisable() {
        flickEngine.cancelFlick();
        targetManager.reset();
    }

    @Override
    public void guiUpdate() {
        activeProfile = buildProfile();
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!Utils.Player.isPlayerInGame()) return;

        if (fe.getEvent() instanceof AttackEntityEvent) {
            AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
            if (event.target instanceof EntityPlayer) {
                EntityPlayer hit = (EntityPlayer) event.target;
                long now = System.nanoTime();
                int nowTick = mc.thePlayer.ticksExisted;

                targetManager.lockTarget(hit);
                targetManager.updateCombo();

                boolean attackTrigger = flickOnAttack.isToggled() &&
                    (now - lastAttackTime) > 80_000_000;
                boolean hitTrigger = flickOnHit.isToggled() &&
                    hit.hurtTime > 0;

                lastAttackTime = now;
                lastAttackTick = nowTick;

                if ((attackTrigger || hitTrigger) && flickEngine.canFlick(now)) {
                    flickEngine.startFlick(hit, activeProfile, styleIntensity.getInput(), movementInfluence.getInput());
                }
            }
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (mc.currentScreen != null) {
            flickEngine.cancelFlick();
            return;
        }

        if (manualTrigger.isToggled()) {
            manualTrigger.disable();
            EntityPlayer target = targetManager.getLockedTarget();
            if (target == null) {
                target = targetManager.findTarget(
                    targetRange.getInput(), fov.getInput(),
                    playersOnly.isToggled(), lineOfSight.isToggled(),
                    targetPriority.getMode()
                );
            }
            if (target != null && flickEngine.canFlick(System.nanoTime())) {
                targetManager.lockTarget(target);
                flickEngine.startFlick(target, activeProfile, styleIntensity.getInput(), movementInfluence.getInput());
            }
        }

        if (flickEngine.isFlicking()) {
            applyFlickRotation(e);
            return;
        }

        if (flickEngine.getState() == FlickEngine.State.REACQUIRE) {
            flickEngine.onReacquire();
        }

        if (flickEngine.getState() == FlickEngine.State.COOLDOWN) {
            flickEngine.onCooldownComplete();
        }

        EntityPlayer target = targetManager.getLockedTarget();
        if (target == null || target.isDead || !target.isEntityAlive()) {
            target = targetManager.findTarget(
                targetRange.getInput(), fov.getInput(),
                playersOnly.isToggled(), lineOfSight.isToggled(),
                targetPriority.getMode()
            );
            if (target != null) {
                targetManager.lockTarget(target);
                flickEngine.onTargetFound();
                if (flickEngine.getState() == FlickEngine.State.TARGET_ACQUIRED) {
                    flickEngine.transitionToTracking();
                }
            } else {
                flickEngine.onTargetLost();
                return;
            }
        } else {
            if (mc.thePlayer.getDistanceToEntity(target) > targetRange.getInput() + 1.0) {
                flickEngine.onTargetLost();
                return;
            }
            targetManager.updateCombo();
            if (flickEngine.getState() == FlickEngine.State.IDLE) {
                flickEngine.onTargetFound();
                flickEngine.transitionToTracking();
            }
        }

        if (flickEngine.getState() == FlickEngine.State.TRACKING && target != null) {
            applyTrackingRotation(target, e);
        }
    }

    private void applyTrackingRotation(EntityPlayer target, UpdateEvent e) {
        Rotation desired = targetManager.getRotationToTarget(
            target, targetPoint.getMode(), predictionTime.getInput(), System.nanoTime()
        );
        if (desired == null) return;

        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;

        float yawError = Rotation.angleDiff(currentYaw, desired.yaw);
        float pitchError = desired.pitch - currentPitch;

        double strength = trackingStrength.getInput();
        double maxSpeed = maxTrackingSpeed.getInput();
        double dt = 0.016;

        double yawStep = yawError * strength * dt * 15.0;
        yawStep = Math.max(-maxSpeed * dt, Math.min(maxSpeed * dt, yawStep));

        double pitchStep = pitchError * strength * dt * 12.0;
        pitchStep = Math.max(-maxSpeed * 0.6 * dt, Math.min(maxSpeed * 0.6 * dt, pitchStep));

        if (Math.abs(yawError) < 0.3) yawStep = 0;
        if (Math.abs(pitchError) < 0.3) pitchStep = 0;

        mc.thePlayer.rotationYaw = (float) (currentYaw + yawStep);
        mc.thePlayer.rotationPitch = Rotation.clampPitch((float)(currentPitch + pitchStep));

        mc.thePlayer.rotationYawHead = mc.thePlayer.rotationYaw;
        mc.thePlayer.renderYawOffset = mc.thePlayer.rotationYaw;

        e.setYaw(mc.thePlayer.rotationYaw);
        e.setPitch(mc.thePlayer.rotationPitch);
    }

    private void applyFlickRotation(UpdateEvent e) {
        Rotation rot = flickEngine.evaluateFlick();
        if (rot != null) {
            mc.thePlayer.rotationYaw = rot.yaw;
            mc.thePlayer.rotationPitch = rot.pitch;
            mc.thePlayer.rotationYawHead = rot.yaw;
            mc.thePlayer.renderYawOffset = rot.yaw;
            e.setYaw(rot.yaw);
            e.setPitch(rot.pitch);
        }
    }

    private StyleProfile buildProfile() {
        StyleProfile base;
        switch (stylePreset.getMode()) {
            case SUBTLE: base = StyleProfile.subtle(); break;
            case CLEAN: base = StyleProfile.clean(); break;
            case AGGRESSIVE: base = StyleProfile.aggressive(); break;
            case BOXING: base = StyleProfile.boxing(); break;
            case EXTREME: base = StyleProfile.extreme(); break;
            case CUSTOM: base = StyleProfile.reference(); break;
            default: base = StyleProfile.reference(); break;
        }

        double intensity = styleIntensity.getInput();

        if (stylePreset.getMode() == StylePreset.CUSTOM) {
            base = base.withIntensity(intensity);
            return new StyleProfile(
                "CUSTOM",
                flickSpeed.getInput() > 0 ? flickSpeed.getInput() : base.flickSpeedMultiplier,
                flickAmplitudeMin.getInput() > 0 ? flickAmplitudeMin.getInput() : base.flickAmplitudeMin,
                flickAmplitudeMax.getInput() > 0 ? flickAmplitudeMax.getInput() : base.flickAmplitudeMax,
                overshootAmount.getInput() > 0 ? overshootAmount.getInput() / 100.0 : base.overshootPercent,
                overshootAngle.getInput() > 0 ? overshootAngle.getInput() : base.overshootAngleMax,
                recoverySpeed.getInput() > 0 ? recoverySpeed.getInput() : base.recoverySpeedMultiplier,
                pitchInfluence.getInput() > 0 ? pitchInfluence.getInput() : base.pitchInfluence,
                pitchLimit.getInput() > 0 ? pitchLimit.getInput() : base.pitchMax,
                base.trackingStrength,
                base.maxTrackingSpeed,
                base.cooldownMs,
                timingVariation.getInput() > 0 ? timingVariation.getInput() : base.timingVariation,
                amplitudeVariation.getInput() > 0 ? amplitudeVariation.getInput() : base.amplitudeVariation,
                directionVariation.getInput() > 0 ? directionVariation.getInput() : base.directionVariation,
                base.movementInfluence
            );
        }

        return base.withIntensity(intensity);
    }

    public static TargetManager getTargetManager() { return targetManager; }
    public static FlickEngine getFlickEngine() { return flickEngine; }

    public enum StylePreset {
        SUBTLE, CLEAN, AGGRESSIVE, BOXING, REFERENCE, EXTREME, CUSTOM
    }
}
