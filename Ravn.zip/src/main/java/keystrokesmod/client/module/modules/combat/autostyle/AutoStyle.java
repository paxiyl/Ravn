package keystrokesmod.client.module.modules.combat.autostyle;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class AutoStyle extends Module {

    private static final TargetManager targetMgr = new TargetManager();
    private static final FlickEngine flick = new FlickEngine();

    private static ComboSetting<Style> style;
    private static SliderSetting range;
    private static SliderSetting intensity;
    private static SliderSetting pitchAmt;
    private static SliderSetting cooldownMs;
    private static TickSetting hitOnly;
    private static TickSetting manualTrigger;
    private static TickSetting debug;

    private double velYaw = 0, velPitch = 0;
    private long lastFlickEnd = 0;
    private int prevHurtTime = 0;
    private Style lastStyle = null;

    public AutoStyle() {
        super("AutoStyle", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Combat styling flicks on hit"));
        this.registerSetting(style = new ComboSetting("Style", Style.REFERENCE));
        this.registerSetting(range = new SliderSetting("Range", 4.0D, 2.0D, 8.0D, 0.1D));
        this.registerSetting(intensity = new SliderSetting("Intensity", 75.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(pitchAmt = new SliderSetting("Pitch amount", 10.0D, 0.0D, 30.0D, 0.5D));
        this.registerSetting(cooldownMs = new SliderSetting("Cooldown ms", 280.0D, 100.0D, 800.0D, 10.0D));
        this.registerSetting(hitOnly = new TickSetting("Flick on hit only", true));
        this.registerSetting(manualTrigger = new TickSetting("Manual trigger (V)", false));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public void onEnable() {
        targetMgr.reset();
        flick.reset();
        velYaw = 0;
        velPitch = 0;
        lastFlickEnd = 0;
        prevHurtTime = 0;
        lastStyle = null;
        applyPreset(style.getMode());
    }

    @Override
    public void onDisable() {
        targetMgr.reset();
        flick.reset();
    }

    @Override
    public void guiUpdate() {
        Style current = style.getMode();
        if (current != lastStyle) {
            applyPreset(current);
            lastStyle = current;
        }
    }

    private void applyPreset(Style s) {
        switch (s) {
            case SUBTLE:
                intensity.setValue(25); pitchAmt.setValue(3); cooldownMs.setValue(400); hitOnly.enable(); break;
            case CLEAN:
                intensity.setValue(45); pitchAmt.setValue(6); cooldownMs.setValue(350); hitOnly.enable(); break;
            case NORMAL:
                intensity.setValue(60); pitchAmt.setValue(8); cooldownMs.setValue(300); hitOnly.enable(); break;
            case AGGRESSIVE:
                intensity.setValue(80); pitchAmt.setValue(12); cooldownMs.setValue(220); hitOnly.enable(); break;
            case BOXING:
                intensity.setValue(90); pitchAmt.setValue(10); cooldownMs.setValue(180); hitOnly.disable(); break;
            case REFERENCE:
                intensity.setValue(75); pitchAmt.setValue(10); cooldownMs.setValue(280); hitOnly.enable(); break;
            case CUSTOM:
                break;
        }
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!Utils.Player.isPlayerInGame()) return;
        if (!(fe.getEvent() instanceof AttackEntityEvent)) return;

        AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
        if (!(event.target instanceof EntityPlayer)) return;

        EntityPlayer hit = (EntityPlayer) event.target;
        targetMgr.lockTarget(hit);

        long now = System.nanoTime();
        boolean canFlick = now - lastFlickEnd > (long)(cooldownMs.getInput() * 1_000_000);

        boolean shouldFlick;
        if (hitOnly.isToggled()) {
            shouldFlick = hit.hurtTime > 0 && prevHurtTime == 0;
        } else {
            shouldFlick = canFlick;
        }

        prevHurtTime = hit.hurtTime;

        if (shouldFlick && canFlick && !flick.isFlicking()) {
            flick.startFlick(hit, intensity.getInput(), pitchAmt.getInput());
            lastFlickEnd = now + flick.getTrajectoryDurationNanos();
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (mc.currentScreen != null) { flick.reset(); return; }

        if (manualTrigger.isToggled()) {
            manualTrigger.disable();
            EntityPlayer t = targetMgr.getLockedTarget();
            if (t == null) t = findTarget();
            if (t != null && !flick.isFlicking()) {
                targetMgr.lockTarget(t);
                flick.startFlick(t, intensity.getInput(), pitchAmt.getInput());
                lastFlickEnd = System.nanoTime() + flick.getTrajectoryDurationNanos();
            }
        }

        if (flick.isFlicking()) {
            Rotation rot = flick.evaluate();
            if (rot != null) {
                mc.thePlayer.rotationYaw = rot.yaw;
                mc.thePlayer.rotationPitch = rot.pitch;
                mc.thePlayer.rotationYawHead = rot.yaw;
                mc.thePlayer.renderYawOffset = rot.yaw;
                e.setYaw(rot.yaw);
                e.setPitch(rot.pitch);
            }
            return;
        }

        EntityPlayer target = targetMgr.getLockedTarget();
        if (target == null || target.isDead || !target.isEntityAlive()
            || mc.thePlayer.getDistanceToEntity(target) > range.getInput() + 1.0) {
            target = findTarget();
            if (target != null) {
                targetMgr.lockTarget(target);
            } else {
                targetMgr.reset();
                velYaw = 0;
                velPitch = 0;
                return;
            }
        }

        applyTracking(target, e);
    }

    private void applyTracking(EntityPlayer target, UpdateEvent e) {
        float desiredYaw = getDesiredYaw(target);
        float desiredPitch = getDesiredPitch(target);

        float errYaw = Rotation.angleDiff(mc.thePlayer.rotationYaw, desiredYaw);
        float errPitch = desiredPitch - mc.thePlayer.rotationPitch;

        double omega = 4.0 + intensity.getInput() * 0.06;
        double stiffness = omega * omega;
        double damping = 2.0 * omega;
        double dt = 0.016;

        double newYawVel = velYaw + (stiffness * errYaw - damping * velYaw) * dt;
        double yawStep = (velYaw + newYawVel) * 0.5 * dt;
        velYaw = newYawVel;

        double maxStep = 500.0 * dt;
        yawStep = Math.max(-maxStep, Math.min(maxStep, yawStep));
        if (Math.abs(errYaw) < 0.4) { yawStep = 0; velYaw *= Math.exp(-8.0 * dt); }

        double newPitchVel = velPitch + (stiffness * 0.85 * errPitch - damping * 0.85 * velPitch) * dt;
        double pitchStep = (velPitch + newPitchVel) * 0.5 * dt;
        velPitch = newPitchVel;

        double maxPitchStep = maxStep * 0.6;
        pitchStep = Math.max(-maxPitchStep, Math.min(maxPitchStep, pitchStep));
        if (Math.abs(errPitch) < 0.4) { pitchStep = 0; velPitch *= Math.exp(-8.0 * dt); }

        mc.thePlayer.rotationYaw = (float) (mc.thePlayer.rotationYaw + yawStep);
        mc.thePlayer.rotationPitch = Rotation.clampPitch((float)(mc.thePlayer.rotationPitch + pitchStep));
        mc.thePlayer.rotationYawHead = mc.thePlayer.rotationYaw;
        mc.thePlayer.renderYawOffset = mc.thePlayer.rotationYaw;

        e.setYaw(mc.thePlayer.rotationYaw);
        e.setPitch(mc.thePlayer.rotationPitch);
    }

    private EntityPlayer findTarget() {
        return targetMgr.findTarget(range.getInput(), 180.0, true, false, TargetManager.TargetPriority.COMBO_LOCK);
    }

    private float getDesiredYaw(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    private float getDesiredPitch(EntityPlayer target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * 0.5) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return Rotation.clampPitch((float) (-Math.toDegrees(Math.atan2(dy, dist))));
    }

    public static TargetManager getTargetManager() { return targetMgr; }
    public static FlickEngine getFlickEngine() { return flick; }

    public enum Style {
        SUBTLE, CLEAN, NORMAL, AGGRESSIVE, BOXING, REFERENCE, CUSTOM
    }
}
