package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import org.lwjgl.input.Mouse;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.InventoryUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * BlockStop coach for Minecraft 1.8.9.
 *
 * This module predicts a nearby opponent's movement, chooses a legal block-stop
 * candidate, and assists the player's camera toward the placement hit vector while
 * right-click is held. The actual click/placement remains manual.
 */
public class BlockStop extends Module {
    public static SliderSetting targetRange;
    public static SliderSetting predictionTicks;
    public static SliderSetting safeDistance;
    public static SliderSetting maxYaw;
    public static SliderSetting maxReach;
    public static SliderSetting candidateRadius;
    public static TickSetting renderPreview;
    public static TickSetting requireBlockHeld;
    public static SliderSetting approachThreshold;
    public static SliderSetting approachAlignment;
    public static SliderSetting rotationSpeed;
    private boolean cameraAssistActive;
    private float savedYaw;
    private float savedPitch;
    public static TickSetting rightClickOnly;
    public static SliderSetting rotationSpeed;
    public static SliderSetting minHeight;
    public static SliderSetting maxHeight;

    private EntityPlayer target;
    private Candidate best;
    private Timing timing = Timing.IDLE;
    private double targetSpeed;
    private double closingSpeed;
    private long lastUpdateMs;

    private boolean cameraAssistActive;
    private float restoreYaw;
    private float restorePitch;
    private long lastCameraFrameNanos = -1L;

    public BlockStop() {
        super("BlockStop", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Predictive block-stop training coach; placement remains manual."));
        this.registerSetting(targetRange = new SliderSetting("Target range", 8.0D, 3.0D, 12.0D, 0.5D));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction ticks", 3.0D, 1.0D, 8.0D, 1.0D));
        this.registerSetting(safeDistance = new SliderSetting("Safe distance", 1.35D, 0.8D, 2.5D, 0.05D));
        this.registerSetting(maxYaw = new SliderSetting("Max aim angle", 75.0D, 25.0D, 180.0D, 5.0D));
        this.registerSetting(maxReach = new SliderSetting("Reach", 4.5D, 3.0D, 5.0D, 0.1D));
        this.registerSetting(candidateRadius = new SliderSetting("Candidate radius", 2.0D, 1.0D, 3.0D, 0.5D));
        this.registerSetting(renderPreview = new TickSetting("Preview", false));
        this.registerSetting(requireBlockHeld = new TickSetting("Require block", true));
        this.registerSetting(approachThreshold = new SliderSetting("Approach speed", 0.08D, 0.02D, 0.35D, 0.01D));
        this.registerSetting(approachAlignment = new SliderSetting("Approach alignment", 0.60D, 0.20D, 1.00D, 0.05D));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 35.0D, 5.0D, 180.0D, 5.0D));
        this.registerSetting(rightClickOnly = new TickSetting("Aim while placing", true));
        this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", 720.0D, 180.0D, 1440.0D, 60.0D));
        this.registerSetting(minHeight = new SliderSetting("Min height", 0.0D, 0.0D, 255.0D, 1.0D));
        this.registerSetting(maxHeight = new SliderSetting("Max height", 255.0D, 0.0D, 255.0D, 1.0D));
        setVisableInHud(false);
    }

    @Override
    public void onEnable() {
        clear();
        lastCameraFrameNanos = -1L;
    }

    @Override
    public void onDisable() {
        restoreCamera();
        clear();
        lastCameraFrameNanos = -1L;
    }

    @Subscribe
    public void onUpdate(UpdateEvent event) {
        if (!event.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null) {
            clear();
            return;
        }
        if (mc.currentScreen != null) {
            clear();
            return;
        }
        if (requireBlockHeld.isToggled() && !hasPlaceableBlock()) {
            restoreCamera();
            clear();
            return;
        }

        EntityPlayer nextTarget = acquireTarget();
        if (nextTarget == null) {
            restoreCamera();
            clear();
            return;
        }

        target = nextTarget;
        targetSpeed = horizontalSpeed(target.motionX, target.motionZ);
        closingSpeed = computeClosingSpeed(target);
        best = findBestCandidate(target);
        timing = classifyTiming(target, best);
        lastUpdateMs = System.currentTimeMillis();

        if (best != null && Mouse.isButtonDown(1)) {
            applyCameraAssist(best);
        } else {
            restoreCamera();
        }
    }

    @Subscribe
    public void onRender(Render2DEvent event) {
        if (!Utils.Client.currentScreenMinecraft() || !Utils.Player.isPlayerInGame() || mc.thePlayer == null) {
            restoreCamera();
            return;
        }

        boolean placing = Mouse.isButtonDown(1) && (!rightClickOnly.isToggled() || hasPlaceableBlock());
        if (!placing || best == null || timing == Timing.IDLE || !isHeightAllowed(best.pos)) {
            restoreCamera();
            return;
        }

        if (!cameraAssistActive) {
            cameraAssistActive = true;
            restoreYaw = mc.thePlayer.rotationYaw;
            restorePitch = mc.thePlayer.rotationPitch;
        }

        long now = System.nanoTime();
        double dt = lastCameraFrameNanos < 0L ? 0.016D : (now - lastCameraFrameNanos) * 1.0E-9D;
        lastCameraFrameNanos = now;
        if (dt < 0.001D) dt = 0.001D;
        if (dt > 0.05D) dt = 0.05D;

        float desiredYaw = best.yaw;
        float desiredPitch = best.pitch;
        double maxStep = rotationSpeed.getInput() * dt;
        double yawDelta = wrapYawDelta(mc.thePlayer.rotationYaw, desiredYaw);
        double pitchDelta = desiredPitch - mc.thePlayer.rotationPitch;

        mc.thePlayer.rotationYaw = (float) (mc.thePlayer.rotationYaw + clamp(yawDelta, -maxStep, maxStep));
        mc.thePlayer.rotationPitch = (float) MathHelper.clamp_double(
                mc.thePlayer.rotationPitch + clamp(pitchDelta, -maxStep * 0.85D, maxStep * 0.85D), -90.0D, 90.0D);
    }

    @Subscribe
    public void onRenderWorld(ForgeEvent event) {
        if (!(event.getEvent() instanceof RenderWorldLastEvent)) return;
        if (!renderPreview.isToggled() || best == null || !Utils.Player.isPlayerInGame()) return;
        drawCandidate(best.pos, timingColor(timing));
    }

    private EntityPlayer acquireTarget() {
        double rangeSq = targetRange.getInput() * targetRange.getInput();
        EntityPlayer bestTarget = null;
        double bestScore = Double.POSITIVE_INFINITY;

        for (Object obj : mc.theWorld.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) obj;
            if (p == mc.thePlayer || p.isDead || p.getHealth() <= 0.0F) continue;
            if (p.getDistanceSqToEntity(mc.thePlayer) > rangeSq) continue;
            if (p.isSpectator()) continue;

            double closing = computeClosingSpeed(p);
            double speed = horizontalSpeed(p.motionX, p.motionZ);
            Vec3 future = predict(p, Math.max(1, (int) predictionTicks.getInput()));
            double futureDistance = horizontalDistance(future.xCoord, future.zCoord, mc.thePlayer.posX, mc.thePlayer.posZ);
            boolean approaching = closing > 0.01D || futureDistance < p.getDistanceToEntity(mc.thePlayer);
            if (!approaching && speed < 0.03D) continue;

            double score = p.getDistanceSqToEntity(mc.thePlayer) - closing * 2.0D - speed * 0.5D;
            if (score < bestScore) {
                bestScore = score;
                bestTarget = p;
            }
        }
        return bestTarget;
    }

    private Candidate findBestCandidate(EntityPlayer enemy) {
        Vec3 predicted = predict(enemy, (int) predictionTicks.getInput());
        int centerX = MathHelper.floor_double(predicted.xCoord);
        int centerY = MathHelper.floor_double(enemy.posY);
        int centerZ = MathHelper.floor_double(predicted.zCoord);

        List<Candidate> candidates = new ArrayList<>();
        int radius = (int) Math.ceil(candidateRadius.getInput());

        for (int x = centerX - radius; x <= centerX + radius; x++) {
            for (int y = centerY - 1; y <= centerY + 1; y++) {
                for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!isHeightAllowed(pos)) continue;
                    if (!isReplaceable(pos)) continue;

                    EnumFacing support = findBestSupportFace(pos);
                    if (support == null) continue;

                    double distance = distanceToPlacement(pos);
                    if (distance > maxReach.getInput()) continue;

                    if (wouldIntersectPlayer(enemy, pos)) continue;
                    if (wouldTrapLocalPlayer(pos)) continue;

                    // The camera must target the FACE OF THE ADJACENT SUPPORT BLOCK,
                    // not the empty block we intend to place.
                    BlockPos supportPos = pos.offset(support.getOpposite());
                    Vec3 hit = hitVector(supportPos, support);
                    Rotation rotation = rotationsTo(hit);
                    float yaw = rotation.yaw;
                    float pitch = rotation.pitch;
                    double yawDelta = Math.abs(wrapYawDelta(mc.thePlayer.rotationYaw, yaw));
                    if (yawDelta > maxYaw.getInput()) continue;

                    double separation = horizontalDistanceToBlock(enemy, pos);
                    double predictedSeparation = horizontalDistance(predicted.xCoord, predicted.zCoord,
                            pos.getX() + 0.5D, pos.getZ() + 0.5D);
                    double intercept = Math.abs(predictedSeparation - 0.15D);
                    double approachPenalty = Math.max(0.0D, safeDistance.getInput() - separation) * 5.0D;
                    double localPenalty = Math.max(0.0D, 1.1D - horizontalDistanceToBlock(mc.thePlayer, pos)) * 4.0D;
                    double anglePenalty = yawDelta / 45.0D;

                    double score = intercept * 8.0D + distance * 2.0D + anglePenalty
                            + approachPenalty + localPenalty;

                    Timing candidateTiming = classifyTiming(enemy, new Candidate(pos, support, hit, yaw, pitch, score));
                    if (candidateTiming == Timing.READY) score -= 2.0D;
                    else if (candidateTiming == Timing.TOO_EARLY) score += 0.8D;
                    else if (candidateTiming == Timing.TOO_LATE) score += 3.0D;

                    candidates.add(new Candidate(pos, support, hit, yaw, pitch, score));
                }
            }
        }

        candidates.sort(Comparator.comparingDouble(c -> c.score));
        return candidates.isEmpty() ? null : candidates.get(0);
    }

    private EnumFacing findBestSupportFace(BlockPos placePos) {
        EnumFacing[] faces = EnumFacing.values();
        EnumFacing bestFace = null;
        double bestDistance = Double.MAX_VALUE;

        for (EnumFacing face : faces) {
            BlockPos support = placePos.offset(face.getOpposite());
            if (!canUseAsSupport(support)) continue;
            double d = mc.thePlayer.getDistanceSq(support.getX() + 0.5D,
                    support.getY() + 0.5D, support.getZ() + 0.5D);
            if (d < bestDistance) {
                bestDistance = d;
                bestFace = face;
            }
        }

        if (bestFace == null && canUseAsSupport(placePos.down())) return EnumFacing.UP;
        return bestFace;
    }

    private boolean canUseAsSupport(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block == Blocks.air || block instanceof BlockLiquid) return false;
        Material material = block.getMaterial();
        return material != Material.air && material != Material.lava && material != Material.water;
    }

    private boolean isReplaceable(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block == Blocks.air || block.getMaterial().isReplaceable();
    }

    private boolean wouldIntersectPlayer(EntityPlayer enemy, BlockPos pos) {
        AxisAlignedBB blockBB = new AxisAlignedBB(
                pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0D, pos.getY() + 1.0D, pos.getZ() + 1.0D
        );
        AxisAlignedBB enemyBB = enemy.getEntityBoundingBox();
        return blockBB.intersectsWith(enemyBB.expand(0.01D, 0.01D, 0.01D));
    }

    private boolean wouldTrapLocalPlayer(BlockPos pos) {
        AxisAlignedBB blockBB = new AxisAlignedBB(
                pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0D, pos.getY() + 1.0D, pos.getZ() + 1.0D
        );
        return blockBB.intersectsWith(mc.thePlayer.getEntityBoundingBox().expand(0.03D, 0.0D, 0.03D));
    }

    private Vec3 predict(EntityPlayer p, int ticks) {
        if (approachAlignment(p) < approachAlignment.getInput()
                || computeClosingSpeed(p) < approachThreshold.getInput()) {
            return new Vec3(p.posX, p.posY, p.posZ);
        }

        double px = p.posX;
        double pz = p.posZ;
        double vx = p.motionX;
        double vz = p.motionZ;
        double damp = 1.0D;

        // Short, damped extrapolation. Only used after the approach-direction
        // gate above succeeds, preventing lateral/retreating targets from
        // generating fake block-stop predictions.
        for (int i = 0; i < ticks; i++) {
            px += vx * damp;
            pz += vz * damp;
            damp *= 0.91D;
        }
        return new Vec3(px, p.posY, pz);
    }

    private double computeClosingSpeed(EntityPlayer p) {
        double dx = mc.thePlayer.posX - p.posX;
        double dz = mc.thePlayer.posZ - p.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1.0E-4D) return 0.0D;
        double nx = dx / dist;
        double nz = dz / dist;
        double relativeX = p.motionX - mc.thePlayer.motionX;
        double relativeZ = p.motionZ - mc.thePlayer.motionZ;
        return -(relativeX * nx + relativeZ * nz);
    }

    private double approachAlignment(EntityPlayer p) {
        double vx = p.motionX;
        double vz = p.motionZ;
        double speed = Math.sqrt(vx * vx + vz * vz);
        if (speed < 1.0E-4D) return 0.0D;

        double tx = mc.thePlayer.posX - p.posX;
        double tz = mc.thePlayer.posZ - p.posZ;
        double distance = Math.sqrt(tx * tx + tz * tz);
        if (distance < 1.0E-4D) return 1.0D;

        return (vx * (tx / distance) + vz * (tz / distance)) / speed;
    }

    private double horizontalSpeed(double x, double z) {
        return Math.sqrt(x * x + z * z);
    }

    private double distanceToPlacement(BlockPos pos) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        EnumFacing face = findBestSupportFace(pos);
        if (face == null) return Double.MAX_VALUE;
        BlockPos support = pos.offset(face.getOpposite());
        return eyes.distanceTo(hitVector(support, face));
    }

    private Vec3 hitVector(BlockPos pos, EnumFacing face) {
        double inset = 0.08D;
        switch (face) {
            case UP:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 1.0D - inset, pos.getZ() + 0.5D);
            case DOWN:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + inset, pos.getZ() + 0.5D);
            case NORTH:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + inset);
            case SOUTH:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 1.0D - inset);
            case WEST:
                return new Vec3(pos.getX() + inset, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            case EAST:
                return new Vec3(pos.getX() + 1.0D - inset, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            default:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
        }
    }

    private Rotation rotationsTo(Vec3 point) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        double dx = point.xCoord - eyes.xCoord;
        double dy = point.yCoord - eyes.yCoord;
        double dz = point.zCoord - eyes.zCoord;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        return new Rotation(wrapYaw(yaw), MathHelper.clamp_float(pitch, -90.0F, 90.0F));
    }

    private Timing classifyTiming(EntityPlayer enemy, Candidate candidate) {
        if (enemy == null || candidate == null) return Timing.IDLE;

        double distance = horizontalDistanceToBlock(enemy, candidate.pos);
        double speed = Math.max(0.02D, targetSpeed);
        double seconds = Math.max(0.0D, (distance - 0.15D) / speed);
        double ticks = seconds * 20.0D;

        if (targetSpeed < 0.03D && closingSpeed < 0.03D) return Timing.IDLE;
        if (ticks > predictionTicks.getInput() + 1.5D) return Timing.TOO_EARLY;
        if (ticks < -0.25D || distance < 0.25D) return Timing.TOO_LATE;
        return ticks <= 1.25D ? Timing.READY : Timing.TOO_EARLY;
    }

    private double horizontalDistanceToBlock(EntityPlayer p, BlockPos pos) {
        return horizontalDistance(p.posX, p.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D);
    }

    private double horizontalDistance(double ax, double az, double bx, double bz) {
        double dx = ax - bx;
        double dz = az - bz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private boolean hasPlaceableBlock() {
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held != null && held.getItem() instanceof ItemBlock && InventoryUtils.isGoodBlockStack(held)) return true;
        return false;
    }

    private void drawCandidate(BlockPos pos, int color) {
        double rx = pos.getX() - mc.getRenderManager().viewerPosX;
        double ry = pos.getY() - mc.getRenderManager().viewerPosY;
        double rz = pos.getZ() - mc.getRenderManager().viewerPosZ;
        AxisAlignedBB bb = new AxisAlignedBB(rx, ry, rz, rx + 1.0D, ry + 1.0D, rz + 1.0D);

        float r = ((color >> 16) & 255) / 255.0F;
        float g = ((color >> 8) & 255) / 255.0F;
        float b = (color & 255) / 255.0F;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glLineWidth(2.0F);
        GL11.glColor4f(r, g, b, 0.9F);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private int timingColor(Timing value) {
        switch (value) {
            case READY: return 0xFF39D353;
            case TOO_EARLY: return 0xFFFFCC33;
            case TOO_LATE: return 0xFFFF5555;
            default: return 0xFFAAAAAA;
        }
    }

    private void restoreCamera() {
        if (!cameraAssistActive || mc.thePlayer == null) return;
        mc.thePlayer.rotationYaw = restoreYaw;
        mc.thePlayer.rotationPitch = restorePitch;
        cameraAssistActive = false;
        lastCameraFrameNanos = -1L;
    }

    private void applyCameraAssist(Candidate candidate) {
        if (candidate == null || mc.thePlayer == null) return;
        if (!cameraAssistActive) {
            savedYaw = mc.thePlayer.rotationYaw;
            savedPitch = mc.thePlayer.rotationPitch;
            cameraAssistActive = true;
        }

        float yawDelta = wrapYawDelta(mc.thePlayer.rotationYaw, candidate.yaw);
        float pitchDelta = candidate.pitch - mc.thePlayer.rotationPitch;
        float step = (float) Math.max(1.0D, rotationSpeed.getInput() / 20.0D);
        float yawStep = MathHelper.clamp_float(yawDelta, -step, step);
        float pitchStep = MathHelper.clamp_float(pitchDelta, -step, step);

        mc.thePlayer.rotationYaw = wrapYaw(mc.thePlayer.rotationYaw + yawStep);
        mc.thePlayer.rotationYawHead = mc.thePlayer.rotationYaw;
        mc.thePlayer.rotationPitch = MathHelper.clamp_float(mc.thePlayer.rotationPitch + pitchStep, -90.0F, 90.0F);
    }

    private void restoreCamera() {
        if (!cameraAssistActive || mc.thePlayer == null) return;
        mc.thePlayer.rotationYaw = savedYaw;
        mc.thePlayer.rotationYawHead = savedYaw;
        mc.thePlayer.rotationPitch = savedPitch;
        cameraAssistActive = false;
    }

    private void clear() {
        if (cameraAssistActive) restoreCamera();
        target = null;
        best = null;
        timing = Timing.IDLE;
        targetSpeed = 0.0D;
        closingSpeed = 0.0D;
        lastUpdateMs = 0L;
    }

    public EntityPlayer getTarget() {
        return target;
    }

    public BlockPos getRecommendedBlock() {
        return best == null ? null : best.pos;
    }

    public EnumFacing getRecommendedFace() {
        return best == null ? null : best.face;
    }

    public Vec3 getRecommendedHitVec() {
        return best == null ? null : best.hitVec;
    }

    public Timing getTiming() {
        return timing;
    }

    public long getLastUpdateMs() {
        return lastUpdateMs;
    }

    private boolean isHeightAllowed(BlockPos pos) {
        double min = Math.min(minHeight.getInput(), maxHeight.getInput());
        double max = Math.max(minHeight.getInput(), maxHeight.getInput());
        return pos.getY() >= min && pos.getY() <= max;
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float wrapYaw(float yaw) {
        yaw %= 360.0F;
        if (yaw >= 180.0F) yaw -= 360.0F;
        if (yaw < -180.0F) yaw += 360.0F;
        return yaw;
    }

    private static float wrapYawDelta(float from, float to) {
        float delta = to - from;
        while (delta > 180.0F) delta -= 360.0F;
        while (delta < -180.0F) delta += 360.0F;
        return delta;
    }

    public enum Timing {
        IDLE,
        TOO_EARLY,
        READY,
        TOO_LATE
    }

    private static class Rotation {
        final float yaw;
        final float pitch;
        Rotation(float yaw, float pitch) {
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    private static class Candidate {
        final BlockPos pos;
        final EnumFacing face;
        final Vec3 hitVec;
        final float yaw;
        final float pitch;
        final double score;

        Candidate(BlockPos pos, EnumFacing face, Vec3 hitVec, float yaw, float pitch, double score) {
            this.pos = pos;
            this.face = face;
            this.hitVec = hitVec;
            this.yaw = yaw;
            this.pitch = pitch;
            this.score = score;
        }
    }
}
