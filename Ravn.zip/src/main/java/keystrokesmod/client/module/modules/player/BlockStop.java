package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.InventoryUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * BlockStop coach for Minecraft 1.8.9.
 *
 * This module analyzes approaching players and selects a legal block position
 * that is likely to intersect their short-term movement corridor. It does not
 * rotate the player, click, place blocks, change inventory, or send placement
 * packets. The selected candidate can be used by a trainer/debug renderer.
 */
public class BlockStop extends Module {
    public static SliderSetting targetRange;
    public static SliderSetting predictionTicks;
    public static SliderSetting safeDistance;
    public static SliderSetting maxYaw;
    public static SliderSetting maxReach;
    public static SliderSetting candidateRadius;
    public static TickSetting renderPreview;
    public static TickSetting requireBlockHeld;

    private EntityPlayer target;
    private Candidate best;
    private Timing timing = Timing.IDLE;
    private double targetSpeed;
    private double closingSpeed;
    private long lastUpdateMs;

    public BlockStop() {
        super("BlockStop", ModuleCategory.player);
        this.registerSetting(new DescriptionSetting("Predictive block-stop training coach; placement remains manual."));
        this.registerSetting(targetRange = new SliderSetting("Target range", 8.0D, 3.0D, 12.0D, 0.5D));
        this.registerSetting(predictionTicks = new SliderSetting("Prediction ticks", 3.0D, 1.0D, 8.0D, 1.0D));
        this.registerSetting(safeDistance = new SliderSetting("Safe distance", 1.35D, 0.8D, 2.5D, 0.05D));
        this.registerSetting(maxYaw = new SliderSetting("Max aim angle", 75.0D, 25.0D, 180.0D, 5.0D));
        this.registerSetting(maxReach = new SliderSetting("Reach", 4.5D, 3.0D, 5.0D, 0.1D));
        this.registerSetting(candidateRadius = new SliderSetting("Candidate radius", 2.0D, 1.0D, 3.0D, 0.5D));
        this.registerSetting(renderPreview = new TickSetting("Preview", false));
        this.registerSetting(requireBlockHeld = new TickSetting("Require block", true));
        setVisableInHud(false);
    }

    @Override
    public void onEnable() {
        clear();
    }

    @Override
    public void onDisable() {
        clear();
    }

    @Subscribe
    public void onUpdate(UpdateEvent event) {
        if (!event.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.thePlayer == null || mc.theWorld == null) {
            clear();
            return;
        }
        if (mc.currentScreen != null) {
            clear();
            return;
        }
        if (requireBlockHeld.isToggled() && !hasPlaceableBlock()) {
            clear();
            return;
        }

        EntityPlayer nextTarget = acquireTarget();
        if (nextTarget == null) {
            clear();
            return;
        }

        target = nextTarget;
        targetSpeed = horizontalSpeed(target.motionX, target.motionZ);
        closingSpeed = computeClosingSpeed(target);
        best = findBestCandidate(target);
        timing = classifyTiming(target, best);
        lastUpdateMs = System.currentTimeMillis();
    }

    @Subscribe
    public void onRenderWorld(ForgeEvent event) {
        if (!(event.getEvent() instanceof RenderWorldLastEvent)) return;
        if (!renderPreview.isToggled() || best == null || !Utils.Player.isPlayerInGame()) return;
        drawCandidate(best.pos, timingColor(timing));
    }

    private EntityPlayer acquireTarget() {
        double rangeSq = targetRange.getInput() * targetRange.getInput();
        EntityPlayer bestTarget = null;
        double bestScore = Double.POSITIVE_INFINITY;

        for (Object obj : mc.theWorld.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) obj;
            if (p == mc.thePlayer || p.isDead || p.getHealth() <= 0.0F) continue;
            if (p.getDistanceSqToEntity(mc.thePlayer) > rangeSq) continue;
            if (p.isSpectator()) continue;

            double closing = computeClosingSpeed(p);
            if (closing < 0.03D) continue;

            double score = p.getDistanceSqToEntity(mc.thePlayer) - closing * 2.0D;
            if (score < bestScore) {
                bestScore = score;
                bestTarget = p;
            }
        }
        return bestTarget;
    }

    private Candidate findBestCandidate(EntityPlayer enemy) {
        Vec3 predicted = predict(enemy, (int) predictionTicks.getInput());
        int centerX = MathHelper.floor_double(predicted.xCoord);
        int centerY = MathHelper.floor_double(enemy.posY);
        int centerZ = MathHelper.floor_double(predicted.zCoord);

        List<Candidate> candidates = new ArrayList<>();
        int radius = (int) Math.ceil(candidateRadius.getInput());

        for (int x = centerX - radius; x <= centerX + radius; x++) {
            for (int y = centerY - 1; y <= centerY + 1; y++) {
                for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!isReplaceable(pos)) continue;

                    EnumFacing support = findBestSupportFace(pos);
                    if (support == null) continue;

                    double distance = distanceToPlacement(pos);
                    if (distance > maxReach.getInput()) continue;

                    if (wouldIntersectPlayer(enemy, pos)) continue;
                    if (wouldTrapLocalPlayer(pos)) continue;

                    Vec3 hit = hitVector(pos, support);
                    float yaw = rotationsTo(hit).yaw;
                    float pitch = rotationsTo(hit).pitch;
                    double yawDelta = Math.abs(wrapYawDelta(mc.thePlayer.rotationYaw, yaw));
                    if (yawDelta > maxYaw.getInput()) continue;

                    double separation = horizontalDistanceToBlock(enemy, pos);
                    double predictedSeparation = horizontalDistance(predicted.xCoord, predicted.zCoord,
                            pos.getX() + 0.5D, pos.getZ() + 0.5D);
                    double intercept = Math.abs(predictedSeparation - 0.15D);
                    double approachPenalty = Math.max(0.0D, safeDistance.getInput() - separation) * 5.0D;
                    double localPenalty = Math.max(0.0D, 1.1D - horizontalDistanceToBlock(mc.thePlayer, pos)) * 4.0D;
                    double anglePenalty = yawDelta / 45.0D;

                    double score = intercept * 8.0D + distance * 2.0D + anglePenalty
                            + approachPenalty + localPenalty;

                    Timing candidateTiming = classifyTiming(enemy, new Candidate(pos, support, hit, yaw, pitch, score));
                    if (candidateTiming == Timing.READY) score -= 2.0D;
                    else if (candidateTiming == Timing.TOO_EARLY) score += 0.8D;
                    else if (candidateTiming == Timing.TOO_LATE) score += 3.0D;

                    candidates.add(new Candidate(pos, support, hit, yaw, pitch, score));
                }
            }
        }

        candidates.sort(Comparator.comparingDouble(c -> c.score));
        return candidates.isEmpty() ? null : candidates.get(0);
    }

    private EnumFacing findBestSupportFace(BlockPos placePos) {
        EnumFacing[] faces = EnumFacing.values();
        EnumFacing bestFace = null;
        double bestDistance = Double.MAX_VALUE;

        for (EnumFacing face : faces) {
            BlockPos support = placePos.offset(face.getOpposite());
            if (!canUseAsSupport(support)) continue;
            double d = mc.thePlayer.getDistanceSq(support.getX() + 0.5D,
                    support.getY() + 0.5D, support.getZ() + 0.5D);
            if (d < bestDistance) {
                bestDistance = d;
                bestFace = face;
            }
        }

        if (bestFace == null && canUseAsSupport(placePos.down())) return EnumFacing.UP;
        return bestFace;
    }

    private boolean canUseAsSupport(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block == Blocks.air || block instanceof BlockLiquid) return false;
        Material material = block.getMaterial();
        return material != Material.air && material != Material.lava && material != Material.water;
    }

    private boolean isReplaceable(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block == Blocks.air || block.getMaterial().isReplaceable();
    }

    private boolean wouldIntersectPlayer(EntityPlayer enemy, BlockPos pos) {
        AxisAlignedBB blockBB = new AxisAlignedBB(pos);
        AxisAlignedBB enemyBB = enemy.getEntityBoundingBox();
        return blockBB.intersectsWith(enemyBB.expand(0.01D, 0.01D, 0.01D));
    }

    private boolean wouldTrapLocalPlayer(BlockPos pos) {
        AxisAlignedBB blockBB = new AxisAlignedBB(pos);
        return blockBB.intersectsWith(mc.thePlayer.getEntityBoundingBox().expand(0.03D, 0.0D, 0.03D));
    }

    private Vec3 predict(EntityPlayer p, int ticks) {
        double friction = 0.91D;
        double px = p.posX;
        double pz = p.posZ;
        double vx = p.motionX;
        double vz = p.motionZ;

        for (int i = 0; i < ticks; i++) {
            px += vx;
            pz += vz;
            vx *= friction;
            vz *= friction;
        }
        return new Vec3(px, p.posY, pz);
    }

    private double computeClosingSpeed(EntityPlayer p) {
        double dx = mc.thePlayer.posX - p.posX;
        double dz = mc.thePlayer.posZ - p.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1.0E-4D) return 0.0D;
        double nx = dx / dist;
        double nz = dz / dist;
        double relativeX = p.motionX - mc.thePlayer.motionX;
        double relativeZ = p.motionZ - mc.thePlayer.motionZ;
        return -(relativeX * nx + relativeZ * nz);
    }

    private double horizontalSpeed(double x, double z) {
        return Math.sqrt(x * x + z * z);
    }

    private double distanceToPlacement(BlockPos pos) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        Vec3 hit = hitVector(pos, findBestSupportFace(pos));
        return eyes.distanceTo(hit);
    }

    private Vec3 hitVector(BlockPos pos, EnumFacing face) {
        double inset = 0.08D;
        switch (face) {
            case UP:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 1.0D - inset, pos.getZ() + 0.5D);
            case DOWN:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + inset, pos.getZ() + 0.5D);
            case NORTH:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + inset);
            case SOUTH:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 1.0D - inset);
            case WEST:
                return new Vec3(pos.getX() + inset, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            case EAST:
                return new Vec3(pos.getX() + 1.0D - inset, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            default:
                return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
        }
    }

    private Rotation rotationsTo(Vec3 point) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        double dx = point.xCoord - eyes.xCoord;
        double dy = point.yCoord - eyes.yCoord;
        double dz = point.zCoord - eyes.zCoord;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        return new Rotation(wrapYaw(yaw), MathHelper.clamp_float(pitch, -90.0F, 90.0F));
    }

    private Timing classifyTiming(EntityPlayer enemy, Candidate candidate) {
        if (enemy == null || candidate == null) return Timing.IDLE;

        double distance = horizontalDistanceToBlock(enemy, candidate.pos);
        double speed = Math.max(0.02D, targetSpeed);
        double seconds = Math.max(0.0D, (distance - 0.15D) / speed);
        double ticks = seconds * 20.0D;

        if (closingSpeed < 0.03D) return Timing.IDLE;
        if (ticks > predictionTicks.getInput() + 1.5D) return Timing.TOO_EARLY;
        if (ticks < -0.25D || distance < 0.25D) return Timing.TOO_LATE;
        return ticks <= 1.25D ? Timing.READY : Timing.TOO_EARLY;
    }

    private double horizontalDistanceToBlock(EntityPlayer p, BlockPos pos) {
        return horizontalDistance(p.posX, p.posZ, pos.getX() + 0.5D, pos.getZ() + 0.5D);
    }

    private double horizontalDistance(double ax, double az, double bx, double bz) {
        double dx = ax - bx;
        double dz = az - bz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private boolean hasPlaceableBlock() {
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held != null && held.getItem() instanceof ItemBlock && InventoryUtils.isGoodBlockStack(held)) return true;
        return false;
    }

    private void drawCandidate(BlockPos pos, int color) {
        double rx = pos.getX() - mc.getRenderManager().viewerPosX;
        double ry = pos.getY() - mc.getRenderManager().viewerPosY;
        double rz = pos.getZ() - mc.getRenderManager().viewerPosZ;
        AxisAlignedBB bb = new AxisAlignedBB(rx, ry, rz, rx + 1.0D, ry + 1.0D, rz + 1.0D);

        float r = ((color >> 16) & 255) / 255.0F;
        float g = ((color >> 8) & 255) / 255.0F;
        float b = (color & 255) / 255.0F;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glLineWidth(2.0F);
        GL11.glColor4f(r, g, b, 0.9F);
        RenderGlobal.drawSelectionBoundingBox(bb);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private int timingColor(Timing value) {
        switch (value) {
            case READY: return 0xFF39D353;
            case TOO_EARLY: return 0xFFFFCC33;
            case TOO_LATE: return 0xFFFF5555;
            default: return 0xFFAAAAAA;
        }
    }

    private void clear() {
        target = null;
        best = null;
        timing = Timing.IDLE;
        targetSpeed = 0.0D;
        closingSpeed = 0.0D;
        lastUpdateMs = 0L;
    }

    public EntityPlayer getTarget() {
        return target;
    }

    public BlockPos getRecommendedBlock() {
        return best == null ? null : best.pos;
    }

    public EnumFacing getRecommendedFace() {
        return best == null ? null : best.face;
    }

    public Vec3 getRecommendedHitVec() {
        return best == null ? null : best.hitVec;
    }

    public Timing getTiming() {
        return timing;
    }

    public long getLastUpdateMs() {
        return lastUpdateMs;
    }

    private static float wrapYaw(float yaw) {
        yaw %= 360.0F;
        if (yaw >= 180.0F) yaw -= 360.0F;
        if (yaw < -180.0F) yaw += 360.0F;
        return yaw;
    }

    private static float wrapYawDelta(float from, float to) {
        float delta = to - from;
        while (delta > 180.0F) delta -= 360.0F;
        while (delta < -180.0F) delta += 360.0F;
        return delta;
    }

    public enum Timing {
        IDLE,
        TOO_EARLY,
        READY,
        TOO_LATE
    }

    private static class Rotation {
        final float yaw;
        final float pitch;
        Rotation(float yaw, float pitch) {
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    private static class Candidate {
        final BlockPos pos;
        final EnumFacing face;
        final Vec3 hitVec;
        final float yaw;
        final float pitch;
        final double score;

        Candidate(BlockPos pos, EnumFacing face, Vec3 hitVec, float yaw, float pitch, double score) {
            this.pos = pos;
            this.face = face;
            this.hitVec = hitVec;
            this.yaw = yaw;
            this.pitch = pitch;
            this.score = score;
        }
    }
}
