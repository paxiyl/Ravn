package keystrokesmod.client.module.modules.combat.lobohit;

import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.MathHelper;

import com.google.common.eventbus.Subscribe;

public class LoboHitV2 extends Module {

    public static SliderSetting nudgeStrength;
    public static SliderSetting syncThreshold;
    public static TickSetting debug;

    private EntityPlayer currentTarget = null;
    private boolean trackingCombat = false;
    private int ticksSincePlayerSwing = 999;
    private float prevDistance = 0;
    private int comboCount = 0;

    private double lastSyncX, lastSyncY, lastSyncZ;
    private boolean hasSynced = false;
    private int ticksSinceSync = 0;

    private float smoothedError = 0;
    private float errorVelocity = 0;
    private float prevError = 0;

    private static final float GROUND_FRICTION = 0.91f;
    private static final float AIR_FRICTION = 0.98f;

    public LoboHitV2() {
        super("LoboHitV2", Module.ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Motion boost + teleport sync"));
        this.registerSetting(new DescriptionSetting("Hold weapon to activate"));
        this.registerSetting(nudgeStrength = new SliderSetting("Nudge strength", 0.06D, 0.01D, 0.15D, 0.01D));
        this.registerSetting(syncThreshold = new SliderSetting("Sync threshold", 0.12D, 0.05D, 0.3D, 0.01D));
        this.registerSetting(debug = new TickSetting("Debug", false));
    }

    @Override
    public void onEnable() {
        currentTarget = null;
        trackingCombat = false;
        ticksSincePlayerSwing = 999;
        comboCount = 0;
        hasSynced = false;
        ticksSinceSync = 0;
        smoothedError = 0;
        errorVelocity = 0;
        prevError = 0;
    }

    @Override
    public void onDisable() {
        currentTarget = null;
        trackingCombat = false;
        comboCount = 0;
        hasSynced = false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) {
            mc.thePlayer.setSneaking(false);
        }
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!isHoldingWeapon()) {
            trackingCombat = false;
            return;
        }

        ticksSincePlayerSwing++;
        ticksSinceSync++;

        detectTarget();

        if (currentTarget != null && isTargetValid(currentTarget)) {
            trackingCombat = true;
            runEngine();
        } else {
            trackingCombat = false;
            comboCount = 0;
        }
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isOutgoing() && e.getPacket() instanceof C0APacketAnimation) {
            ticksSincePlayerSwing = 0;
            if (currentTarget != null) {
                comboCount++;
                lastSyncX = mc.thePlayer.posX;
                lastSyncY = mc.thePlayer.posY;
                lastSyncZ = mc.thePlayer.posZ;
                hasSynced = true;
                ticksSinceSync = 0;
            }
        }

        if (e.isIncoming() && e.getPacket() instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity pkt = (S12PacketEntityVelocity) e.getPacket();
            if (pkt.getEntityID() == mc.thePlayer.getEntityId()) {
                hasSynced = false;
            }
        }
    }

    private void runEngine() {
        if (mc.thePlayer == null || currentTarget == null) return;

        float dist = mc.thePlayer.getDistanceToEntity(currentTarget);
        float error = dist - 3.0f;

        prevError = smoothedError;
        smoothedError = smoothedError * 0.7f + error * 0.3f;
        errorVelocity = smoothedError - prevError;

        float nudge = calculateNudge(smoothedError, errorVelocity);
        if (nudge != 0) {
            applyNudge(nudge);
            syncPosition();
        }

        decideSprintReset(smoothedError, errorVelocity);
    }

    private float calculateNudge(float error, float errorVel) {
        if (mc.thePlayer == null) return 0;
        if (!mc.thePlayer.onGround) return 0;

        float strength = nudgeStrength.getInput();
        float absError = Math.abs(error);

        if (absError < 0.15f) return 0;

        boolean closing = errorVel < -0.01f;
        boolean separating = errorVel > 0.01f;

        if (error > 0.2f) {
            if (separating) return 0;
            if (closing && absError < 0.6f) return 0;
            return MathHelper.clamp_float(error * strength * 0.6f, -strength, strength);
        }

        if (error < -0.2f) {
            boolean justHit = ticksSincePlayerSwing < 3;
            boolean overshooting = errorVel < -0.03f;

            if (justHit && overshooting) {
                return MathHelper.clamp_float(error * strength * 1.2f, -strength * 1.5f, strength * 1.5f);
            }

            if (separating) return 0;

            return MathHelper.clamp_float(error * strength * 0.8f, -strength, strength);
        }

        return 0;
    }

    private void applyNudge(float nudge) {
        if (mc.thePlayer == null || nudge == 0) return;
        float yaw = mc.thePlayer.rotationYaw;
        mc.thePlayer.motionX += -Math.sin(Math.toRadians(yaw)) * nudge;
        mc.thePlayer.motionZ += Math.cos(Math.toRadians(yaw)) * nudge;
    }

    private void syncPosition() {
        if (mc.thePlayer == null || mc.thePlayer.sendQueue == null) return;
        if (ticksSinceSync < 1) return;

        double dx = mc.thePlayer.posX - lastSyncX;
        double dy = mc.thePlayer.posY - lastSyncY;
        double dz = mc.thePlayer.posZ - lastSyncZ;
        double moved = Math.sqrt(dx * dx + dy * dy + dz * dz);

        float threshold = syncThreshold.getInput();
        if (moved > threshold || ticksSinceSync > 3) {
            mc.thePlayer.sendQueue.addToSendQueue(
                new C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX,
                    mc.thePlayer.posY,
                    mc.thePlayer.posZ,
                    mc.thePlayer.onGround
                )
            );
            lastSyncX = mc.thePlayer.posX;
            lastSyncY = mc.thePlayer.posY;
            lastSyncZ = mc.thePlayer.posZ;
            hasSynced = true;
            ticksSinceSync = 0;
        }
    }

    private void decideSprintReset(float error, float errorVel) {
        if (mc.thePlayer == null) return;
        if (!mc.thePlayer.isSprinting()) return;
        if (!mc.thePlayer.onGround) return;

        boolean justHit = ticksSincePlayerSwing < 2;
        boolean overshooting = errorVel < -0.03f && Math.abs(error) < 0.5f;

        if (justHit && mc.thePlayer.onGround) {
            mc.thePlayer.setSprinting(false);
            return;
        }

        if (error < -0.4f && Math.abs(error) > 0.5f) {
            mc.thePlayer.setSprinting(false);
            return;
        }
    }

    private boolean isHoldingWeapon() {
        return Utils.Player.isPlayerHoldingWeapon();
    }

    private boolean isTargetValid(EntityPlayer target) {
        if (target == null || target.isDead || !target.isEntityAlive()) return false;
        if (Targets.isATeamMate(target)) return false;
        if (Targets.isAFriend(target)) return false;
        float dist = mc.thePlayer.getDistanceToEntity(target);
        return dist < 6.0f;
    }

    private void detectTarget() {
        EntityPlayer target = Targets.getTarget();
        if (target != currentTarget) {
            if (target != null) {
                currentTarget = target;
                comboCount = 0;
                hasSynced = false;
            } else {
                currentTarget = null;
                trackingCombat = false;
                comboCount = 0;
            }
        }
    }
}
