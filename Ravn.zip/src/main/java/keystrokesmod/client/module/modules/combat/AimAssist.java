package keystrokesmod.client.module.modules.combat;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.modules.player.RightClicker;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class AimAssist extends Module {

    public static SliderSetting range, aimFov, speed;
    public static TickSetting clickAim, weaponOnly, breakBlocks, comboAim;

    public static ArrayList<Entity> friends = new ArrayList<>();

    private static final double RETENTION_FOV_MARGIN = 15.0D;
    private static final double RETENTION_RANGE_MARGIN = 0.75D;
    private static final double MANUAL_INPUT_THRESHOLD_DEG = 0.6D;
    private static final double MANUAL_BLEND_FLOOR = 0.7D;
    private static final double MANUAL_HOLD_SECONDS = 0.12D;
    private static final double BLEND_TAU = 0.18D;
    private static final double POINT_SMOOTHING_TAU = 0.09D;
    private static final double PREDICTION_LEAD_SECONDS = 0.07D;
    private static final double DEADZONE_DEG = 0.05D;
    private static final double MAX_DT_SECONDS = 0.05D;
    private static final double MIN_DT_SECONDS = 0.0005D;
    private static final double PITCH_SPEED_RATIO = 0.75D;
    private static final double SPEED_CAP_DEG_PER_SEC = 900.0D;

    private EntityPlayer activeTarget;

    private long lastFrameNanos = -1L;
    private boolean hasLastAppliedRotation = false;
    private double lastAppliedYaw, lastAppliedPitch;

    private double manualHoldTimer = 0.0D;
    private double blend = 1.0D;

    private double velYaw, velPitch;

    private double smoothPointX, smoothPointZ;
    private boolean hasSmoothPoint = false;
    private double targetVelX, targetVelZ;

    private int comboCount = 0;
    private EntityPlayer comboTarget = null;
    private float prevComboDistance = 0;
    private boolean comboAimActive = false;

    public AimAssist() {
        super("AimAssist", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Fast, gliding aim pull - no snapping"));
        this.registerSetting(clickAim = new TickSetting("Only while clicking", true));
        this.registerSetting(comboAim = new TickSetting("Combo auto-aim", true));
        this.registerSetting(weaponOnly = new TickSetting("Weapon only", false));
        this.registerSetting(breakBlocks = new TickSetting("Don't aim at blocks", true));
        this.registerSetting(range = new SliderSetting("Range", 4.0D, 1.0D, 8.0D, 0.5D));
        this.registerSetting(aimFov = new SliderSetting("Field of view", 90.0D, 10.0D, 360.0D, 5.0D));
        this.registerSetting(speed = new SliderSetting("Speed", 24.0D, 4.0D, 60.0D, 2.0D));
    }

    @Subscribe
    public void onRender(Render2DEvent e) {
        if (!Utils.Client.currentScreenMinecraft() || !Utils.Player.isPlayerInGame()) {
            resetTracking(false);
            return;
        }

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            resetTracking(false);
            return;
        }

        long now = System.nanoTime();
        double dt = lastFrameNanos < 0L ? 0.016D : (now - lastFrameNanos) * 1.0E-9D;
        lastFrameNanos = now;
        if (dt < MIN_DT_SECONDS) dt = MIN_DT_SECONDS;
        else if (dt > MAX_DT_SECONDS) dt = MAX_DT_SECONDS;

        updateComboState();

        if (!shouldAssist()) {
            resetTracking(true);
            return;
        }

        updateTarget();

        if (activeTarget == null) {
            resetTracking(true);
            return;
        }

        double[] desired = computeDesiredRotation(dt);
        if (desired == null) {
            resetTracking(true);
            return;
        }

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        if (!hasLastAppliedRotation) {
            lastAppliedYaw = curYaw;
            lastAppliedPitch = curPitch;
            hasLastAppliedRotation = true;
        }
        else {
            double manualYaw = wrapDegrees(curYaw - lastAppliedYaw);
            double manualPitch = curPitch - lastAppliedPitch;
            double manualMag = Math.sqrt(manualYaw * manualYaw + manualPitch * manualPitch);
            if (manualMag > MANUAL_INPUT_THRESHOLD_DEG)
                manualHoldTimer = MANUAL_HOLD_SECONDS;
            else if (manualHoldTimer > 0.0D)
                manualHoldTimer -= dt;

            double targetBlend = manualHoldTimer > 0.0D ? MANUAL_BLEND_FLOOR : 1.0D;
            blend += (targetBlend - blend) * (1.0D - Math.exp(-dt / BLEND_TAU));
        }

        double errYaw = wrapDegrees(desired[0] - curYaw);
        double errPitch = desired[1] - curPitch;

        double omega = Math.max(speed.getInput(), 2.0D);
        omega = Math.min(omega, 1.5D / dt);
        double maxStepH = SPEED_CAP_DEG_PER_SEC * dt;
        double maxStepV = SPEED_CAP_DEG_PER_SEC * PITCH_SPEED_RATIO * dt;

        double moveYaw = springStep(errYaw * blend, velYaw, omega, dt);
        velYaw = (moveYaw / dt);
        if (moveYaw > maxStepH) moveYaw = maxStepH;
        else if (moveYaw < -maxStepH) moveYaw = -maxStepH;
        if (Math.abs(errYaw) < DEADZONE_DEG) { moveYaw = 0.0D; velYaw *= Math.exp(-10.0D * dt); }

        double movePitch = springStep(errPitch * blend, velPitch, omega * 0.9D, dt);
        velPitch = (movePitch / dt);
        if (movePitch > maxStepV) movePitch = maxStepV;
        else if (movePitch < -maxStepV) movePitch = -maxStepV;
        if (Math.abs(errPitch) < DEADZONE_DEG) { movePitch = 0.0D; velPitch *= Math.exp(-10.0D * dt); }

        mc.thePlayer.rotationYaw = (float) (curYaw + moveYaw);
        mc.thePlayer.rotationPitch = (float) SliderSetting.check(curPitch + movePitch, -90.0D, 90.0D);
        lastAppliedYaw = mc.thePlayer.rotationYaw;
        lastAppliedPitch = mc.thePlayer.rotationPitch;
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!comboAim.isToggled()) return;

        if (e.isOutgoing() && e.getPacket() instanceof C0APacketAnimation) {
            EntityPlayer target = Targets.getTarget();
            if (target != null && mc.thePlayer.getDistanceToEntity(target) < range.getInput() + 1.0f) {
                if (comboTarget == target) {
                    comboCount++;
                } else {
                    comboTarget = target;
                    comboCount = 1;
                    prevComboDistance = mc.thePlayer.getDistanceToEntity(target);
                }
                comboAimActive = comboCount >= 2;
            }
        }
    }

    private void updateComboState() {
        if (mc.thePlayer == null || comboTarget == null) {
            resetCombo();
            return;
        }

        if (comboTarget.isDead || !comboTarget.isEntityAlive()) {
            resetCombo();
            return;
        }

        float currentDist = mc.thePlayer.getDistanceToEntity(comboTarget);
        float distDelta = currentDist - prevComboDistance;
        prevComboDistance = currentDist;

        if (distDelta > 0.8f) {
            resetCombo();
            return;
        }

        if (currentDist > range.getInput() + 2.0f) {
            resetCombo();
        }
    }

    private void resetCombo() {
        comboCount = 0;
        comboTarget = null;
        comboAimActive = false;
        prevComboDistance = 0;
    }

    private double springStep(double error, double velocity, double omega, double dt) {
        double stiffness = omega * omega;
        double damping = 2.0D * omega;
        double newVel = velocity + (stiffness * error - damping * velocity) * dt;
        return (velocity + newVel) * 0.5D * dt;
    }

    private boolean shouldAssist() {
        if (mc.gameSettings.keyBindUseItem.isKeyDown())
            return false;

        if (breakBlocks.isToggled() && (mc.objectMouseOver != null)) {
            BlockPos p = mc.objectMouseOver.getBlockPos();
            if (p != null) {
                Block bl = mc.theWorld.getBlockState(p).getBlock();
                if ((bl != Blocks.air) && !(bl instanceof BlockLiquid))
                    return false;
            }
        }
        if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
            return false;

        if (comboAim.isToggled() && comboAimActive && comboCount >= 2) {
            return true;
        }

        if (!clickAim.isToggled())
            return true;
        if (Utils.Client.autoClickerClicking())
            return true;
        Module autoClicker = Raven.moduleManager.getModuleByClazz(RightClicker.class);
        return (Mouse.isButtonDown(0) && (autoClicker != null) && !autoClicker.isEnabled());
    }

    private void updateTarget() {
        EntityPlayer candidate = Targets.getTarget();
        double maxDist = range.getInput();

        if (activeTarget != null && isTargetUsable(activeTarget, maxDist + RETENTION_RANGE_MARGIN,
                aimFov.getInput() + RETENTION_FOV_MARGIN))
            return;

        if (candidate == null || !isTargetUsable(candidate, maxDist, aimFov.getInput())) {
            activeTarget = null;
            return;
        }

        boolean isNewTarget = candidate != activeTarget;
        activeTarget = candidate;
        if (isNewTarget) {
            hasSmoothPoint = false;
            targetVelX = targetVelZ = 0.0D;
        }
    }

    private boolean isTargetUsable(EntityPlayer en, double maxDist, double maxFov) {
        if (en == null || en.isDead || !en.isEntityAlive() || en == mc.thePlayer)
            return false;
        if (mc.thePlayer.getDistanceToEntity(en) > maxDist)
            return false;
        double dx = en.posX - mc.thePlayer.posX;
        double dz = en.posZ - mc.thePlayer.posZ;
        double yawTo = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;
        double yawErr = Math.abs(wrapDegrees(yawTo - mc.thePlayer.rotationYaw));
        return yawErr <= maxFov;
    }

    private double[] computeDesiredRotation(double dt) {
        EntityPlayer en = activeTarget;
        if (en == null)
            return null;

        AxisAlignedBB bb = en.getEntityBoundingBox();
        double rawX = (bb.minX + bb.maxX) * 0.5D;
        double rawZ = (bb.minZ + bb.maxZ) * 0.5D;

        targetVelX = (en.posX - en.prevPosX) * 20.0D;
        targetVelZ = (en.posZ - en.prevPosZ) * 20.0D;

        double pointAlpha = 1.0D - Math.exp(-dt / POINT_SMOOTHING_TAU);
        if (!hasSmoothPoint) {
            smoothPointX = rawX;
            smoothPointZ = rawZ;
            hasSmoothPoint = true;
        }
        else {
            smoothPointX += (rawX - smoothPointX) * pointAlpha;
            smoothPointZ += (rawZ - smoothPointZ) * pointAlpha;
        }

        double tx = smoothPointX + targetVelX * PREDICTION_LEAD_SECONDS;
        double tz = smoothPointZ + targetVelZ * PREDICTION_LEAD_SECONDS;

        double eyeX = mc.thePlayer.posX;
        double eyeY = mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
        double eyeZ = mc.thePlayer.posZ;

        double dx = tx - eyeX;
        double dz = tz - eyeZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        double desiredYaw = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;

        double curPitch = mc.thePlayer.rotationPitch;
        double pitchTop = -(Math.atan2(bb.maxY - eyeY, horizontal) * 180.0D / Math.PI);
        double pitchBottom = -(Math.atan2(bb.minY - eyeY, horizontal) * 180.0D / Math.PI);
        double inset = 0.75D;
        double innerTop = pitchTop + inset;
        double innerBottom = pitchBottom - inset;
        double desiredPitch;
        if (curPitch < innerTop)
            desiredPitch = innerTop;
        else if (curPitch > innerBottom)
            desiredPitch = innerBottom;
        else
            desiredPitch = curPitch;
        desiredPitch = SliderSetting.check(desiredPitch, -89.9D, 89.9D);

        return new double[]{desiredYaw, desiredPitch};
    }

    private static double wrapDegrees(double degrees) {
        degrees %= 360.0D;
        if (degrees >= 180.0D) degrees -= 360.0D;
        else if (degrees < -180.0D) degrees += 360.0D;
        return degrees;
    }

    private void resetTracking(boolean softReset) {
        activeTarget = null;
        hasSmoothPoint = false;
        targetVelX = targetVelZ = 0.0D;
        hasLastAppliedRotation = false;
        manualHoldTimer = 0.0D;
        blend = 1.0D;
        velYaw = 0.0D;
        velPitch = 0.0D;
        if (!softReset)
            lastFrameNanos = -1L;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetTracking(false);
        resetCombo();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetTracking(false);
        resetCombo();
    }

    public Entity getEnemy() {
        return activeTarget;
    }

    public static void addFriend(Entity entityPlayer) {
        friends.add(entityPlayer);
    }

    public static boolean addFriend(String name) {
        boolean found = false;
        for (Object o : mc.theWorld.getLoadedEntityList()) {
            Entity entity = (Entity) o;
            if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name))
                if (!Targets.isAFriend(entity)) {
                    addFriend(entity);
                    found = true;
                }
        }
        return found;
    }

    public static boolean removeFriend(String name) {
        try {
            boolean removed = false;
            boolean found = false;
            for (NetworkPlayerInfo networkPlayerInfo : new ArrayList<>(mc.getNetHandler().getPlayerInfoMap())) {
                Entity entity = mc.theWorld.getPlayerEntityByName(networkPlayerInfo.getDisplayName().getUnformattedText());
                if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name)) {
                    removed = removeFriend(entity);
                    found = true;
                }
            }
            return found && removed;
        } catch (Exception e) {
            Utils.Player.sendMessageToSelf("Error! Could not Remove " + name);
            return false;
        }
    }

    public static boolean removeFriend(Entity entityPlayer) {
        try {
            friends.remove(entityPlayer);
        } catch (Exception eeeeee) {
            eeeeee.printStackTrace();
            return false;
        }
        return true;
    }

    public static ArrayList<Entity> getFriends() {
        return friends;
    }
}
