package keystrokesmod.client.module.modules.combat;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.GameLoopEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.modules.player.RightClicker;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class AimAssist extends Module {

    public static SliderSetting aimFov, range, responseH, responseV, maxSpeedH, maxSpeedV,
            accelTime, settleThreshold, verticalOffset, predictionLead;
    public static TickSetting clickAim, breakBlocks, weaponOnly, prediction, debugOutput;

    public static ArrayList<Entity> friends = new ArrayList<>();

    private static final double RETENTION_FOV_MARGIN = 15.0D;
    private static final double RETENTION_RANGE_MARGIN = 0.75D;
    private static final int PREDICTION_WARMUP_FRAMES = 5;
    private static final double MANUAL_INPUT_THRESHOLD_DEG = 0.75D;
    private static final double MANUAL_INPUT_INFLUENCE = 0.35D;
    private static final double MANUAL_INPUT_RECOVERY_TAU = 0.4D;
    private static final double POINT_SMOOTHING_TAU = 0.05D;
    private static final double VELOCITY_SMOOTHING_TAU = 0.12D;
    private static final double MAX_PREDICTED_DISPLACEMENT = 2.0D;
    private static final double TARGET_HEIGHT_FRACTION = 0.85D;
    private static final double SETTLING_RATE = 40.0D;
    private static final double MAX_DT_SECONDS = 0.1D;
    private static final double MIN_DT_SECONDS = 0.0005D;

    private EntityPlayer activeTarget;
    private final AxisState yawAxis = new AxisState();
    private final AxisState pitchAxis = new AxisState();

    private double influence = 1.0D;
    private long lastFrameNanos = -1L;
    private boolean hasLastAppliedRotation = false;
    private double lastAppliedYaw, lastAppliedPitch;

    private double smoothPointX, smoothPointY, smoothPointZ;
    private boolean hasSmoothPoint = false;
    private double predVelX, predVelY, predVelZ;
    private int predictionFrames;

    private double debugTimer = 0.0D;

    public AimAssist() {
        super("AimAssist", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Critically damped rotation controller"));
        this.registerSetting(clickAim = new TickSetting("Click aim", true));
        this.registerSetting(weaponOnly = new TickSetting("Weapon only", false));
        this.registerSetting(breakBlocks = new TickSetting("Break blocks", true));
        this.registerSetting(aimFov = new SliderSetting("Aim FOV", 90.0D, 10.0D, 360.0D, 1.0D));
        this.registerSetting(range = new SliderSetting("Range", 4.0D, 1.0D, 8.0D, 0.1D));
        this.registerSetting(responseH = new SliderSetting("Response (horizontal)", 5.0D, 1.0D, 20.0D, 0.5D));
        this.registerSetting(responseV = new SliderSetting("Response (vertical)", 4.0D, 1.0D, 20.0D, 0.5D));
        this.registerSetting(maxSpeedH = new SliderSetting("Max speed (horizontal)", 240.0D, 60.0D, 600.0D, 5.0D));
        this.registerSetting(maxSpeedV = new SliderSetting("Max speed (vertical)", 140.0D, 30.0D, 400.0D, 5.0D));
        this.registerSetting(accelTime = new SliderSetting("Acceleration time (ms)", 150.0D, 50.0D, 500.0D, 10.0D));
        this.registerSetting(settleThreshold = new SliderSetting("Settling threshold", 0.08D, 0.02D, 0.5D, 0.01D));
        this.registerSetting(verticalOffset = new SliderSetting("Vertical offset", 0.0D, -2.0D, 2.0D, 0.05D));
        this.registerSetting(prediction = new TickSetting("Prediction", true));
        this.registerSetting(predictionLead = new SliderSetting("Prediction lead (ms)", 100.0D, 0.0D, 300.0D, 10.0D));
        this.registerSetting(debugOutput = new TickSetting("Debug output", false));
    }

    @Subscribe
    public void onGameLoop(GameLoopEvent e) {
        if (!Utils.Client.currentScreenMinecraft() || !Utils.Player.isPlayerInGame()) {
            resetTracking(false);
            return;
        }

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            resetTracking(false);
            return;
        }

        long now = System.nanoTime();
        double dt = lastFrameNanos < 0L ? 0.05D : (now - lastFrameNanos) * 1.0E-9D;
        lastFrameNanos = now;
        if (dt < MIN_DT_SECONDS) dt = MIN_DT_SECONDS;
        else if (dt > MAX_DT_SECONDS) dt = MAX_DT_SECONDS;

        if (!shouldAssist()) {
            resetTracking(true);
            return;
        }

        updateTarget();

        if (activeTarget == null) {
            resetTracking(true);
            return;
        }

        updateConfiguredAxes();

        double[] desired = computeDesiredRotation(dt);
        if (desired == null) {
            resetTracking(true);
            return;
        }

        float currentYaw = mc.thePlayer.rotationYaw;
        float currentPitch = mc.thePlayer.rotationPitch;

        if (!hasLastAppliedRotation) {
            lastAppliedYaw = currentYaw;
            lastAppliedPitch = currentPitch;
            hasLastAppliedRotation = true;
        }
        else {
            double manualYaw = wrapDegrees(currentYaw - lastAppliedYaw);
            double manualPitch = currentPitch - lastAppliedPitch;
            if (Math.sqrt(manualYaw * manualYaw + manualPitch * manualPitch) > MANUAL_INPUT_THRESHOLD_DEG)
                influence = MANUAL_INPUT_INFLUENCE;
            else
                influence += (1.0D - influence) * (1.0D - Math.exp(-dt / MANUAL_INPUT_RECOVERY_TAU));
        }

        double newYaw = stepAxis(currentYaw, desired[0], yawAxis, dt);
        double newPitch = stepAxis(currentPitch, desired[1], pitchAxis, dt);

        newPitch = SliderSetting.check(newPitch, -90.0D, 90.0D);

        mc.thePlayer.rotationYaw = (float) newYaw;
        mc.thePlayer.rotationPitch = (float) newPitch;
        lastAppliedYaw = newYaw;
        lastAppliedPitch = newPitch;

        if (debugOutput.isToggled()) {
            debugTimer += dt;
            if (debugTimer >= 0.5D) {
                debugTimer = 0.0D;
                double yawErr = wrapDegrees(desired[0] - newYaw);
                double pitchErr = desired[1] - newPitch;
                Utils.Player.sendMessageToSelf(String.format(
                        "tgt=%s yaw=%.2f want=%.2f err=%.2f vyaw=%.1f | pitch=%.2f want=%.2f err=%.2f vpitch=%.1f infl=%.2f",
                        activeTarget.getName(),
                        newYaw, desired[0], yawErr, yawAxis.velocity,
                        newPitch, desired[1], pitchErr, pitchAxis.velocity, influence));
            }
        }
    }

    private boolean shouldAssist() {
        if (breakBlocks.isToggled() && (mc.objectMouseOver != null)) {
            BlockPos p = mc.objectMouseOver.getBlockPos();
            if (p != null) {
                Block bl = mc.theWorld.getBlockState(p).getBlock();
                if ((bl != Blocks.air) && !(bl instanceof BlockLiquid))
                    return false;
            }
        }
        if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
            return false;
        if (!clickAim.isToggled())
            return true;
        if (Utils.Client.autoClickerClicking())
            return true;
        Module autoClicker = Raven.moduleManager.getModuleByClazz(RightClicker.class);
        return (Mouse.isButtonDown(0) && (autoClicker != null) && !autoClicker.isEnabled());
    }

    private void updateTarget() {
        EntityPlayer candidate = Targets.getTarget();
        double maxDist = range.getInput();

        if (activeTarget != null && isTargetUsable(activeTarget, maxDist + RETENTION_RANGE_MARGIN,
                aimFov.getInput() + RETENTION_FOV_MARGIN))
            return;

        if (candidate == null || !isTargetUsable(candidate, maxDist, aimFov.getInput())) {
            activeTarget = null;
            return;
        }

        boolean isNewTarget = candidate != activeTarget;
        activeTarget = candidate;
        if (isNewTarget) {
            hasSmoothPoint = false;
            predVelX = predVelY = predVelZ = 0.0D;
            predictionFrames = 0;
        }
    }

    private boolean isTargetUsable(EntityPlayer en, double maxDist, double maxFov) {
        if (en == null || en.isDead || !en.isEntityAlive() || en == mc.thePlayer)
            return false;
        if (mc.thePlayer.getDistanceToEntity(en) > maxDist)
            return false;
        double dx = en.posX - mc.thePlayer.posX;
        double dz = en.posZ - mc.thePlayer.posZ;
        double yawTo = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;
        double yawErr = Math.abs(wrapDegrees(yawTo - mc.thePlayer.rotationYaw));
        return yawErr <= maxFov;
    }

    private double[] computeDesiredRotation(double dt) {
        EntityPlayer en = activeTarget;
        if (en == null)
            return null;

        AxisAlignedBB bb = en.getEntityBoundingBox();
        double rawX = (bb.minX + bb.maxX) * 0.5D;
        double rawZ = (bb.minZ + bb.maxZ) * 0.5D;
        double rawY = bb.minY + (bb.maxY - bb.minY) * TARGET_HEIGHT_FRACTION + verticalOffset.getInput();

        double instVelX = (en.posX - en.prevPosX) * 20.0D;
        double instVelY = (en.posY - en.prevPosY) * 20.0D;
        double instVelZ = (en.posZ - en.prevPosZ) * 20.0D;

        predictionFrames++;
        boolean canPredict = prediction.isToggled() && predictionFrames >= PREDICTION_WARMUP_FRAMES;

        double alpha = 1.0D - Math.exp(-dt / VELOCITY_SMOOTHING_TAU);
        if (canPredict) {
            predVelX += (instVelX - predVelX) * alpha;
            predVelY += (instVelY - predVelY) * alpha;
            predVelZ += (instVelZ - predVelZ) * alpha;
        }
        else {
            predVelX = predVelY = predVelZ = 0.0D;
        }

        double leadSeconds = canPredict ? predictionLead.getInput() * 0.001D : 0.0D;
        double offX = predVelX * leadSeconds;
        double offY = predVelY * leadSeconds;
        double offZ = predVelZ * leadSeconds;
        double offLen = Math.sqrt(offX * offX + offY * offY + offZ * offZ);
        if (offLen > MAX_PREDICTED_DISPLACEMENT) {
            double scale = MAX_PREDICTED_DISPLACEMENT / offLen;
            offX *= scale;
            offY *= scale;
            offZ *= scale;
        }

        double pointAlpha = 1.0D - Math.exp(-dt / POINT_SMOOTHING_TAU);
        if (!hasSmoothPoint) {
            smoothPointX = rawX;
            smoothPointY = rawY;
            smoothPointZ = rawZ;
            hasSmoothPoint = true;
        }
        else {
            smoothPointX += (rawX - smoothPointX) * pointAlpha;
            smoothPointY += (rawY - smoothPointY) * pointAlpha;
            smoothPointZ += (rawZ - smoothPointZ) * pointAlpha;
        }

        double tx = smoothPointX + offX;
        double ty = smoothPointY + offY;
        double tz = smoothPointZ + offZ;

        double eyeX = mc.thePlayer.posX;
        double eyeY = mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
        double eyeZ = mc.thePlayer.posZ;

        double dx = tx - eyeX;
        double dy = ty - eyeY;
        double dz = tz - eyeZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        double desiredYaw = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;
        double desiredPitch = -(Math.atan2(dy, horizontal) * 180.0D / Math.PI);
        desiredPitch = SliderSetting.check(desiredPitch, -89.9D, 89.9D);

        return new double[]{desiredYaw, desiredPitch};
    }

    private void updateConfiguredAxes() {
        double accelTimeSeconds = Math.max(accelTime.getInput(), 10.0D) * 0.001D;

        yawAxis.gain = responseH.getInput() * 0.05D;
        yawAxis.maxSpeed = maxSpeedH.getInput();
        yawAxis.accel = yawAxis.maxSpeed / accelTimeSeconds;
        yawAxis.settleThreshold = settleThreshold.getInput();

        pitchAxis.gain = responseV.getInput() * 0.05D;
        pitchAxis.maxSpeed = maxSpeedV.getInput();
        pitchAxis.accel = pitchAxis.maxSpeed / accelTimeSeconds;
        pitchAxis.settleThreshold = settleThreshold.getInput();
    }

    private double stepAxis(double current, double desired, AxisState axis, double dt) {
        double error = wrapDegrees(desired - current);
        double absError = Math.abs(error);

        if (absError <= axis.settleThreshold) {
            double blend = 1.0D - Math.exp(-dt * SETTLING_RATE);
            double delta = error * blend;
            axis.velocity = delta / dt;
            return wrapDegrees(current + delta);
        }

        double brakeSpeed = Math.sqrt(2.0D * axis.accel * (absError - axis.settleThreshold));
        double speedLimit = Math.min(brakeSpeed, axis.maxSpeed * influence);
        double desiredVel = axis.maxSpeed * influence * Math.tanh(axis.gain * error);
        if (Math.abs(desiredVel) > speedLimit)
            desiredVel = Math.signum(error) * speedLimit;

        double maxDeltaV = axis.accel * dt;
        double dv = desiredVel - axis.velocity;
        if (dv > maxDeltaV) dv = maxDeltaV;
        else if (dv < -maxDeltaV) dv = -maxDeltaV;
        axis.velocity += dv;

        double step = axis.velocity * dt;
        if (Math.abs(step) > absError && Math.signum(step) == Math.signum(error)) {
            axis.velocity = 0.0D;
            return wrapDegrees(current + error);
        }

        return wrapDegrees(current + step);
    }

    private static double wrapDegrees(double degrees) {
        degrees %= 360.0D;
        if (degrees >= 180.0D) degrees -= 360.0D;
        else if (degrees < -180.0D) degrees += 360.0D;
        return degrees;
    }

    private void resetTracking(boolean keepInfluenceRecovery) {
        activeTarget = null;
        hasSmoothPoint = false;
        predVelX = predVelY = predVelZ = 0.0D;
        predictionFrames = 0;
        yawAxis.velocity = 0.0D;
        pitchAxis.velocity = 0.0D;
        hasLastAppliedRotation = false;
        if (!keepInfluenceRecovery) {
            influence = 1.0D;
            lastFrameNanos = -1L;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetTracking(false);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetTracking(false);
    }

    public Entity getEnemy() {
        return activeTarget;
    }

    private static final class AxisState {
        double velocity;
        double gain;
        double maxSpeed;
        double accel;
        double settleThreshold;
    }

    public static void addFriend(Entity entityPlayer) {
        friends.add(entityPlayer);
    }

    public static boolean addFriend(String name) {
        boolean found = false;
        for (Object o : mc.theWorld.getLoadedEntityList()) {
            Entity entity = (Entity) o;
            if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name))
                if (!Targets.isAFriend(entity)) {
                    addFriend(entity);
                    found = true;
                }
        }
        return found;
    }

    public static boolean removeFriend(String name) {
        try {
            boolean removed = false;
            boolean found = false;
            for (NetworkPlayerInfo networkPlayerInfo : new ArrayList<>(mc.getNetHandler().getPlayerInfoMap())) {
                Entity entity = mc.theWorld.getPlayerEntityByName(networkPlayerInfo.getDisplayName().getUnformattedText());
                if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name)) {
                    removed = removeFriend(entity);
                    found = true;
                }
            }
            return found && removed;
        } catch (Exception e) {
            Utils.Player.sendMessageToSelf("Error! Could not Remove " + name);
            return false;
        }
    }

    public static boolean removeFriend(Entity entityPlayer) {
        try {
            friends.remove(entityPlayer);
        } catch (Exception eeeeee) {
            eeeeee.printStackTrace();
            return false;
        }
        return true;
    }

    public static ArrayList<Entity> getFriends() {
        return friends;
    }
}
