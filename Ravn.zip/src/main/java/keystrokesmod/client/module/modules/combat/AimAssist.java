package keystrokesmod.client.module.modules.combat;

import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.Targets;
import keystrokesmod.client.module.modules.player.RightClicker;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class AimAssist extends Module {

    public static SliderSetting range, aimFov, speed;
    public static TickSetting clickAim, weaponOnly, breakBlocks, comboAim;

    public static ArrayList<Entity> friends = new ArrayList<>();

    private static final double RETENTION_FOV_MARGIN = 15.0D;
    private static final double RETENTION_RANGE_MARGIN = 0.75D;

    // Manual input detection
    private static final double MANUAL_INPUT_THRESHOLD_DEG = 0.6D;
    private static final double MANUAL_BLEND_FLOOR = 0.7D;
    private static final double MANUAL_HOLD_SECONDS = 0.12D;
    private static final double BLEND_TAU = 0.18D;

    // Target point smoothing (frame-rate independent)
    private static final double POINT_SMOOTHING_TAU = 0.09D;

    // Prediction
    private static final double PREDICTION_LEAD_SECONDS = 0.07D;

    // Spring dynamics: omega = 2.0 + speed * 0.35, critically damped via damping = 2*omega
    // At speed=24 (default): omega=10.4, settling ~0.38s
    // At speed=60 (max): omega=23.0, settling ~0.17s

    // Deadzone: 0.3 deg eliminates micro-jitter without visible inaccuracy
    private static final double DEADZONE_DEG = 0.3D;

    // Target loss settling: velocity below this threshold triggers clean reset
    private static final double SETTLE_VEL_THRESHOLD = 0.3D;

    // Frame timing bounds
    private static final double MAX_DT_SECONDS = 0.05D;
    private static final double MIN_DT_SECONDS = 0.0005D;

    // Block interaction debounce
    private static final int BLOCK_CONFIRM_FRAMES = 3;
    private static final int BLOCK_EXIT_FRAMES = 5;

    // Block interaction state
    private boolean blockInteractionActive = false;
    private int blockInteractionConfirmFrames = 0;
    private int blockExitFrames = 0;
    private Vec3 blockInteractionHitVec = null;

    // Combat target
    private EntityPlayer activeTarget;

    // Frame timing
    private long lastFrameNanos = -1L;

    // Manual input blend
    private double manualHoldTimer = 0.0D;
    private double blend = 1.0D;
    private boolean hasLastAppliedRotation = false;
    private double lastAppliedYaw, lastAppliedPitch;

    // Spring state (semi-implicit Euler: position + velocity)
    private double springYaw, springPitch;
    private double velYaw, velPitch;

    // Target point smoothing
    private double smoothPointX, smoothPointZ;
    private boolean hasSmoothPoint = false;
    private double targetVelX, targetVelZ;

    // Frame interpolation: previous and current simulation rotations
    private double prevRotationYaw, prevRotationPitch;
    private double currentRotationYaw, currentRotationPitch;

    // Combo aim
    private int comboCount = 0;
    private EntityPlayer comboTarget = null;
    private float prevComboDistance = 0;
    private boolean comboAimActive = false;
    private int prevComboTargetHurtTime = 0;

    public AimAssist() {
        super("AimAssist", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Fast, gliding aim pull - no snapping"));
        this.registerSetting(clickAim = new TickSetting("Only while clicking", true));
        this.registerSetting(comboAim = new TickSetting("Combo auto-aim", true));
        this.registerSetting(weaponOnly = new TickSetting("Weapon only", false));
        this.registerSetting(breakBlocks = new TickSetting("Don't aim at blocks", true));
        this.registerSetting(range = new SliderSetting("Range", 4.0D, 1.0D, 8.0D, 0.5D));
        this.registerSetting(aimFov = new SliderSetting("Field of view", 90.0D, 10.0D, 360.0D, 5.0D));
        this.registerSetting(speed = new SliderSetting("Speed", 24.0D, 4.0D, 60.0D, 2.0D));
    }

    @Subscribe
    public void onRender(ForgeEvent e) {
        if (!(e.getEvent() instanceof RenderWorldLastEvent)) return;
        RenderWorldLastEvent rwle = (RenderWorldLastEvent) e.getEvent();
        float partialTicks = rwle.partialTicks;

        if (!Utils.Client.currentScreenMinecraft() || !Utils.Player.isPlayerInGame()) {
            resetTracking(false);
            return;
        }

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            resetTracking(false);
            return;
        }

        long now = System.nanoTime();
        double dt = lastFrameNanos < 0L ? 0.016D : (now - lastFrameNanos) * 1.0E-9D;
        lastFrameNanos = now;
        if (dt < MIN_DT_SECONDS) dt = MIN_DT_SECONDS;
        else if (dt > MAX_DT_SECONDS) dt = MAX_DT_SECONDS;

        updateComboState();
        updateBlockInteractionState();

        if (!shouldAssist()) {
            resetTracking(true);
            return;
        }

        updateTarget();

        double[] desired;
        if (activeTarget == null && !blockInteractionActive) {
            if (hasLastAppliedRotation && (Math.abs(velYaw) > SETTLE_VEL_THRESHOLD || Math.abs(velPitch) > SETTLE_VEL_THRESHOLD)) {
                desired = new double[]{springYaw, springPitch};
            } else {
                resetTracking(true);
                return;
            }
        } else {
            desired = computeDesiredRotation(dt);
            if (desired == null) {
                resetTracking(true);
                return;
            }
        }

        float curYaw = mc.thePlayer.rotationYaw;
        float curPitch = mc.thePlayer.rotationPitch;

        // Initialize spring state from player rotation on first frame
        if (!hasLastAppliedRotation) {
            springYaw = curYaw;
            springPitch = curPitch;
            lastAppliedYaw = curYaw;
            lastAppliedPitch = curPitch;
            prevRotationYaw = curYaw;
            prevRotationPitch = curPitch;
            currentRotationYaw = curYaw;
            currentRotationPitch = curPitch;
            hasLastAppliedRotation = true;
        }

        // Detect manual mouse input and update blend factor
        double manualYaw = wrapDegrees(curYaw - lastAppliedYaw);
        double manualPitch = curPitch - lastAppliedPitch;
        double manualMag = Math.sqrt(manualYaw * manualYaw + manualPitch * manualPitch);
        if (manualMag > MANUAL_INPUT_THRESHOLD_DEG)
            manualHoldTimer = MANUAL_HOLD_SECONDS;
        else if (manualHoldTimer > 0.0D)
            manualHoldTimer -= dt;

        double targetBlend = manualHoldTimer > 0.0D ? MANUAL_BLEND_FLOOR : 1.0D;
        blend += (targetBlend - blend) * expApprox(-dt / BLEND_TAU);

        // Compute angular errors with yaw wraparound
        double errYaw = wrapDegrees(desired[0] - springYaw);
        double errPitch = desired[1] - springPitch;

        // Spring dynamics (semi-implicit Euler, frame-rate independent)
        // omega maps speed setting to natural frequency: 2.0 + speed * 0.35
        // Damping = 2*omega (critically damped)
        double omega = 2.0D + Math.max(speed.getInput(), 2.0D) * 0.35D;
        double stiffness = omega * omega;
        double damping = 2.0D * omega;

        double blendedErrYaw = errYaw * blend;
        double blendedErrPitch = errPitch * blend;

        double accYaw = stiffness * blendedErrYaw - damping * velYaw;
        velYaw += accYaw * dt;
        springYaw += velYaw * dt;
        springYaw = wrapDegrees(springYaw);

        double pitchOmega = omega * 0.9D;
        double pitchStiffness = pitchOmega * pitchOmega;
        double pitchDamping = 2.0D * pitchOmega;

        double accPitch = pitchStiffness * blendedErrPitch - pitchDamping * velPitch;
        velPitch += accPitch * dt;
        springPitch += velPitch * dt;
        springPitch = SliderSetting.check(springPitch, -89.9D, 89.9D);

        // Deadzone: damp velocity when error is tiny to prevent micro-jitter
        if (Math.abs(errYaw) < DEADZONE_DEG) {
            velYaw *= expApprox(-10.0D * dt);
        }
        if (Math.abs(errPitch) < DEADZONE_DEG) {
            velPitch *= expApprox(-10.0D * dt);
        }

        // Store previous simulation state for interpolation
        prevRotationYaw = currentRotationYaw;
        prevRotationPitch = currentRotationPitch;

        // Current simulation rotation is the spring state
        currentRotationYaw = springYaw;
        currentRotationPitch = springPitch;

        // Frame interpolation: smooth visual transition between simulation states
        double interpYaw = interpolateYaw(prevRotationYaw, currentRotationYaw, partialTicks);
        double interpPitch = prevRotationPitch + wrapDegrees(currentRotationPitch - prevRotationPitch) * partialTicks;

        // Apply interpolated rotation
        mc.thePlayer.rotationYaw = (float) interpYaw;
        mc.thePlayer.rotationPitch = (float) SliderSetting.check(interpPitch, -90.0D, 90.0D);

        lastAppliedYaw = mc.thePlayer.rotationYaw;
        lastAppliedPitch = mc.thePlayer.rotationPitch;
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!comboAim.isToggled()) return;

        if (e.isOutgoing() && e.getPacket() instanceof C0APacketAnimation) {
            EntityPlayer target = Targets.getTarget();
            if (target != null && mc.thePlayer.getDistanceToEntity(target) < range.getInput() + 1.0f) {
                if (comboTarget == null) {
                    comboTarget = target;
                    comboCount = 0;
                    prevComboDistance = mc.thePlayer.getDistanceToEntity(target);
                    prevComboTargetHurtTime = target.hurtTime;
                }
            }
        }
    }

    private void updateComboState() {
        if (mc.thePlayer == null || comboTarget == null) {
            resetCombo();
            return;
        }

        if (mc.thePlayer.hurtTime > 0) {
            resetCombo();
            return;
        }

        if (!hasLineOfSight(comboTarget)) {
            resetCombo();
            return;
        }

        if (comboTarget.isDead || !comboTarget.isEntityAlive()) {
            resetCombo();
            return;
        }

        if (comboTarget.hurtTime > 0 && prevComboTargetHurtTime == 0) {
            comboCount++;
            comboAimActive = comboCount >= 2;
        }
        prevComboTargetHurtTime = comboTarget.hurtTime;

        float currentDist = mc.thePlayer.getDistanceToEntity(comboTarget);
        float distDelta = currentDist - prevComboDistance;
        prevComboDistance = currentDist;

        if (distDelta > 0.8f) {
            resetCombo();
            return;
        }

        if (currentDist > range.getInput() + 2.0f) {
            resetCombo();
        }
    }

    private void resetCombo() {
        comboCount = 0;
        comboTarget = null;
        comboAimActive = false;
        prevComboDistance = 0;
        prevComboTargetHurtTime = 0;
    }

    private boolean shouldAssist() {
        if (breakBlocks.isToggled()) {
            if (blockInteractionActive || blockInteractionConfirmFrames > 0) {
                if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
                    return false;
                return true;
            }
        } else {
            if (mc.gameSettings.keyBindUseItem.isKeyDown())
                return false;
        }

        if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
            return false;

        if (comboAim.isToggled() && comboAimActive && comboCount >= 2) {
            if (comboTarget != null && hasLineOfSight(comboTarget)) {
                return true;
            }
        }

        if (!clickAim.isToggled())
            return true;
        if (Utils.Client.autoClickerClicking())
            return true;
        Module autoClicker = Raven.moduleManager.getModuleByClazz(RightClicker.class);
        return (Mouse.isButtonDown(0) && (autoClicker != null) && !autoClicker.isEnabled());
    }

    private void updateBlockInteractionState() {
        if (!breakBlocks.isToggled() || mc.thePlayer == null || mc.theWorld == null) {
            blockInteractionActive = false;
            blockInteractionConfirmFrames = 0;
            blockExitFrames = 0;
            blockInteractionHitVec = null;
            return;
        }

        boolean blockCandidate = false;
        if (mc.objectMouseOver != null
                && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            boolean breaking = Mouse.isButtonDown(0);
            boolean placing = mc.gameSettings.keyBindUseItem.isKeyDown();
            if (breaking || placing) {
                BlockPos p = mc.objectMouseOver.getBlockPos();
                if (p != null) {
                    Block bl = mc.theWorld.getBlockState(p).getBlock();
                    if ((bl != Blocks.air) && !(bl instanceof BlockLiquid)) {
                        blockCandidate = true;
                    }
                }
            }
        }

        if (blockCandidate) {
            blockInteractionConfirmFrames++;
            blockExitFrames = 0;
            if (blockInteractionConfirmFrames >= BLOCK_CONFIRM_FRAMES) {
                blockInteractionActive = true;
                if (mc.objectMouseOver != null && mc.objectMouseOver.hitVec != null) {
                    blockInteractionHitVec = mc.objectMouseOver.hitVec;
                }
            }
        } else {
            blockInteractionConfirmFrames = 0;
            if (blockInteractionActive) {
                blockExitFrames++;
                if (blockExitFrames >= BLOCK_EXIT_FRAMES) {
                    blockInteractionActive = false;
                    blockInteractionHitVec = null;
                    blockExitFrames = 0;
                }
            }
        }
    }

    private void updateTarget() {
        EntityPlayer candidate = Targets.getTarget();
        double maxDist = range.getInput();

        if (activeTarget != null && isTargetUsable(activeTarget, maxDist + RETENTION_RANGE_MARGIN,
                aimFov.getInput() + RETENTION_FOV_MARGIN))
            return;

        if (candidate == null || !isTargetUsable(candidate, maxDist, aimFov.getInput())) {
            activeTarget = null;
            return;
        }

        boolean isNewTarget = candidate != activeTarget;
        activeTarget = candidate;
        if (isNewTarget) {
            hasSmoothPoint = false;
            targetVelX = targetVelZ = 0.0D;
        }
    }

    private boolean isTargetUsable(EntityPlayer en, double maxDist, double maxFov) {
        if (en == null || en.isDead || !en.isEntityAlive() || en == mc.thePlayer)
            return false;
        if (mc.thePlayer.getDistanceToEntity(en) > maxDist)
            return false;
        double dx = en.posX - mc.thePlayer.posX;
        double dz = en.posZ - mc.thePlayer.posZ;
        double yawTo = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;
        double yawErr = Math.abs(wrapDegrees(yawTo - mc.thePlayer.rotationYaw));
        return yawErr <= maxFov;
    }

    private boolean hasLineOfSight(EntityPlayer target) {
        if (target == null) return false;
        Vec3 eyePos = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
        AxisAlignedBB bb = target.getEntityBoundingBox();
        Vec3 targetPos = new Vec3((bb.minX + bb.maxX) * 0.5D, (bb.minY + bb.maxY) * 0.5D, (bb.minZ + bb.maxZ) * 0.5D);
        return mc.theWorld.rayTraceBlocks(eyePos, targetPos) == null;
    }

    private double[] computeDesiredRotation(double dt) {
        if (blockInteractionActive && blockInteractionHitVec != null && breakBlocks.isToggled()) {
            return computeBlockInteractionRotation();
        }

        EntityPlayer en = activeTarget;
        if (en == null)
            return null;

        AxisAlignedBB bb = en.getEntityBoundingBox();
        double rawX = (bb.minX + bb.maxX) * 0.5D;
        double rawZ = (bb.minZ + bb.maxZ) * 0.5D;

        targetVelX = (en.posX - en.prevPosX) * 20.0D;
        targetVelZ = (en.posZ - en.prevPosZ) * 20.0D;

        // Frame-rate independent exponential smoothing for target point
        double pointAlpha = 1.0D - expApprox(-dt / POINT_SMOOTHING_TAU);
        if (!hasSmoothPoint) {
            smoothPointX = rawX;
            smoothPointZ = rawZ;
            hasSmoothPoint = true;
        } else {
            smoothPointX += (rawX - smoothPointX) * pointAlpha;
            smoothPointZ += (rawZ - smoothPointZ) * pointAlpha;
        }

        double tx = smoothPointX + targetVelX * PREDICTION_LEAD_SECONDS;
        double tz = smoothPointZ + targetVelZ * PREDICTION_LEAD_SECONDS;

        double eyeX = mc.thePlayer.posX;
        double eyeY = mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
        double eyeZ = mc.thePlayer.posZ;

        double dx = tx - eyeX;
        double dz = tz - eyeZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        double desiredYaw = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;

        double curPitch = mc.thePlayer.rotationPitch;
        double pitchTop = -(Math.atan2(bb.maxY - eyeY, horizontal) * 180.0D / Math.PI);
        double pitchBottom = -(Math.atan2(bb.minY - eyeY, horizontal) * 180.0D / Math.PI);
        double inset = 0.75D;
        double innerTop = pitchTop + inset;
        double innerBottom = pitchBottom - inset;
        double desiredPitch;
        if (curPitch < innerTop)
            desiredPitch = innerTop;
        else if (curPitch > innerBottom)
            desiredPitch = innerBottom;
        else
            desiredPitch = curPitch;
        desiredPitch = SliderSetting.check(desiredPitch, -89.9D, 89.9D);

        return new double[]{desiredYaw, desiredPitch};
    }

    private double[] computeBlockInteractionRotation() {
        if (mc.objectMouseOver != null && mc.objectMouseOver.hitVec != null) {
            blockInteractionHitVec = mc.objectMouseOver.hitVec;
        }

        Vec3 target = blockInteractionHitVec;
        if (target == null)
            return null;

        double eyeX = mc.thePlayer.posX;
        double eyeY = mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
        double eyeZ = mc.thePlayer.posZ;

        double dx = target.xCoord - eyeX;
        double dy = target.yCoord - eyeY;
        double dz = target.zCoord - eyeZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        double desiredYaw = (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0D;
        double desiredPitch = -(Math.atan2(dy, horizontal) * 180.0D / Math.PI);
        desiredPitch = SliderSetting.check(desiredPitch, -89.9D, 89.9D);

        return new double[]{desiredYaw, desiredPitch};
    }

    /**
     * Interpolate yaw through the short arc using wrapped angle difference.
     * Handles the -180/+180 boundary correctly.
     */
    private double interpolateYaw(double prev, double current, float t) {
        double delta = wrapDegrees(current - prev);
        return prev + delta * t;
    }

    /**
     * Frame-rate independent exponential decay.
     * Clamps extreme inputs to prevent numerical issues at very small/large dt.
     */
    private static double expApprox(double x) {
        if (x < -20.0D) return 0.0D;
        if (x > 0.0D) return 1.0D;
        return Math.exp(x);
    }

    private static double wrapDegrees(double degrees) {
        degrees %= 360.0D;
        if (degrees >= 180.0D) degrees -= 360.0D;
        else if (degrees < -180.0D) degrees += 360.0D;
        return degrees;
    }

    private void resetTracking(boolean softReset) {
        activeTarget = null;
        hasSmoothPoint = false;
        targetVelX = targetVelZ = 0.0D;
        hasLastAppliedRotation = false;
        manualHoldTimer = 0.0D;
        blend = 1.0D;
        velYaw = 0.0D;
        velPitch = 0.0D;
        springYaw = 0.0D;
        springPitch = 0.0D;
        blockInteractionActive = false;
        blockInteractionConfirmFrames = 0;
        blockExitFrames = 0;
        blockInteractionHitVec = null;
        if (!softReset) {
            lastFrameNanos = -1L;
            prevRotationYaw = 0.0D;
            prevRotationPitch = 0.0D;
            currentRotationYaw = 0.0D;
            currentRotationPitch = 0.0D;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetTracking(false);
        resetCombo();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetTracking(false);
        resetCombo();
    }

    public Entity getEnemy() {
        return activeTarget;
    }

    public static void addFriend(Entity entityPlayer) {
        friends.add(entityPlayer);
    }

    public static boolean addFriend(String name) {
        boolean found = false;
        for (Object o : mc.theWorld.getLoadedEntityList()) {
            Entity entity = (Entity) o;
            if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name))
                if (!Targets.isAFriend(entity)) {
                    addFriend(entity);
                    found = true;
                }
        }
        return found;
    }

    public static boolean removeFriend(String name) {
        try {
            boolean removed = false;
            boolean found = false;
            for (NetworkPlayerInfo networkPlayerInfo : new ArrayList<>(mc.getNetHandler().getPlayerInfoMap())) {
                Entity entity = mc.theWorld.getPlayerEntityByName(networkPlayerInfo.getDisplayName().getUnformattedText());
                if (entity.getName().equalsIgnoreCase(name) || entity.getCustomNameTag().equalsIgnoreCase(name)) {
                    removed = removeFriend(entity);
                    found = true;
                }
            }
            return found && removed;
        } catch (Exception e) {
            Utils.Player.sendMessageToSelf("Error! Could not Remove " + name);
            return false;
        }
    }

    public static boolean removeFriend(Entity entityPlayer) {
        try {
            friends.remove(entityPlayer);
        } catch (Exception eeeeee) {
            eeeeee.printStackTrace();
            return false;
        }
        return true;
    }

    public static ArrayList<Entity> getFriends() {
        return friends;
    }
}
