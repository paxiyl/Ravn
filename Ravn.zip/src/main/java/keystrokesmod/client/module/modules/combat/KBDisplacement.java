package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class KBDisplacement extends Module {

    private static SliderSetting hitRange;
    private static SliderSetting voidScanRange;
    private static SliderSetting voidScanDepth;
    private static SliderSetting yawOffset;
    private static TickSetting onlyWhileSprinting;
    private static TickSetting restoreAfterHit;
    private static TickSetting autoDetectSide;

    private float savedYaw, savedPitch;
    private boolean needsRestore = false;
    private boolean displacedThisTick = false;
    private int restoreTicks = 0;
    private float targetVoidYaw = Float.MAX_VALUE;
    private int lastAttackTick = 0;

    public KBDisplacement() {
        super("KBDisplacement", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Flicks rotation toward void on hit for void KB"));
        this.registerSetting(hitRange = new SliderSetting("Hit range", 3.5D, 2.0D, 6.0D, 0.1D));
        this.registerSetting(voidScanRange = new SliderSetting("Void scan range", 5.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(voidScanDepth = new SliderSetting("Void scan depth", 15.0D, 3.0D, 40.0D, 1.0D));
        this.registerSetting(yawOffset = new SliderSetting("Yaw offset", 0.0D, -90.0D, 90.0D, 1.0D));
        this.registerSetting(onlyWhileSprinting = new TickSetting("Only while sprinting", false));
        this.registerSetting(restoreAfterHit = new TickSetting("Restore after hit", true));
        this.registerSetting(autoDetectSide = new TickSetting("Auto detect void side", true));
    }

    @Override
    public void onEnable() {
        needsRestore = false;
        restoreTicks = 0;
        targetVoidYaw = Float.MAX_VALUE;
    }

    @Override
    public void onDisable() {
        if (mc.thePlayer != null && needsRestore) {
            mc.thePlayer.rotationYaw = savedYaw;
            mc.thePlayer.rotationPitch = savedPitch;
            needsRestore = false;
        }
    }

    @Subscribe
    public void onAttack(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof AttackEntityEvent)) return;
        if (!Utils.Player.isPlayerInGame()) return;

        EntityPlayer target = getTargetFromEvent((AttackEntityEvent) fe.getEvent());
        if (target == null) return;

        lastAttackTick = mc.thePlayer.ticksExisted;

        float voidYaw = findVoidYaw(target);
        if (voidYaw == Float.MAX_VALUE) {
            targetVoidYaw = Float.MAX_VALUE;
            return;
        }

        targetVoidYaw = voidYaw;
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        displacedThisTick = false;

        if (restoreTicks > 0) {
            restoreTicks--;
            if (restoreTicks == 0 && needsRestore && restoreAfterHit.isToggled()) {
                mc.thePlayer.rotationYaw = savedYaw;
                mc.thePlayer.rotationPitch = savedPitch;
                needsRestore = false;
            }
            return;
        }

        if (onlyWhileSprinting.isToggled() && !mc.thePlayer.isSprinting()) {
            if (needsRestore) {
                mc.thePlayer.rotationYaw = savedYaw;
                mc.thePlayer.rotationPitch = savedPitch;
                needsRestore = false;
            }
            return;
        }

        EntityPlayer target = getNearestTarget();
        if (target == null) {
            if (needsRestore) {
                mc.thePlayer.rotationYaw = savedYaw;
                mc.thePlayer.rotationPitch = savedPitch;
                needsRestore = false;
            }
            return;
        }

        int ticksSinceAttack = mc.thePlayer.ticksExisted - lastAttackTick;
        if (ticksSinceAttack > 4) {
            if (needsRestore) {
                mc.thePlayer.rotationYaw = savedYaw;
                mc.thePlayer.rotationPitch = savedPitch;
                needsRestore = false;
            }
            targetVoidYaw = Float.MAX_VALUE;
            return;
        }

        float voidYaw;
        if (targetVoidYaw != Float.MAX_VALUE) {
            voidYaw = targetVoidYaw;
        } else {
            voidYaw = findVoidYaw(target);
            if (voidYaw == Float.MAX_VALUE) {
                if (needsRestore) {
                    mc.thePlayer.rotationYaw = savedYaw;
                    mc.thePlayer.rotationPitch = savedPitch;
                    needsRestore = false;
                }
                return;
            }
        }

        if (!needsRestore) {
            savedYaw = mc.thePlayer.rotationYaw;
            savedPitch = mc.thePlayer.rotationPitch;
            needsRestore = true;
        }

        float currentYaw = mc.thePlayer.rotationYaw;

        float targetYaw = voidYaw + (float) yawOffset.getInput();

        float yawDiff = MathHelper.wrapAngleTo180_float(targetYaw - currentYaw);
        float maxStep = 80.0F;
        float step = MathHelper.clamp_float(yawDiff, -maxStep, maxStep);

        mc.thePlayer.rotationYaw = currentYaw + step;

        mc.thePlayer.rotationYawHead = mc.thePlayer.rotationYaw;
        mc.thePlayer.renderYawOffset = mc.thePlayer.rotationYaw;

        displacedThisTick = true;
    }

    private float findVoidYaw(EntityPlayer target) {
        int scanRange = (int) voidScanRange.getInput();
        int scanDepth = (int) voidScanDepth.getInput();

        float bestYaw = Float.MAX_VALUE;
        float bestDist = Float.MAX_VALUE;

        int targetX = (int) Math.floor(target.posX);
        int targetY = (int) Math.floor(target.posY);
        int targetZ = (int) Math.floor(target.posZ);

        for (int dx = -scanRange; dx <= scanRange; dx++) {
            for (int dz = -scanRange; dz <= scanRange; dz++) {
                if (dx == 0 && dz == 0) continue;

                for (int dy = 0; dy >= -scanDepth; dy--) {
                    BlockPos pos = new BlockPos(targetX + dx, targetY + dy, targetZ + dz);

                    if (isVoid(pos) && isPathClearToVoid(target, pos)) {
                        float vx = (float)(pos.getX() + 0.5 - mc.thePlayer.posX);
                        float vz = (float)(pos.getZ() + 0.5 - mc.thePlayer.posZ);
                        float distSq = vx * vx + vz * vz;

                        if (distSq < bestDist) {
                            bestDist = distSq;
                            bestYaw = (float) Math.toDegrees(Math.atan2(vz, vx)) - 90.0F;
                        }
                    }
                }
            }
        }

        return bestYaw;
    }

    private boolean isVoid(BlockPos pos) {
        IBlockState state = mc.theWorld.getBlockState(pos);
        if (state.getBlock() != Blocks.air) return false;

        for (int y = pos.getY() - 1; y >= 0; y--) {
            BlockPos below = new BlockPos(pos.getX(), y, pos.getZ());
            IBlockState belowState = mc.theWorld.getBlockState(below);
            if (belowState.getBlock() != Blocks.air) {
                return false;
            }
        }
        return true;
    }

    private boolean isPathClearToVoid(EntityPlayer target, BlockPos voidPos) {
        Vec3 start = new Vec3(target.posX, target.posY + target.getEyeHeight(), target.posZ);
        Vec3 end = new Vec3(voidPos.getX() + 0.5, voidPos.getY() + 0.5, voidPos.getZ() + 0.5);
        Vec3 dir = end.subtract(start);
        double dist = start.distanceTo(end);
        double steps = dist * 3.0;

        for (int i = 1; i < steps; i++) {
            double t = i / steps;
            Vec3 check = start.addVector(dir.xCoord * t, dir.yCoord * t, dir.zCoord * t);
            BlockPos blockPos = new BlockPos(check);
            IBlockState state = mc.theWorld.getBlockState(blockPos);
            if (state.getBlock().isNormalCube()) {
                return false;
            }
        }
        return true;
    }

    private EntityPlayer getNearestTarget() {
        EntityPlayer closest = null;
        double closestDist = hitRange.getInput();

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (entity instanceof EntityPlayer && entity != mc.thePlayer) {
                double dist = mc.thePlayer.getDistanceToEntity(entity);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = (EntityPlayer) entity;
                }
            }
        }
        return closest;
    }

    private EntityPlayer getTargetFromEvent(AttackEntityEvent event) {
        if (event.target instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) event.target;
            if (mc.thePlayer.getDistanceToEntity(player) <= hitRange.getInput() + 1.0F) {
                return player;
            }
        }
        return null;
    }
}
