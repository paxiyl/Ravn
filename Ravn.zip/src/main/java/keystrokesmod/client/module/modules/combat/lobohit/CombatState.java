package keystrokesmod.client.module.modules.combat.lobohit;

public class CombatState {

    public enum State {
        IDLE,
        COMBAT_DETECTED,
        FOLLOW_TARGET,
        POST_HIT,
        SPACING_CONTROL
    }

    public enum SpacingDecision {
        MAINTAIN,
        CLOSE,
        BACK_OFF
    }

    public enum VelocityClassification {
        CLOSING,
        STABLE,
        SEPARATING
    }

    private State state = State.IDLE;
    private SpacingDecision decision = SpacingDecision.MAINTAIN;
    private VelocityClassification velocityClass = VelocityClassification.STABLE;

    private float currentDistance = 0;
    private float idealDistance = 3.0f;
    private float distanceDelta = 0;

    private float playerVelocity = 0;
    private float targetVelocity = 0;
    private float relativeVelocity = 0;

    private float estimatedKnockback = 0;
    private float recentKnockback = 0;

    private float pingMs = 50;
    private float smoothedPing = 50;
    private float pingVariance = 0;

    private float predictionConfidence = 0.5f;

    private boolean playerGrounded = true;
    private boolean targetGrounded = true;
    private boolean playerMoving = false;
    private boolean targetMoving = false;

    private float playerHealth = 20;
    private float targetHealth = 20;

    private long lastHitTimestamp = 0;
    private int ticksSinceLastHit = 0;
    private int ticksInCombat = 0;

    private boolean playerWasHit = false;
    private float playerKbReceived = 0;

    private int stateTicks = 0;
    private long stateEntryTime = 0;

    private float correctionStrength = 1.0f;

    public State getState() { return state; }
    public void setState(State s) {
        if (s != state) {
            state = s;
            stateEntryTime = System.currentTimeMillis();
            stateTicks = 0;
        }
    }

    public SpacingDecision getDecision() { return decision; }
    public void setDecision(SpacingDecision d) { decision = d; }

    public VelocityClassification getVelocityClass() { return velocityClass; }
    public void setVelocityClass(VelocityClassification v) { velocityClass = v; }

    public float getCurrentDistance() { return currentDistance; }
    public void setCurrentDistance(float d) { currentDistance = d; }

    public float getIdealDistance() { return idealDistance; }
    public void setIdealDistance(float d) { idealDistance = d; }

    public float getDistanceDelta() { return distanceDelta; }
    public void setDistanceDelta(float d) { distanceDelta = d; }

    public float getPlayerVelocity() { return playerVelocity; }
    public void setPlayerVelocity(float v) { playerVelocity = v; }

    public float getTargetVelocity() { return targetVelocity; }
    public void setTargetVelocity(float v) { targetVelocity = v; }

    public float getRelativeVelocity() { return relativeVelocity; }
    public void setRelativeVelocity(float v) { relativeVelocity = v; }

    public float getEstimatedKnockback() { return estimatedKnockback; }
    public void setEstimatedKnockback(float kb) { estimatedKnockback = kb; }

    public float getRecentKnockback() { return recentKnockback; }
    public void setRecentKnockback(float kb) { recentKnockback = kb; }

    public float getPingMs() { return pingMs; }
    public void setPingMs(float p) {
        float delta = p - smoothedPing;
        pingVariance = pingVariance * 0.9f + Math.abs(delta) * 0.1f;
        smoothedPing = smoothedPing * 0.8f + p * 0.2f;
        pingMs = p;
    }

    public float getSmoothedPing() { return smoothedPing; }
    public float getPingVariance() { return pingVariance; }

    public float getPredictionConfidence() { return predictionConfidence; }
    public void setPredictionConfidence(float c) { predictionConfidence = Math.max(0, Math.min(1, c)); }

    public boolean isPlayerGrounded() { return playerGrounded; }
    public void setPlayerGrounded(boolean g) { playerGrounded = g; }

    public boolean isTargetGrounded() { return targetGrounded; }
    public void setTargetGrounded(boolean g) { targetGrounded = g; }

    public boolean isPlayerMoving() { return playerMoving; }
    public void setPlayerMoving(boolean m) { playerMoving = m; }

    public boolean isTargetMoving() { return targetMoving; }
    public void setTargetMoving(boolean m) { targetMoving = m; }

    public float getPlayerHealth() { return playerHealth; }
    public void setPlayerHealth(float h) { playerHealth = h; }

    public float getTargetHealth() { return targetHealth; }
    public void setTargetHealth(float h) { targetHealth = h; }

    public long getLastHitTimestamp() { return lastHitTimestamp; }
    public void setLastHitTimestamp(long t) { lastHitTimestamp = t; }

    public int getTicksSinceLastHit() { return ticksSinceLastHit; }
    public void resetTicksSinceLastHit() { ticksSinceLastHit = 0; }

    public int getTicksInCombat() { return ticksInCombat; }
    public void setTicksInCombat(int t) { ticksInCombat = t; }

    public boolean isPlayerWasHit() { return playerWasHit; }
    public void setPlayerWasHit(boolean h) { playerWasHit = h; }

    public float getPlayerKbReceived() { return playerKbReceived; }
    public void setPlayerKbReceived(float kb) { playerKbReceived = kb; }

    public int getStateTicks() { return stateTicks; }

    public float getCorrectionStrength() { return correctionStrength; }
    public void setCorrectionStrength(float s) { correctionStrength = Math.max(0, Math.min(1, s)); }

    public void tick() {
        stateTicks++;
        ticksSinceLastHit++;
        if (state == State.IDLE) {
            ticksInCombat = 0;
        } else {
            ticksInCombat++;
        }
    }

    public void reset() {
        state = State.IDLE;
        decision = SpacingDecision.MAINTAIN;
        velocityClass = VelocityClassification.STABLE;
        currentDistance = 0;
        idealDistance = 3.0f;
        distanceDelta = 0;
        playerVelocity = 0;
        targetVelocity = 0;
        relativeVelocity = 0;
        estimatedKnockback = 0;
        recentKnockback = 0;
        predictionConfidence = 0.5f;
        playerWasHit = false;
        playerKbReceived = 0;
        lastHitTimestamp = 0;
        ticksSinceLastHit = 0;
        ticksInCombat = 0;
        stateTicks = 0;
    }
}
