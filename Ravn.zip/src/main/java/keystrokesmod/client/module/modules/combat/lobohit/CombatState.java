package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class CombatState {
    public enum State {
        IDLE,
        APPROACH,
        COMBO,
        FINISHER,
        DEFENSIVE,
        SPACING,
        KB_RECOVERY,
        JUMP_COMBO,
        PLANE_COMBO,
        AIR_CONTROL,
        TRADING,
        STUNNED,
        EXITING
    }

    private State currentState = State.IDLE;
    private long stateEntryTime = 0;
    private int stateTicks = 0;
    private int consecutiveStateEntries = 0;
    private State previousState = State.IDLE;

    private float targetDistance = 0;
    private float targetDistanceDelta = 0;
    private float targetHealth = 20;
    private float playerHealth = 20;
    private float relativeVelocity = 0;
    private float kbEstimate = 0;
    private int targetHurtTime = 0;
    private int targetHurtTimeSinceLastHit = 0;
    private int playerAttackCooldown = 0;
    private int playerTicksSinceLastHit = 0;
    private boolean playerGrounded = true;
    private boolean targetGrounded = true;
    private boolean targetMoving = false;
    private boolean playerSprintResetActive = false;
    private boolean playerWtapActive = false;
    private boolean playerShouldApproach = true;
    private boolean targetLocked = false;
    private boolean playerVulnerable = true;
    private boolean staggered = false;
    private float playerPositionConfidence = 0;
    private float targetPositionConfidence = 0;
    private float pingMs = 0;
    private boolean serverConfirmedCombo = false;
    private boolean lastHitRegistered = false;

    private final float[] recentDistances = new float[8];
    private int distanceIndex = 0;
    private final float[] recentHealthDeltas = new float[8];
    private int healthDeltaIndex = 0;
    private final int[] recentHurtTimes = new int[16];
    private int hurtTimeIndex = 0;

    public State getState() {
        return currentState;
    }

    public State getPreviousState() {
        return previousState;
    }

    public void setState(State newState) {
        if (newState != currentState) {
            previousState = currentState;
            currentState = newState;
            stateEntryTime = System.currentTimeMillis();
            stateTicks = 0;
            consecutiveStateEntries++;
        }
    }

    public void reset() {
        currentState = State.IDLE;
        previousState = State.IDLE;
        stateEntryTime = 0;
        stateTicks = 0;
        consecutiveStateEntries = 0;
        resetHistory();
    }

    public void resetHistory() {
        java.util.Arrays.fill(recentDistances, 0);
        java.util.Arrays.fill(recentHealthDeltas, 0);
        java.util.Arrays.fill(recentHurtTimes, 0);
        distanceIndex = 0;
        healthDeltaIndex = 0;
        hurtTimeIndex = 0;
    }

    public void tick() {
        stateTicks++;
        targetHurtTimeSinceLastHit++;
        playerTicksSinceLastHit++;
    }

    public long getStateDuration() {
        return System.currentTimeMillis() - stateEntryTime;
    }

    public int getStateTicks() {
        return stateTicks;
    }

    public void recordDistance(float dist) {
        recentDistances[distanceIndex % recentDistances.length] = dist;
        distanceIndex++;
    }

    public void recordHealthDelta(float delta) {
        recentHealthDeltas[healthDeltaIndex % recentHealthDeltas.length] = delta;
        healthDeltaIndex++;
    }

    public void recordHurtTime(int hurtTime) {
        recentHurtTimes[hurtTimeIndex % recentHurtTimes.length] = hurtTime;
        hurtTimeIndex++;
        targetHurtTimeSinceLastHit = 0;
    }

    public float getAverageDistance() {
        float sum = 0;
        int count = Math.min(distanceIndex, recentDistances.length);
        if (count == 0) return 0;
        for (int i = 0; i < count; i++) {
            sum += recentDistances[i];
        }
        return sum / count;
    }

    public float getDistanceTrend() {
        if (distanceIndex < 2) return 0;
        int count = Math.min(distanceIndex, recentDistances.length);
        float oldHalf = 0, newHalf = 0;
        int half = count / 2;
        for (int i = 0; i < half; i++) {
            oldHalf += recentDistances[i];
        }
        for (int i = half; i < count; i++) {
            newHalf += recentDistances[i];
        }
        return (newHalf / (count - half)) - (oldHalf / half);
    }

    public float getAverageHealthDelta() {
        float sum = 0;
        int count = Math.min(healthDeltaIndex, recentHealthDeltas.length);
        if (count == 0) return 0;
        for (int i = 0; i < count; i++) {
            sum += recentHealthDeltas[i];
        }
        return sum / count;
    }

    public boolean wasRecentlyHurt(int ticks) {
        return targetHurtTimeSinceLastHit <= ticks;
    }

    // --- Getters/Setters ---
    public float getTargetDistance() { return targetDistance; }
    public void setTargetDistance(float d) { this.targetDistance = d; }

    public float getTargetDistanceDelta() { return targetDistanceDelta; }
    public void setTargetDistanceDelta(float d) { this.targetDistanceDelta = d; }

    public float getTargetHealth() { return targetHealth; }
    public void setTargetHealth(float h) { this.targetHealth = h; }

    public float getPlayerHealth() { return playerHealth; }
    public void setPlayerHealth(float h) { this.playerHealth = h; }

    public float getRelativeVelocity() { return relativeVelocity; }
    public void setRelativeVelocity(float v) { this.relativeVelocity = v; }

    public float getKbEstimate() { return kbEstimate; }
    public void setKbEstimate(float kb) { this.kbEstimate = kb; }

    public int getTargetHurtTime() { return targetHurtTime; }
    public void setTargetHurtTime(int ht) { this.targetHurtTime = ht; }

    public int getTargetHurtTimeSinceLastHit() { return targetHurtTimeSinceLastHit; }

    public int getPlayerAttackCooldown() { return playerAttackCooldown; }
    public void setPlayerAttackCooldown(int cd) { this.playerAttackCooldown = cd; }

    public int getPlayerTicksSinceLastHit() { return playerTicksSinceLastHit; }
    public void resetPlayerTicksSinceLastHit() { this.playerTicksSinceLastHit = 0; }

    public boolean isPlayerGrounded() { return playerGrounded; }
    public void setPlayerGrounded(boolean g) { this.playerGrounded = g; }

    public boolean isTargetGrounded() { return targetGrounded; }
    public void setTargetGrounded(boolean g) { this.targetGrounded = g; }

    public boolean isTargetMoving() { return targetMoving; }
    public void setTargetMoving(boolean m) { this.targetMoving = m; }

    public boolean isPlayerSprintResetActive() { return playerSprintResetActive; }
    public void setPlayerSprintResetActive(boolean a) { this.playerSprintResetActive = a; }

    public boolean isPlayerWtapActive() { return playerWtapActive; }
    public void setPlayerWtapActive(boolean a) { this.playerWtapActive = a; }

    public boolean isPlayerShouldApproach() { return playerShouldApproach; }
    public void setPlayerShouldApproach(boolean a) { this.playerShouldApproach = a; }

    public boolean isTargetLocked() { return targetLocked; }
    public void setTargetLocked(boolean l) { this.targetLocked = l; }

    public boolean isPlayerVulnerable() { return playerVulnerable; }
    public void setPlayerVulnerable(boolean v) { this.playerVulnerable = v; }

    public boolean isStaggered() { return staggered; }
    public void setStaggered(boolean s) { this.staggered = s; }

    public float getPlayerPositionConfidence() { return playerPositionConfidence; }
    public void setPlayerPositionConfidence(float c) { this.playerPositionConfidence = c; }

    public float getTargetPositionConfidence() { return targetPositionConfidence; }
    public void setTargetPositionConfidence(float c) { this.targetPositionConfidence = c; }

    public float getPingMs() { return pingMs; }
    public void setPingMs(float p) { this.pingMs = p; }

    public boolean isServerConfirmedCombo() { return serverConfirmedCombo; }
    public void setServerConfirmedCombo(boolean c) { this.serverConfirmedCombo = c; }

    public boolean isLastHitRegistered() { return lastHitRegistered; }
    public void setLastHitRegistered(boolean r) { this.lastHitRegistered = r; }

    public int getConsecutiveStateEntries() { return consecutiveStateEntries; }

    public boolean isInState(State s) { return currentState == s; }

    public long ticksInState(int tps) {
        return getStateDuration() / (1000 / Math.max(tps, 1));
    }
}
