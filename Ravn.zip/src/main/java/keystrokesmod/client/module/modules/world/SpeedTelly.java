package keystrokesmod.client.module.modules.world;

import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.event.impl.PostPlayerInputEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import com.google.common.eventbus.Subscribe;

public class SpeedTelly extends Module {

    public static SliderSetting activationDelay;
    public static TickSetting autoSwap;
    public static SliderSetting cycleSpeed;
    public static SliderSetting setupJumpTick;

    private boolean armed = false;
    private boolean running = false;
    private long activatePromptAt = 0;
    private int setupTick = -1;
    private int cyclePhase = 13;
    private float baseYaw = 0;
    private int travelX = 0;
    private int travelZ = 0;

    private double antiSwayLane = 0;
    private float antiSwayYawOffset = 0;
    private boolean antiSwayTapUsed = false;

    private float scriptedYaw = 0;
    private float scriptedPitch = 0;

    private boolean rotationActive = false;
    private long rotationStartedAt = 0;
    private long rotationDuration = 40;
    private float rotationStartYaw = 0;
    private float rotationStartPitch = 0;
    private float rotationTargetYaw = 0;
    private float rotationTargetPitch = 0;
    private int rotationStepCounter = 0;

    private BlockPos lastSupportPos = null;
    private int lastSupportFace = -1;
    private BlockPos lastPlacedPos = null;
    private long lastFreezeCheck = 0;

    private static final double SENSITIVITY_QUANTUM = 0.03404715;
    private static final int[] YAW_NUDGE_PATTERN = {0, 1, -1, 2, -2};

    // 14-phase forward sprint telly curves
    // Phases 0-2: sprint launch (ground + jump)
    // Phases 3-4: air acceleration
    // Phases 5-8: placement window (looking down)
    // Phases 9-11: recovery (rotate up)
    // Phases 12-13: re-accelerate to sprint

    private static final float[] YAW_CURVE = {
        0.0f, 10.0f, 20.0f, 15.0f, 5.0f, -5.0f, -10.0f,
        -5.0f, 0.0f, 5.0f, 10.0f, 15.0f, 5.0f, 0.0f
    };

    private static final float[] PITCH_CURVE = {
        30.0f, 25.0f, 20.0f, 40.0f, 65.0f, 75.0f, 80.0f,
        78.0f, 72.0f, 60.0f, 45.0f, 35.0f, 30.0f, 25.0f
    };

    private static final float[] FORWARD_CURVE = {
        1.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.3f, 0.0f,
        -0.3f, -0.5f, -0.5f, 0.0f, 0.5f, 1.0f, 1.0f
    };

    private static final float[] STRAFE_CURVE = {
        0.0f, 0.0f, -0.5f, -0.5f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.5f, 0.5f, 0.5f, 0.0f, 0.0f
    };

    private static final boolean[] SPRINT_CURVE = {
        true, true, true, false, false, false, false,
        false, false, false, false, false, true, true
    };

    private static final boolean[] JUMP_CURVE = {
        false, true, true, true, true, true, true,
        true, true, true, true, true, true, false
    };

    private static final boolean[] USE_CURVE = {
        false, false, false, false, true, true, true,
        true, true, false, false, false, false, false
    };

    public SpeedTelly() {
        super("SpeedTelly", ModuleCategory.world);
        this.registerSetting(new DescriptionSetting("Forward sprint telly bridging"));
        this.registerSetting(activationDelay = new SliderSetting("Activate delay (ms)", 1000, 500, 2000, 50));
        this.registerSetting(autoSwap = new TickSetting("Auto swap blocks", true));
        this.registerSetting(cycleSpeed = new SliderSetting("Cycle speed (ms)", 40, 25, 60, 5));
        this.registerSetting(setupJumpTick = new SliderSetting("Setup jump tick", 4, 2, 8, 1));
    }

    @Override
    public void onEnable() {
        armed = true;
        running = false;
        activatePromptAt = 0;
        setupTick = 0;
        cyclePhase = 13;
        rotationActive = false;
        lastFreezeCheck = 0;
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;
    }

    @Override
    public void onDisable() {
        stopAutomation(false);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (running) {
            long now = System.currentTimeMillis();
            if (lastFreezeCheck != 0 && now - lastFreezeCheck > 300) {
                stopAutomation(true);
                return;
            }
            lastFreezeCheck = now;

            if (mc.thePlayer.fallDistance > 7.0f) {
                stopAutomation(true);
                return;
            }

            if (!isHoldingBlock()) {
                stopAutomation(true);
                return;
            }

            if (autoSwap.isToggled()) {
                handleAutoSwap();
            }

            mc.gameSettings.keyBindAttack.pressed = false;
        } else if (armed) {
            updateActivationPrompt();
        }
    }

    @Subscribe
    public void onPostPlayerInput(PostPlayerInputEvent e) {
        if (mc.thePlayer == null) return;

        if (running) {
            mc.gameSettings.keyBindSneak.pressed = false;
            mc.thePlayer.setSneaking(false);

            applySmoothedRotation();
            cycleTick();
        } else if (armed) {
            updateActivationPrompt();
        }
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (mc.thePlayer == null) return;

        if (e.isIncoming() && e.getPacket() instanceof S08PacketPlayerPosLook) {
            if (running) {
                stopAutomation(true);
            }
        }
    }

    private void updateActivationPrompt() {
        EntityPlayer player = mc.thePlayer;
        if (player == null) return;

        // Speed telly: activate at back edge of block, looking forward
        // Player faces the direction of travel, standing at the back edge
        boolean lookingForward = Math.abs(player.rotationPitch) <= 25.0f;
        boolean atBackEdge = lookingForward && isAtBackEdge();
        boolean sneaking = mc.gameSettings.keyBindSneak.isKeyDown();

        if (sneaking && atBackEdge) {
            if (activatePromptAt == 0) {
                activatePromptAt = System.currentTimeMillis();
            }

            long elapsed = System.currentTimeMillis() - activatePromptAt;
            if (elapsed >= (long) activationDelay.getInput()) {
                if (mc.gameSettings.keyBindUseItem.isKeyDown() && isYawAligned(player.rotationYaw)) {
                    beginAutomation();
                    return;
                }
            }
        } else {
            activatePromptAt = 0;
        }
    }

    private void beginAutomation() {
        EntityPlayer player = mc.thePlayer;
        if (player == null || !isHoldingBlock()) return;
        if (!isYawAligned(player.rotationYaw)) return;

        baseYaw = player.rotationYaw;
        calculateTravelDirection(baseYaw);

        Vec3 pos = player.getPositionVector();
        antiSwayLane = travelX != 0 ? pos.zCoord : pos.xCoord;
        antiSwayYawOffset = 0;
        antiSwayTapUsed = false;

        running = true;
        armed = false;
        setupTick = 0;
        cyclePhase = 13;
        scriptedYaw = baseYaw;
        scriptedPitch = player.rotationPitch;
        lastFreezeCheck = System.currentTimeMillis();
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;

        // Start walking forward off the edge
        applyMovement(1.0f, 0.0f, false, true);
        setRotationTarget(baseYaw + 5.0f, 25.0f, (int) (long) cycleSpeed.getInput());
        mc.gameSettings.keyBindUseItem.pressed = false;
    }

    private void stopAutomation(boolean rearm) {
        running = false;
        armed = rearm;
        activatePromptAt = 0;
        setupTick = rearm ? 0 : -1;
        cyclePhase = 13;
        rotationActive = false;
        antiSwayYawOffset = 0;
        lastSupportPos = null;
        lastSupportFace = -1;
        lastPlacedPos = null;

        if (mc.thePlayer != null) {
            mc.thePlayer.moveForward = 0;
            mc.thePlayer.moveStrafing = 0;
            mc.thePlayer.setSprinting(false);
            mc.thePlayer.setSneaking(false);
        }

        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), false);
        mc.gameSettings.keyBindUseItem.pressed = false;
    }

    private void applyMovement(float forward, float strafe, boolean jumping, boolean sprinting) {
        float strafeCorrection = getAntiSwayCorrection(forward, strafe);

        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), forward > 0.03f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindBack.getKeyCode(), forward < -0.03f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindLeft.getKeyCode(), strafeCorrection > 0.5f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindRight.getKeyCode(), strafeCorrection < -0.5f);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), jumping);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), sprinting);

        mc.thePlayer.movementInput.moveForward = forward;
        mc.thePlayer.movementInput.moveStrafe = strafeCorrection;
        mc.thePlayer.movementInput.jump = jumping;
        mc.thePlayer.movementInput.sneak = false;

        mc.thePlayer.moveForward = forward;
        mc.thePlayer.moveStrafing = strafeCorrection;

        mc.thePlayer.setSneaking(false);
        mc.thePlayer.setSprinting(sprinting);
        mc.gameSettings.keyBindSneak.pressed = false;
    }

    private void cycleTick() {
        if (mc.thePlayer == null) return;

        int jumpTick = (int) (long) setupJumpTick.getInput();

        // Setup phase: walk forward off the edge
        // ticks 0 to (jumpTick-1): sprint forward on ground
        // tick jumpTick: jump
        // ticks (jumpTick+1) to 7: air time, preparing
        if (setupTick >= 0 && setupTick < 8) {
            boolean setupJump = setupTick >= jumpTick;
            boolean setupSprint = setupTick < jumpTick;
            applyMovement(1.0f, 0.0f, setupJump, setupSprint);

            if (setupTick < jumpTick) {
                setRotationTarget(baseYaw + 5.0f, 25.0f, (int) (long) cycleSpeed.getInput());
            } else if (setupTick == 7) {
                // Transition: snap to first cycle phase rotation
                setRotationTarget(baseYaw + YAW_CURVE[0], PITCH_CURVE[0], (int) (long) cycleSpeed.getInput());
            } else {
                setRotationTarget(baseYaw + 10.0f, 20.0f, (int) (long) cycleSpeed.getInput());
            }

            setupTick++;
            return;
        }

        // Transition from setup to cycle
        if (setupTick >= 8) {
            setupTick = -1;
            cyclePhase = 13;
        }

        int phase = cyclePhase;
        int dur = (int) (long) cycleSpeed.getInput();

        applyMovement(FORWARD_CURVE[phase], STRAFE_CURVE[phase], JUMP_CURVE[phase], SPRINT_CURVE[phase]);
        mc.gameSettings.keyBindUseItem.pressed = USE_CURVE[phase];

        // Attempt block placement during use phases
        if (USE_CURVE[phase]) {
            attemptDirectPlacement();
        }

        int nextPhase = (phase + 1) % YAW_CURVE.length;
        setRotationTarget(baseYaw + YAW_CURVE[nextPhase], PITCH_CURVE[nextPhase], dur);
        cyclePhase = nextPhase;
    }

    private void attemptDirectPlacement() {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return;

        int playerBlockX = floor(mc.thePlayer.posX);
        int playerBlockY = floor(mc.thePlayer.posY - 0.01);
        int playerBlockZ = floor(mc.thePlayer.posZ);

        int targetY = playerBlockY - 1;
        BlockPos placePos = new BlockPos(playerBlockX, targetY, playerBlockZ);
        if (!isReplaceable(placePos)) return;

        BlockPos supportPos = findBestSupport(placePos);
        if (supportPos == null) return;

        int face = findSupportFace(supportPos, placePos);
        if (face < 2 || face > 5) return;

        EnumFacing enumFace = getEnumFacing(face);
        Vec3 hitVec = getFaceHitVec(supportPos, face, 0.5, 0.5);

        C08PacketPlayerBlockPlacement packet = new C08PacketPlayerBlockPlacement(
            supportPos, face, held, (float) hitVec.xCoord, (float) hitVec.yCoord, (float) hitVec.zCoord
        );
        mc.getNetHandler().addToSendQueue(packet);
        mc.thePlayer.swingItem();

        lastSupportPos = supportPos;
        lastSupportFace = face;
        lastPlacedPos = placePos;
    }

    private BlockPos findBestSupport(BlockPos placePos) {
        int face = getTravelFace();
        if (face < 0) return null;

        // For forward travel, support is the block we just left (behind us)
        BlockPos travelSupport = placePos.offset(getEnumFacing(face).getOpposite());
        if (isSupportBlock(travelSupport)) return travelSupport;

        BlockPos belowSupport = placePos.offset(EnumFacing.DOWN);
        if (isSupportBlock(belowSupport)) return belowSupport;

        for (EnumFacing f : EnumFacing.HORIZONTALS) {
            BlockPos neighbor = placePos.offset(f);
            if (isSupportBlock(neighbor)) return neighbor;
        }

        BlockPos downFromTravel = placePos.down().offset(getEnumFacing(face).getOpposite());
        if (isSupportBlock(downFromTravel)) return downFromTravel;

        return null;
    }

    private int findSupportFace(BlockPos support, BlockPos place) {
        int dx = place.getX() - support.getX();
        int dy = place.getY() - support.getY();
        int dz = place.getZ() - support.getZ();

        if (dx == 1) return 5;
        if (dx == -1) return 4;
        if (dz == 1) return 3;
        if (dz == -1) return 2;
        if (dy == 1) return 1;
        if (dy == -1) return 0;
        return -1;
    }

    private int getTravelFace() {
        if (travelX > 0) return 5;
        if (travelX < 0) return 4;
        if (travelZ > 0) return 3;
        if (travelZ < 0) return 2;
        return -1;
    }

    private EnumFacing getEnumFacing(int face) {
        switch (face) {
            case 0: return EnumFacing.DOWN;
            case 1: return EnumFacing.UP;
            case 2: return EnumFacing.NORTH;
            case 3: return EnumFacing.SOUTH;
            case 4: return EnumFacing.WEST;
            case 5: return EnumFacing.EAST;
            default: return EnumFacing.NORTH;
        }
    }

    private Vec3 getFaceHitVec(BlockPos pos, int face, double hx, double hz) {
        switch (face) {
            case 2: return new Vec3(pos.getX() + hx, pos.getY() + 0.5, pos.getZ() + 0.001);
            case 3: return new Vec3(pos.getX() + hx, pos.getY() + 0.5, pos.getZ() + 0.999);
            case 4: return new Vec3(pos.getX() + 0.001, pos.getY() + 0.5, pos.getZ() + hz);
            case 5: return new Vec3(pos.getX() + 0.999, pos.getY() + 0.5, pos.getZ() + hz);
            default: return new Vec3(pos.getX() + hx, pos.getY() + 0.999, pos.getZ() + hz);
        }
    }

    private boolean isSupportBlock(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block != Blocks.air && block != Blocks.water && block != Blocks.flowing_water
            && block != Blocks.lava && block != Blocks.flowing_lava && block != Blocks.fire;
    }

    private boolean isReplaceable(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.Block block = mc.theWorld.getBlockState(pos).getBlock();
        return block == Blocks.air || block == Blocks.water || block == Blocks.flowing_water
            || block == Blocks.lava || block == Blocks.flowing_lava || block == Blocks.fire;
    }

    private void setRotationTarget(float targetYaw, float targetPitch, long duration) {
        if (mc.thePlayer == null) return;

        applySmoothedRotation();
        rotationStartYaw = mc.thePlayer.rotationYaw;
        rotationStartPitch = mc.thePlayer.rotationPitch;

        float correctedYaw = targetYaw + antiSwayYawOffset;
        rotationStepCounter++;
        correctedYaw += (float) (SENSITIVITY_QUANTUM * YAW_NUDGE_PATTERN[rotationStepCounter % 5]);

        rotationTargetYaw = rotationStartYaw + wrapAngle(correctedYaw - rotationStartYaw);
        rotationTargetPitch = MathHelper.clamp_float(targetPitch, -90, 90);

        rotationStartedAt = System.currentTimeMillis();
        rotationDuration = Math.max(1, duration);
        rotationActive = true;
    }

    private void applySmoothedRotation() {
        if (!rotationActive || mc.thePlayer == null) return;

        double progress = (double) (System.currentTimeMillis() - rotationStartedAt) / (double) rotationDuration;
        if (progress < 0) progress = 0;
        if (progress > 1) progress = 1;

        float desiredYaw = rotationStartYaw + wrapAngle(rotationTargetYaw - rotationStartYaw) * (float) progress;
        float desiredPitch = rotationStartPitch + (rotationTargetPitch - rotationStartPitch) * (float) progress;

        float quantizedYaw = quantizeFrom(rotationStartYaw, desiredYaw);
        float quantizedPitch = quantizeFrom(rotationStartPitch, desiredPitch);

        mc.thePlayer.rotationYaw = quantizedYaw;
        mc.thePlayer.rotationPitch = MathHelper.clamp_float(quantizedPitch, -90, 90);

        scriptedYaw = mc.thePlayer.rotationYaw;
        scriptedPitch = mc.thePlayer.rotationPitch;

        if (progress >= 1.0) rotationActive = false;
    }

    private float quantizeFrom(float origin, float value) {
        double steps = Math.round((value - origin) / SENSITIVITY_QUANTUM);
        return (float) (origin + steps * SENSITIVITY_QUANTUM);
    }

    // Speed-tuned anti-sway: tighter gains for higher velocity
    private float getAntiSwayCorrection(float forward, float recordedStrafe) {
        if (mc.thePlayer == null || !running) {
            antiSwayTapUsed = false;
            antiSwayYawOffset *= 0.65f;
            if (Math.abs(antiSwayYawOffset) < 0.03f) antiSwayYawOffset = 0;
            return recordedStrafe;
        }

        Vec3 pos = mc.thePlayer.getPositionVector();
        Vec3 motion = new Vec3(mc.thePlayer.motionX, mc.thePlayer.motionY, mc.thePlayer.motionZ);

        double lanePosition = travelX != 0 ? pos.zCoord : pos.xCoord;
        double laneVelocity = travelX != 0 ? motion.zCoord : motion.xCoord;
        double error = antiSwayLane - lanePosition;

        // Tighter deadband for speed telly
        if (Math.abs(error) < 0.010 && Math.abs(laneVelocity) < 0.005) {
            antiSwayTapUsed = false;
            antiSwayYawOffset *= 0.50f;
            if (Math.abs(antiSwayYawOffset) < 0.03f) antiSwayYawOffset = 0;
            return recordedStrafe;
        }

        // Higher P and D gains for speed telly
        double desiredLaneVelocity = error * 0.55 - laneVelocity * 0.85;
        if (desiredLaneVelocity > 0.16) desiredLaneVelocity = 0.16;
        if (desiredLaneVelocity < -0.16) desiredLaneVelocity = -0.16;
        double velocityCorrection = desiredLaneVelocity - laneVelocity;

        double radians = Math.toRadians(mc.thePlayer.rotationYaw);
        double sin = Math.sin(radians);
        double cos = Math.cos(radians);
        double yawLaneDerivative = travelX != 0
                ? -forward * sin + recordedStrafe * cos
                : -forward * cos - recordedStrafe * sin;

        double desiredYawOffset = 0;
        if (Math.abs(yawLaneDerivative) >= 0.12) {
            desiredYawOffset = Math.toDegrees(velocityCorrection * 0.55 / yawLaneDerivative);
        }
        // Tighter yaw clamp for speed telly
        if (desiredYawOffset > 1.5) desiredYawOffset = 1.5;
        if (desiredYawOffset < -1.5) desiredYawOffset = -1.5;
        antiSwayYawOffset = antiSwayYawOffset * 0.50f + (float) desiredYawOffset * 0.50f;

        double strafeLaneAxis = travelX != 0 ? sin : cos;
        boolean tapHelps = Math.abs(strafeLaneAxis) >= 0.20 && velocityCorrection * strafeLaneAxis > 0;
        if (tapHelps && !antiSwayTapUsed && Math.abs(velocityCorrection) >= 0.03 && recordedStrafe < 0.5f) {
            antiSwayTapUsed = true;
            return recordedStrafe + 1.0f;
        }

        return recordedStrafe;
    }

    private void handleAutoSwap() {
        if (mc.thePlayer == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        int heldCount = (held != null && held.getItem() instanceof ItemBlock) ? held.stackSize : 0;
        if (heldCount > 5) return;

        int bestSlot = -1;
        int bestSize = heldCount;
        for (int slot = 0; slot <= 8; slot++) {
            if (slot == mc.thePlayer.inventory.currentItem) continue;
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack == null || !(stack.getItem() instanceof ItemBlock)) continue;
            if (stack.stackSize > bestSize) {
                bestSize = stack.stackSize;
                bestSlot = slot;
            }
        }

        if (bestSlot != -1) {
            mc.thePlayer.inventory.currentItem = bestSlot;
        }
    }

    private boolean isHoldingBlock() {
        if (mc.thePlayer == null) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && held.getItem() instanceof ItemBlock;
    }

    // Check if player is at the back edge of a block (for forward travel activation)
    private boolean isAtBackEdge() {
        if (mc.thePlayer == null) return false;

        // Look in the opposite direction of player's facing to find the edge behind us
        double lookX = -Math.sin(Math.toRadians(mc.thePlayer.rotationYaw));
        double lookZ = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw));

        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 backward = new Vec3(lookX, -0.5, lookZ);

        Vec3 end = eyes.addVector(backward.xCoord * 3, backward.yCoord * 3, backward.zCoord * 3);
        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyes, end, false);
        if (mop == null) return false;

        BlockPos pos = mop.getBlockPos();
        return mc.theWorld.getBlockState(pos).getBlock() != Blocks.air;
    }

    private boolean isYawAligned(float yaw) {
        float nearestDiagonal = Math.round((yaw - 45.0f) / 90.0f) * 90.0f + 45.0f;
        return Math.abs(wrapAngle(yaw - nearestDiagonal)) <= 2.0f;
    }

    private void calculateTravelDirection(float yaw) {
        double radians = Math.toRadians(yaw);
        double rawX = Math.sin(radians) - Math.cos(radians);
        double rawZ = -Math.cos(radians) - Math.sin(radians);

        if (Math.abs(rawX) >= Math.abs(rawZ)) {
            travelX = rawX >= 0 ? 1 : -1;
            travelZ = 0;
        } else {
            travelX = 0;
            travelZ = rawZ >= 0 ? 1 : -1;
        }
    }

    private float wrapAngle(float angle) {
        while (angle <= -180.0f) angle += 360.0f;
        while (angle > 180.0f) angle -= 360.0f;
        return angle;
    }

    private int floor(double value) {
        int i = (int) value;
        return value < i ? i - 1 : i;
    }
}
