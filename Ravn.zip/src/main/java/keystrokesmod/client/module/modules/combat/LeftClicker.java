package keystrokesmod.client.module.modules.combat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Random;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.SoundUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class LeftClicker extends Module {
    public static DescriptionSetting bestWithDelayRemover;
    public static SliderSetting jitterLeft;
    public static TickSetting weaponOnly, sound, breakBlocks;
    public static DoubleSliderSetting leftCPS;
    public static TickSetting inventoryFill;

    public static ComboSetting clickStyle, clickTimings, soundMode;

    private long lastClick;
    private long leftHold;
    public static boolean autoClickerEnabled;
    private boolean leftDown;
    private long leftDownTime;
    private long leftUpTime;
    private long leftk;
    private long leftl;
    private double leftm;
    private boolean leftn;
    private boolean breakHeld;
    private Random rand;
    private Method playerMouseInput;
    public EntityLivingBase target;

    private long nextClickTime = 0;

    private int clicksInBurst = 0;
    private int burstLength = 0;
    private long burstPauseUntil = 0;
    private long lastBurstEnd = 0;
    private double prevClickCps = 0;
    private int jitterSkipCounter = 0;
    private float jitterCacheYaw = 0;
    private float jitterCachePitch = 0;
    private long lastJitterTime = 0;

    public LeftClicker() {
        super("Left Clicker", ModuleCategory.combat);

        this.registerSetting(bestWithDelayRemover = new DescriptionSetting("Best with delay remover."));
        this.registerSetting(leftCPS = new DoubleSliderSetting("Left CPS", 9, 13, 1, 60, 0.5));
        this.registerSetting(jitterLeft = new SliderSetting("Jitter left", 0.0D, 0.0D, 3.0D, 0.1D));
        this.registerSetting(inventoryFill = new TickSetting("Inventory fill", false));
        this.registerSetting(weaponOnly = new TickSetting("Weapon only", false));
        this.registerSetting(breakBlocks = new TickSetting("Break blocks", false));

        this.registerSetting(sound = new TickSetting("Play sound (may kill fps)", true));
        this.registerSetting(clickTimings = new ComboSetting("Click event", ClickEvent.Render));
        this.registerSetting(clickStyle = new ComboSetting("Click Style", ClickStyle.Raven));
        this.registerSetting(soundMode = new ComboSetting("Click sound", SoundMode.click));

        try {
            this.playerMouseInput = ReflectionHelper.findMethod(GuiScreen.class, null,
                    new String[] { "func_73864_a", "mouseClicked" }, Integer.TYPE, Integer.TYPE, Integer.TYPE);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (this.playerMouseInput != null)
            this.playerMouseInput.setAccessible(true);
        autoClickerEnabled = false;
    }

    @Override
    public void onEnable() {
        if (this.playerMouseInput == null)
            this.disable();

        this.rand = new Random();
        autoClickerEnabled = true;
        leftDownTime = 0L;
        leftUpTime = 0L;
        leftDown = false;
        nextClickTime = 0;
        clicksInBurst = 0;
        burstLength = 0;
        burstPauseUntil = 0;
        lastBurstEnd = 0;
        prevClickCps = 0;
        jitterSkipCounter = 0;
        lastJitterTime = 0;
    }

    @Override
    public void onDisable() {
        this.leftDownTime = 0L;
        this.leftUpTime = 0L;
        autoClickerEnabled = false;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof AttackEntityEvent)
            target = ((AttackEntityEvent) fe.getEvent()).entityLiving;
        else if (fe.getEvent() instanceof TickEvent.RenderTickEvent) {
            TickEvent.RenderTickEvent ev = (TickEvent.RenderTickEvent) fe.getEvent();

            if ((ev.phase == TickEvent.Phase.END) || (clickTimings.getMode() != ClickEvent.Render))
                return;

            if (!Utils.Client.currentScreenMinecraft()
                    && !(Minecraft.getMinecraft().currentScreen instanceof GuiInventory)
                    && !(Minecraft.getMinecraft().currentScreen instanceof GuiChest))
                return;

            if (clickStyle.getMode() == ClickStyle.Raven)
                ravenClick();
            else if (clickStyle.getMode() == ClickStyle.SKid)
                skidClick();
        }
    }

    @Subscribe
    public void onTick(keystrokesmod.client.event.impl.TickEvent e) {
        if ((clickTimings.getMode() != ClickEvent.Tick) || (!Utils.Client.currentScreenMinecraft() && !(Minecraft.getMinecraft().currentScreen instanceof GuiInventory)
                && !(Minecraft.getMinecraft().currentScreen instanceof GuiChest))
        )
            return;

        if (clickStyle.getMode() == ClickStyle.Raven)
            ravenClick();
        else if (clickStyle.getMode() == ClickStyle.SKid)
            skidClick();
    }

    private void skidClick() {
        if (!Utils.Player.isPlayerInGame())
            return;

        Mouse.poll();
        if ((mc.currentScreen != null) || !mc.inGameHasFocus) {
            doInventoryClick();
            return;
        }

        if (!Mouse.isButtonDown(0)) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            Utils.Client.setMouseButtonState(0, false);
            nextClickTime = 0;
            clicksInBurst = 0;
            burstLength = 0;
            return;
        }

        if (breakBlock() || (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon()))
            return;

        long now = System.currentTimeMillis();

        if (now < burstPauseUntil)
            return;

        if (burstLength == 0) {
            burstLength = 3 + rand.nextInt(8);
            clicksInBurst = 0;
        }

        if (clicksInBurst >= burstLength) {
            clicksInBurst = 0;
            burstLength = 0;
            burstPauseUntil = now + 40 + rand.nextInt(120);
            lastBurstEnd = now;
            return;
        }

        if (nextClickTime == 0) {
            nextClickTime = now + (long) getHumanDelay();
        }

        if (now >= nextClickTime) {
            lastClick = now;
            clicksInBurst++;
            nextClickTime = now + (long) getHumanDelay();

            applyHumanJitter();

            int key = mc.gameSettings.keyBindAttack.getKeyCode();
            KeyBinding.setKeyBindState(key, true);
            KeyBinding.onTick(key);
            Utils.Client.setMouseButtonState(0, true);

            if (sound.isToggled())
                SoundUtils.playSound(soundMode.getMode().name());
        }
    }

    private void ravenClick() {
        if ((mc.currentScreen != null) || !mc.inGameHasFocus) {
            doInventoryClick();
            return;
        }

        Mouse.poll();
        if (!Mouse.isButtonDown(0) && !leftDown) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            Utils.Client.setMouseButtonState(0, false);
            nextClickTime = 0;
            leftDownTime = 0L;
            leftUpTime = 0L;
            clicksInBurst = 0;
            burstLength = 0;
        }
        if (Mouse.isButtonDown(0) || leftDown) {
            if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
                return;
            this.leftClickExecute(mc.gameSettings.keyBindAttack.getKeyCode());
        }
    }

    public void leftClickExecute(int key) {
        if (breakBlock())
            return;

        long now = System.currentTimeMillis();

        if (now < burstPauseUntil)
            return;

        if (burstLength == 0) {
            burstLength = 4 + rand.nextInt(10);
            clicksInBurst = 0;
        }

        if (clicksInBurst >= burstLength) {
            clicksInBurst = 0;
            burstLength = 0;
            burstPauseUntil = now + 30 + rand.nextInt(150);
            lastBurstEnd = now;
            return;
        }

        applyHumanJitter();

        if ((this.leftUpTime > 0L) && (this.leftDownTime > 0L)) {
            if (now > this.leftUpTime && leftDown) {
                if (sound.isToggled())
                    SoundUtils.playSound(soundMode.getMode().name());
                KeyBinding.setKeyBindState(key, true);
                KeyBinding.onTick(key);
                this.genHumanTimings();
                Utils.Client.setMouseButtonState(0, true);
                leftDown = false;
                clicksInBurst++;
            } else if (now > this.leftDownTime) {
                KeyBinding.setKeyBindState(key, false);
                leftDown = true;
                Utils.Client.setMouseButtonState(0, false);
            }
        } else
            this.genHumanTimings();
    }

    public void genHumanTimings() {
        double cps = getNextCPS();
        long delay = (long) Math.round(1000.0D / cps);
        if (delay < 16) delay = 16;

        double downRatio = 0.35 + rand.nextDouble() * 0.3;

        this.leftDownTime = System.currentTimeMillis() + (long)(delay * downRatio);
        this.leftUpTime = System.currentTimeMillis() + delay;
    }

    private double getHumanDelay() {
        double baseCps = getNextCPS();
        double delay = 1000.0 / baseCps;

        if (rand.nextDouble() < 0.08) {
            delay += 20 + rand.nextDouble() * 60;
        }

        if (rand.nextDouble() < 0.03) {
            delay += 80 + rand.nextDouble() * 120;
        }

        delay += rand.nextGaussian() * 3.0;

        return Math.max(16, delay);
    }

    private double getNextCPS() {
        double min = leftCPS.getInputMin();
        double max = leftCPS.getInputMax();
        double base;

        if (rand.nextDouble() < 0.15) {
            base = min + rand.nextDouble() * (max - min) * 0.3;
        } else if (rand.nextDouble() < 0.1) {
            base = max - rand.nextDouble() * (max - min) * 0.3;
        } else {
            base = min + rand.nextDouble() * (max - min);
        }

        if (prevClickCps > 0) {
            double maxDelta = (max - min) * 0.3;
            double delta = base - prevClickCps;
            if (Math.abs(delta) > maxDelta) {
                base = prevClickCps + Math.signum(delta) * maxDelta;
            }
        }

        prevClickCps = base;
        return Math.max(1.0, Math.min(60.0, base));
    }

    private void applyHumanJitter() {
        if (jitterLeft.getInput() <= 0.0D) return;

        long now = System.currentTimeMillis();

        if (now - lastJitterTime < 30) {
            mc.thePlayer.rotationYaw += jitterCacheYaw;
            mc.thePlayer.rotationPitch += jitterCachePitch;
            return;
        }

        jitterSkipCounter++;
        if (jitterSkipCounter % (2 + rand.nextInt(3)) != 0) {
            return;
        }

        double a = jitterLeft.getInput() * 0.45D;
        double yawDelta = (rand.nextDouble() - 0.5) * a * 0.9;
        double pitchDelta = (rand.nextDouble() - 0.5) * a * 0.4;

        yawDelta += rand.nextGaussian() * a * 0.08;
        pitchDelta += rand.nextGaussian() * a * 0.05;

        mc.thePlayer.rotationYaw = (float) ((double) mc.thePlayer.rotationYaw + yawDelta);
        mc.thePlayer.rotationPitch = (float) ((double) mc.thePlayer.rotationPitch + pitchDelta);

        jitterCacheYaw = (float) yawDelta;
        jitterCachePitch = (float) pitchDelta;
        lastJitterTime = now;
    }

    private void inInvClick(GuiScreen guiScreen) {
        int mouseInGUIPosX = (Mouse.getX() * guiScreen.width) / mc.displayWidth;
        int mouseInGUIPosY = guiScreen.height - ((Mouse.getY() * guiScreen.height) / mc.displayHeight) - 1;

        try {
            this.playerMouseInput.invoke(guiScreen, mouseInGUIPosX, mouseInGUIPosY, 0);
        } catch (IllegalAccessException | InvocationTargetException ignored) {
        }
    }

    public boolean breakBlock() {
        if (breakBlocks.isToggled() && (mc.objectMouseOver != null)) {
            BlockPos p = mc.objectMouseOver.getBlockPos();

            if (p != null) {
                Block bl = mc.theWorld.getBlockState(p).getBlock();
                if ((bl != Blocks.air) && !(bl instanceof BlockLiquid)) {
                    if (!breakHeld) {
                        int e = mc.gameSettings.keyBindAttack.getKeyCode();
                        KeyBinding.setKeyBindState(e, true);
                        KeyBinding.onTick(e);
                        breakHeld = true;
                    }
                    return true;
                }
                if (breakHeld)
                    breakHeld = false;
            }
        }
        return false;
    }

    public void doInventoryClick() {
        if (inventoryFill.isToggled()
                && ((mc.currentScreen instanceof GuiInventory) || (mc.currentScreen instanceof GuiChest)))
            if (!Mouse.isButtonDown(0) || (!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42))) {
                this.leftDownTime = 0L;
                this.leftUpTime = 0L;
            } else if ((this.leftDownTime != 0L) && (this.leftUpTime != 0L)) {
                if (System.currentTimeMillis() > this.leftUpTime) {
                    this.genHumanTimings();
                    this.inInvClick(mc.currentScreen);
                }
            } else
                this.genHumanTimings();
    }

    public enum ClickStyle {
        Raven, SKid
    }

    public enum ClickEvent {
        Tick, Render
    }

    public enum SoundMode {
        click, g3032, g502, gpro, hp, microsoft, oldmouse,
    }
}
