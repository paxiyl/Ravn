package keystrokesmod.client.module.modules.combat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.SoundUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class LeftClicker extends Module {
    public static DescriptionSetting bestWithDelayRemover;
    public static SliderSetting jitterLeft, hitSelectTick;
    public static TickSetting weaponOnly, sound, breakBlocks;
    public static DoubleSliderSetting leftCPS;
    public static TickSetting inventoryFill, hitSelect;

    public static ComboSetting clickStyle, clickTimings, soundMode;

    private long lastClick;
    private long leftHold;
    public static boolean autoClickerEnabled;
    private boolean leftDown;
    private long leftDownTime;
    private long leftUpTime;
    private long leftk;
    private long leftl;
    private double leftm;
    private boolean leftn;
    private boolean breakHeld;
    private boolean hitSelected;
    private Random rand;
    private Method playerMouseInput;
    public EntityLivingBase target;

    private int clickBurstCount = 0;
    private long burstStartTime = 0;
    private boolean inBurst = false;
    private int totalClicks = 0;
    private long sessionStart = 0;
    private double fatigue = 0;
    private long lastPauseTime = 0;
    private boolean inMicroPause = false;

    public LeftClicker() {
        super("Left Clicker", ModuleCategory.combat);

        this.registerSetting(bestWithDelayRemover = new DescriptionSetting("Best with delay remover."));
        this.registerSetting(leftCPS = new DoubleSliderSetting("Left CPS", 9, 13, 1, 60, 0.5));
        this.registerSetting(jitterLeft = new SliderSetting("Jitter left", 0.0D, 0.0D, 3.0D, 0.1D));
        this.registerSetting(inventoryFill = new TickSetting("Inventory fill", false));
        this.registerSetting(weaponOnly = new TickSetting("Weapon only", false));
        this.registerSetting(breakBlocks = new TickSetting("Break blocks", false));
        this.registerSetting(hitSelect = new TickSetting("Hit Select", false));
        this.registerSetting(hitSelectTick = new SliderSetting("HitSelect Hurttick", 7, 1, 10, 1));

        this.registerSetting(sound = new TickSetting("Play sound (may kill fps)", true));
        this.registerSetting(clickTimings = new ComboSetting("Click event", ClickEvent.Render));
        this.registerSetting(clickStyle = new ComboSetting("Click Style", ClickStyle.Raven));
        this.registerSetting(soundMode = new ComboSetting("Click sound", SoundMode.click));

        try {
            this.playerMouseInput = ReflectionHelper.findMethod(GuiScreen.class, null,
                    new String[] { "func_73864_a", "mouseClicked" }, Integer.TYPE, Integer.TYPE, Integer.TYPE);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (this.playerMouseInput != null)
			this.playerMouseInput.setAccessible(true);
        autoClickerEnabled = false;
    }

    @Override
    public void onEnable() {
        if (this.playerMouseInput == null)
			this.disable();

        this.rand = new Random();
        autoClickerEnabled = true;
        clickBurstCount = 0;
        burstStartTime = 0;
        inBurst = false;
        totalClicks = 0;
        sessionStart = System.currentTimeMillis();
        fatigue = 0;
        lastPauseTime = 0;
        inMicroPause = false;
    }

    @Override
    public void onDisable() {
        this.leftDownTime = 0L;
        this.leftUpTime = 0L;
        autoClickerEnabled = false;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof AttackEntityEvent)
			target = ((AttackEntityEvent) fe.getEvent()).entityLiving;
		else if (fe.getEvent() instanceof TickEvent.RenderTickEvent) {
            TickEvent.RenderTickEvent ev = (TickEvent.RenderTickEvent) fe.getEvent();

            if ((ev.phase == TickEvent.Phase.END) || (clickTimings.getMode() != ClickEvent.Render))
                return;

            if ((!Utils.Client.currentScreenMinecraft()
                    && !(Minecraft.getMinecraft().currentScreen instanceof GuiInventory)
                    && !(Minecraft.getMinecraft().currentScreen instanceof GuiChest)
) || shouldNotClick())
				return;

            if (clickStyle.getMode() == ClickStyle.Raven)
				ravenClick();
			else if (clickStyle.getMode() == ClickStyle.SKid)
				skidClick();
        }
    }

    private boolean shouldNotClick() {
        if (!Mouse.isButtonDown(0))
			hitSelected = false;

        if (hitSelect.isToggled())
			if (hitSelected || ((mc.thePlayer.hurtTime != 0) && (mc.thePlayer.hurtTime > hitSelectTick.getInput())))
				hitSelected = true;
			else
				return true;
        return false;
    }

    @Subscribe
    public void onTick(keystrokesmod.client.event.impl.TickEvent e) {
        if ((clickTimings.getMode() != ClickEvent.Tick) || (!Utils.Client.currentScreenMinecraft() && !(Minecraft.getMinecraft().currentScreen instanceof GuiInventory)
                && !(Minecraft.getMinecraft().currentScreen instanceof GuiChest)
)
        )
            return;

        if (shouldNotClick())
			return;

        if (clickStyle.getMode() == ClickStyle.Raven)
			ravenClick();
		else if (clickStyle.getMode() == ClickStyle.SKid)
			skidClick();
    }

    private void skidClick() {
        if (!Utils.Player.isPlayerInGame())
            return;

        Mouse.poll();
        if ((mc.currentScreen != null) || !mc.inGameHasFocus) {
            doInventoryClick();
            return;
        }

        if (Mouse.isButtonDown(0)) {
            if (breakBlock() || (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon()))
				return;
            applyJitter();

            double speedLeft = getHumanizedDelay();
            long now = System.currentTimeMillis();
            if ((now - lastClick) > (speedLeft * 1000)) {
                lastClick = now;
                totalClicks++;
                updateFatigue();

                if (leftHold < lastClick)
					leftHold = lastClick;
                int key = mc.gameSettings.keyBindAttack.getKeyCode();
                KeyBinding.setKeyBindState(key, true);
                KeyBinding.onTick(key);
                Utils.Client.setMouseButtonState(0, true);
            } else if ((now - leftHold) > (getHumanizedHoldLength() * 1000)) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
                Utils.Client.setMouseButtonState(0, false);
            }
        }
    }

    private void ravenClick() {
        if ((mc.currentScreen != null) || !mc.inGameHasFocus) {
            doInventoryClick();
            return;
        }

        Mouse.poll();
        if (!Mouse.isButtonDown(0) && !leftDown) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            Utils.Client.setMouseButtonState(0, false);
            clickBurstCount = 0;
            inBurst = false;
        }
        if (Mouse.isButtonDown(0) || leftDown) {
            if (weaponOnly.isToggled() && !Utils.Player.isPlayerHoldingWeapon())
				return;
            this.leftClickExecute(mc.gameSettings.keyBindAttack.getKeyCode());
        }
    }

    public void leftClickExecute(int key) {
        if (breakBlock())
            return;

        applyJitter();

        if ((this.leftUpTime > 0L) && (this.leftDownTime > 0L)) {
            long now = System.currentTimeMillis();
            if (now > this.leftUpTime && leftDown) {
                if (sound.isToggled())
					SoundUtils.playSound(soundMode.getMode().name());
                KeyBinding.setKeyBindState(key, true);
                KeyBinding.onTick(key);
                this.genLeftTimings();
                Utils.Client.setMouseButtonState(0, true);
                leftDown = false;
                totalClicks++;
                updateFatigue();
            } else if (now > this.leftDownTime) {
                KeyBinding.setKeyBindState(key, false);
                leftDown = true;
                Utils.Client.setMouseButtonState(0, false);
            }
        } else
			this.genLeftTimings();
    }

    public void genLeftTimings() {
        double baseCPS = Utils.Client.ranModuleVal(leftCPS, this.rand);
        double humanizedCPS = applyHumanization(baseCPS);
        long delay = (long) Math.round(1000.0D / humanizedCPS);

        if (shouldMicroPause()) {
            delay += 80 + rand.nextInt(200);
            inMicroPause = true;
            lastPauseTime = System.currentTimeMillis();
        } else {
            inMicroPause = false;
        }

        if (rand.nextInt(100) < 3) {
            delay += 150 + rand.nextInt(400);
        }

        this.leftUpTime = System.currentTimeMillis() + delay;
        this.leftDownTime = (System.currentTimeMillis() + (delay / 2L)) - (long) this.rand.nextInt(Math.max(1, (int)(delay * 0.3)));
    }

    private double applyHumanization(double baseCPS) {
        double result = baseCPS;

        result += (rand.nextGaussian() * 0.8);

        if (inBurst) {
            result *= 1.15;
            if (System.currentTimeMillis() - burstStartTime > 800 + rand.nextInt(1200)) {
                inBurst = false;
                clickBurstCount = 0;
            }
        } else {
            if (rand.nextInt(100) < 8) {
                inBurst = true;
                burstStartTime = System.currentTimeMillis();
                clickBurstCount = 0;
            }
            result *= 0.92;
        }

        result *= (1.0 - fatigue * 0.15);

        double swingMod = 1.0 + Math.sin(System.currentTimeMillis() * 0.001) * 0.04;
        result *= swingMod;

        return Math.max(1.0, Math.min(60.0, result));
    }

    private double getHumanizedDelay() {
        double baseCPS = Utils.Client.ranModuleVal(leftCPS, this.rand);
        return 1.0 / applyHumanization(baseCPS);
    }

    private double getHumanizedHoldLength() {
        double baseCPS = Utils.Client.ranModuleVal(leftCPS, this.rand);
        double holdRatio = 0.35 + rand.nextDouble() * 0.25;
        return holdRatio / applyHumanization(baseCPS);
    }

    private boolean shouldMicroPause() {
        if (inMicroPause) return false;
        long elapsed = System.currentTimeMillis() - sessionStart;
        if (elapsed < 5000) return false;
        return rand.nextInt(100) < 2;
    }

    private void updateFatigue() {
        fatigue = Math.min(1.0, fatigue + 0.0001);
        if (totalClicks % 200 == 0 && totalClicks > 0) {
            fatigue *= 0.8;
        }
    }

    private void applyJitter() {
        if (jitterLeft.getInput() <= 0.0D) return;

        double a = jitterLeft.getInput() * 0.45D;
        EntityPlayerSP entityPlayer = mc.thePlayer;

        double yawJitter = rand.nextGaussian() * a * 0.6;
        double pitchJitter = rand.nextGaussian() * a * 0.25;

        entityPlayer.rotationYaw = (float) ((double) entityPlayer.rotationYaw + yawJitter);
        entityPlayer.rotationPitch = (float) ((double) entityPlayer.rotationPitch + pitchJitter);
    }

    private void inInvClick(GuiScreen guiScreen) {
        int mouseInGUIPosX = (Mouse.getX() * guiScreen.width) / mc.displayWidth;
        int mouseInGUIPosY = guiScreen.height - ((Mouse.getY() * guiScreen.height) / mc.displayHeight) - 1;

        try {
            this.playerMouseInput.invoke(guiScreen, mouseInGUIPosX, mouseInGUIPosY, 0);
        } catch (IllegalAccessException | InvocationTargetException ignored) {
        }
    }

    public boolean breakBlock() {
        if (breakBlocks.isToggled() && (mc.objectMouseOver != null)) {
            BlockPos p = mc.objectMouseOver.getBlockPos();

            if (p != null) {
                Block bl = mc.theWorld.getBlockState(p).getBlock();
                if ((bl != Blocks.air) && !(bl instanceof BlockLiquid)) {
                    if (!breakHeld) {
                        int e = mc.gameSettings.keyBindAttack.getKeyCode();
                        KeyBinding.setKeyBindState(e, true);
                        KeyBinding.onTick(e);
                        breakHeld = true;
                    }
                    return true;
                }
                if (breakHeld)
					breakHeld = false;
            }
        }
        return false;
    }

    public void doInventoryClick() {
        if (inventoryFill.isToggled()
                && ((mc.currentScreen instanceof GuiInventory) || (mc.currentScreen instanceof GuiChest)))
			if (!Mouse.isButtonDown(0) || (!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42))) {
                this.leftDownTime = 0L;
                this.leftUpTime = 0L;
            } else if ((this.leftDownTime != 0L) && (this.leftUpTime != 0L)) {
                if (System.currentTimeMillis() > this.leftUpTime) {
                    this.genLeftTimings();
                    this.inInvClick(mc.currentScreen);
                }
            } else
				this.genLeftTimings();
    }

    public enum ClickStyle {
        Raven, SKid
    }

    public enum ClickEvent {
        Tick, Render
    }

    public enum SoundMode {
    	click,
    	g3032,
    	g502,
    	gpro,
    	hp,
    	microsoft,
    	oldmouse,
    }
}
