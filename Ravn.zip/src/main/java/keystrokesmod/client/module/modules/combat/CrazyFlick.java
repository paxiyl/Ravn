package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class CrazyFlick extends Module {

    public static SliderSetting flickSpeed;
    public static SliderSetting flickIntensity;
    public static SliderSetting pitchRange;
    public static SliderSetting flickDuration;
    public static SliderSetting settleTime;
    public static SliderSetting aimSpeed;
    public static TickSetting spin360;
    public static TickSetting verticalFlick;
    public static TickSetting randomJitter;
    public static SliderSetting targetRange;

    private final Random rand = new Random();

    private int state = 0;
    private long stateStartTime = 0;
    private long stateDuration = 0;

    private float flickTargetYaw = 0;
    private float flickTargetPitch = 0;
    private float flickStartYaw = 0;
    private float flickStartPitch = 0;

    private float settleYaw = 0;
    private float settlePitch = 0;

    private float prevAppliedYaw = 0;
    private float prevAppliedPitch = 0;
    private boolean hasPrev = false;

    private float jitterOffsetYaw = 0;
    private float jitterOffsetPitch = 0;
    private int jitterCounter = 0;

    private float accumulatedYaw = 0;
    private float accumulatedPitch = 0;

    private EntityPlayer closestTarget = null;

    private static final int STATE_IDLE = 0;
    private static final int STATE_FLICKING = 1;
    private static final int STATE_SETTLING = 2;

    public CrazyFlick() {
        super("CrazyFlick", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Random flick movements while fighting"));
        this.registerSetting(flickSpeed = new SliderSetting("Flick speed", 8.0D, 2.0D, 20.0D, 0.5D));
        this.registerSetting(flickIntensity = new SliderSetting("Flick intensity", 180.0D, 30.0D, 720.0D, 10.0D));
        this.registerSetting(pitchRange = new SliderSetting("Pitch range", 60.0D, 10.0D, 90.0D, 5.0D));
        this.registerSetting(flickDuration = new SliderSetting("Flick duration (ms)", 300.0D, 50.0D, 800.0D, 10.0D));
        this.registerSetting(settleTime = new SliderSetting("Settle time (ms)", 200.0D, 50.0D, 500.0D, 10.0D));
        this.registerSetting(aimSpeed = new SliderSetting("Aim speed", 10.0D, 3.0D, 20.0D, 0.5D));
        this.registerSetting(targetRange = new SliderSetting("Target range", 4.0D, 2.0D, 6.0D, 0.5D));
        this.registerSetting(spin360 = new TickSetting("360 spins", true));
        this.registerSetting(verticalFlick = new TickSetting("Vertical flick", true));
        this.registerSetting(randomJitter = new TickSetting("Random jitter", true));
    }

    @Override
    public void onEnable() {
        state = STATE_IDLE;
        hasPrev = false;
        accumulatedYaw = 0;
        accumulatedPitch = 0;
        jitterOffsetYaw = 0;
        jitterOffsetPitch = 0;
        jitterCounter = 0;
    }

    @Override
    public void onDisable() {
        hasPrev = false;
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) return;

        closestTarget = findClosestTarget();
        if (closestTarget == null) {
            state = STATE_IDLE;
            hasPrev = false;
            return;
        }

        float[] targetAngles = getAnglesToEntity(closestTarget);
        float targetYaw = targetAngles[0];
        float targetPitch = targetAngles[1];

        long now = System.currentTimeMillis();

        switch (state) {
            case STATE_IDLE:
                startFlick(targetYaw, targetPitch, now);
                break;

            case STATE_FLICKING:
                if (now - stateStartTime >= stateDuration) {
                    startSettle(targetYaw, targetPitch, now);
                }
                break;

            case STATE_SETTLING:
                if (now - stateStartTime >= stateDuration) {
                    startFlick(targetYaw, targetPitch, now);
                }
                break;
        }

        float[] result = computeRotation(targetYaw, targetPitch, now);

        float finalYaw = result[0];
        float finalPitch = MathHelper.clamp_float(result[1], -90.0F, 90.0F);

        if (randomJitter.isToggled()) {
            jitterCounter++;
            if (jitterCounter >= 2 + rand.nextInt(3)) {
                jitterCounter = 0;
                jitterOffsetYaw = (float) ((rand.nextGaussian() * 0.6));
                jitterOffsetPitch = (float) ((rand.nextGaussian() * 0.4));
            }
            finalYaw += jitterOffsetYaw;
            finalPitch += jitterOffsetPitch;
            finalPitch = MathHelper.clamp_float(finalPitch, -90.0F, 90.0F);
        }

        e.setYaw(finalYaw);
        e.setPitch(finalPitch);

        mc.thePlayer.rotationYaw = finalYaw;
        mc.thePlayer.rotationPitch = finalPitch;
        mc.thePlayer.renderYawOffset = finalYaw;
        mc.thePlayer.rotationYawHead = finalYaw;

        prevAppliedYaw = finalYaw;
        prevAppliedPitch = finalPitch;
        hasPrev = true;
    }

    private void startFlick(float targetYaw, float targetPitch, long now) {
        state = STATE_FLICKING;
        stateStartTime = now;
        stateDuration = (long) (flickDuration.getInput() + rand.nextDouble() * flickDuration.getInput() * 0.4);

        flickStartYaw = mc.thePlayer.rotationYaw;
        flickStartPitch = mc.thePlayer.rotationPitch;

        double intensity = flickIntensity.getInput();
        double yawChange = (rand.nextDouble() - 0.5) * 2.0 * intensity;

        if (spin360.isToggled() && rand.nextInt(3) == 0) {
            double sign = rand.nextBoolean() ? 1.0 : -1.0;
            yawChange = sign * (180.0 + rand.nextDouble() * 540.0);
        }

        flickTargetYaw = flickStartYaw + (float) yawChange;

        if (verticalFlick.isToggled()) {
            double pitchSwing = (rand.nextDouble() - 0.5) * 2.0 * pitchRange.getInput();
            flickTargetPitch = MathHelper.clamp_float(flickStartPitch + (float) pitchSwing, -90.0F, 90.0F);
        } else {
            flickTargetPitch = flickStartPitch + (float) ((rand.nextDouble() - 0.5) * 20.0);
            flickTargetPitch = MathHelper.clamp_float(flickTargetPitch, -90.0F, 90.0F);
        }

        accumulatedYaw = flickStartYaw;
        accumulatedPitch = flickStartPitch;
    }

    private void startSettle(float targetYaw, float targetPitch, long now) {
        state = STATE_SETTLING;
        stateStartTime = now;
        stateDuration = (long) (settleTime.getInput() + rand.nextDouble() * settleTime.getInput() * 0.3);

        settleYaw = targetYaw;
        settlePitch = targetPitch;

        flickStartYaw = mc.thePlayer.rotationYaw;
        flickStartPitch = mc.thePlayer.rotationPitch;
    }

    private float[] computeRotation(float targetYaw, float targetPitch, long now) {
        float curYaw = hasPrev ? prevAppliedYaw : mc.thePlayer.rotationYaw;
        float curPitch = hasPrev ? prevAppliedPitch : mc.thePlayer.rotationPitch;

        switch (state) {
            case STATE_FLICKING:
                return computeFlickRotation(curYaw, curPitch, now);

            case STATE_SETTLING:
                return computeSettleRotation(curYaw, curPitch, targetYaw, targetPitch, now);

            default:
                return computeIdleRotation(curYaw, curPitch, targetYaw, targetPitch);
        }
    }

    private float[] computeFlickRotation(float curYaw, float curPitch, long now) {
        float progress = (float) (now - stateStartTime) / (float) stateDuration;
        progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

        float eased = easeInOutCubic(progress);

        float desiredYaw = flickStartYaw + wrapDelta(flickTargetYaw - flickStartYaw) * eased;
        float desiredPitch = flickStartPitch + (flickTargetPitch - flickStartPitch) * eased;

        float speed = (float) flickSpeed.getInput();
        float dYaw = wrapDelta(desiredYaw - curYaw);
        float dPitch = desiredPitch - curPitch;

        float maxStep = speed * 3.0F;
        dYaw = MathHelper.clamp_float(dYaw, -maxStep, maxStep);
        dPitch = MathHelper.clamp_float(dPitch, -maxStep * 0.7F, maxStep * 0.7F);

        float newYaw = curYaw + dYaw;
        float newPitch = MathHelper.clamp_float(curPitch + dPitch, -90.0F, 90.0F);

        return new float[]{newYaw, newPitch};
    }

    private float[] computeSettleRotation(float curYaw, float curPitch, float targetYaw, float targetPitch, long now) {
        float progress = (float) (now - stateStartTime) / (float) stateDuration;
        progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

        float speed = (float) aimSpeed.getInput();
        float dYaw = wrapDelta(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        float closeness = 1.0F - progress;
        float maxStep = speed * (0.5F + closeness * 0.5F) * 2.0F;
        dYaw = MathHelper.clamp_float(dYaw, -maxStep, maxStep);
        dPitch = MathHelper.clamp_float(dPitch, -maxStep * 0.7F, maxStep * 0.7F);

        float newYaw = curYaw + dYaw;
        float newPitch = MathHelper.clamp_float(curPitch + dPitch, -90.0F, 90.0F);

        return new float[]{newYaw, newPitch};
    }

    private float[] computeIdleRotation(float curYaw, float curPitch, float targetYaw, float targetPitch) {
        float speed = (float) aimSpeed.getInput() * 1.5F;
        float dYaw = wrapDelta(targetYaw - curYaw);
        float dPitch = targetPitch - curPitch;

        float maxStep = speed * 2.0F;
        dYaw = MathHelper.clamp_float(dYaw, -maxStep, maxStep);
        dPitch = MathHelper.clamp_float(dPitch, -maxStep * 0.7F, maxStep * 0.7F);

        float newYaw = curYaw + dYaw;
        float newPitch = MathHelper.clamp_float(curPitch + dPitch, -90.0F, 90.0F);

        return new float[]{newYaw, newPitch};
    }

    private float easeInOutCubic(float t) {
        return t < 0.5F ? 4.0F * t * t * t : 1.0F - (float) Math.pow(-2.0 * t + 2.0, 3) / 2.0F;
    }

    private float wrapDelta(float delta) {
        while (delta > 180.0F) delta -= 360.0F;
        while (delta < -180.0F) delta += 360.0F;
        return delta;
    }

    private float[] getAnglesToEntity(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dy = (entity.posY + entity.getEyeHeight()) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = entity.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = MathHelper.clamp_float(pitch, -90.0F, 90.0F);
        return new float[]{yaw, pitch};
    }

    private EntityPlayer findClosestTarget() {
        if (mc.theWorld == null || mc.thePlayer == null) return null;

        List<EntityPlayer> players = new ArrayList<>();
        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (entity instanceof EntityPlayer && entity != mc.thePlayer) {
                double dist = mc.thePlayer.getDistanceToEntity(entity);
                if (dist <= targetRange.getInput()) {
                    players.add((EntityPlayer) entity);
                }
            }
        }

        if (players.isEmpty()) return null;

        players.sort(Comparator.comparingDouble(mc.thePlayer::getDistanceToEntity));
        return players.get(0);
    }
}
