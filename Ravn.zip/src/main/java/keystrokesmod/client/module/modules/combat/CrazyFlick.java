package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

import java.util.Random;

public class CrazyFlick extends Module {

    public static SliderSetting hitsRequired;
    public static SliderSetting flickStrength;
    public static SliderSetting targetRange;
    public static TickSetting spin360;
    public static TickSetting verticalFlick;

    private final Random rand = new Random();

    private int flickPhase = 0;
    private long phaseStartTime = 0;
    private long phaseDuration = 0;

    private float flickStartYaw, flickStartPitch;
    private float flickEndYaw, flickEndPitch;
    private float targetYaw, targetPitch;

    private float prevYaw = 0, prevPitch = 0;
    private boolean hasPrev = false;

    private float jitterY = 0, jitterP = 0;
    private int jitterTick = 0;
    private int jitterInterval = 3;

    private int comboTargetId = -1;
    private int comboCount = 0;
    private boolean flickUnlocked = false;

    private long lastAttackTime = 0;
    private boolean holdingReset = false;

    private boolean suppressedComboAim = false;
    private boolean savedComboAimState = false;

    private float flickWobble = 0;
    private float flickWobbleSpeed = 0;
    private float flickWobbleOffset = 0;

    private static final int PHASE_OFF = 0;
    private static final int PHASE_AWAY = 1;
    private static final int PHASE_BACK = 2;

    public CrazyFlick() {
        super("CrazyFlick", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Crazy flicks between clicks in combos"));
        this.registerSetting(hitsRequired = new SliderSetting("Hits to activate", 2.0D, 1.0D, 5.0D, 1.0D));
        this.registerSetting(flickStrength = new SliderSetting("Flick strength", 3.0D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(targetRange = new SliderSetting("Target range", 4.0D, 2.0D, 6.0D, 0.5D));
        this.registerSetting(spin360 = new TickSetting("360 spins", false));
        this.registerSetting(verticalFlick = new TickSetting("Vertical flick", true));
    }

    @Override
    public void onEnable() {
        resetAll();
    }

    @Override
    public void onDisable() {
        resetAll();
        restoreComboAim();
    }

    private void resetAll() {
        flickPhase = PHASE_OFF;
        comboCount = 0;
        comboTargetId = -1;
        flickUnlocked = false;
        hasPrev = false;
        lastAttackTime = 0;
        holdingReset = false;
    }

    private float getIntensity() {
        float s = (float) flickStrength.getInput();
        return s * 55.0F + rand.nextFloat() * s * 15.0F;
    }

    private float getSpeed() {
        return (float) flickStrength.getInput() * 8.0F;
    }

    private long getAwayMs() {
        float s = (float) flickStrength.getInput();
        return (long) (55.0 + s * 32.0 + rand.nextDouble() * s * 12.0);
    }

    private long getBackMs() {
        float s = (float) flickStrength.getInput();
        return (long) (35.0 + s * 16.0 + rand.nextDouble() * s * 8.0);
    }

    private float getCurrentYaw() {
        return hasPrev ? prevYaw : mc.thePlayer.rotationYaw;
    }

    private float getCurrentPitch() {
        return hasPrev ? prevPitch : mc.thePlayer.rotationPitch;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof AttackEntityEvent)) return;
        AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
        if (event.entityPlayer != mc.thePlayer) return;
        if (!(event.target instanceof EntityPlayer)) return;

        EntityPlayer hit = (EntityPlayer) event.target;
        long now = System.currentTimeMillis();
        int hitId = hit.getEntityId();
        long gap = now - lastAttackTime;
        lastAttackTime = now;

        if (gap < 50) {
            holdingReset = true;
            comboCount = 0;
            comboTargetId = -1;
            flickUnlocked = false;
            flickPhase = PHASE_OFF;
            hasPrev = false;
            restoreComboAim();
            return;
        }

        holdingReset = false;

        if (comboTargetId == hitId) {
            comboCount++;
        } else {
            comboTargetId = hitId;
            comboCount = 1;
        }

        if (comboCount >= (int) hitsRequired.getInput()) {
            flickUnlocked = true;
        }

        if (!flickUnlocked) return;

        float[] angles = getAnglesToEntity(hit);
        targetYaw = angles[0];
        targetPitch = angles[1];

        if (flickPhase == PHASE_OFF || flickPhase == PHASE_BACK) {
            startFlickAway(now);
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (holdingReset) return;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            if (flickPhase != PHASE_OFF) {
                flickPhase = PHASE_OFF;
                hasPrev = false;
                restoreComboAim();
            }
            return;
        }

        if (mc.thePlayer.hurtTime > 0) {
            resetAll();
            restoreComboAim();
            return;
        }

        if (!flickUnlocked) return;

        long now = System.currentTimeMillis();

        if (lastAttackTime > 0 && (now - lastAttackTime) > 500) {
            resetAll();
            restoreComboAim();
            return;
        }

        EntityPlayer target = findTargetById(comboTargetId);
        if (target == null || target.isDead || !target.isEntityAlive()) {
            resetAll();
            restoreComboAim();
            return;
        }

        if (mc.thePlayer.getDistanceToEntity(target) > targetRange.getInput() + 2.0F) {
            resetAll();
            restoreComboAim();
            return;
        }

        float[] targetAngles = getAnglesToEntity(target);
        targetYaw = targetAngles[0];
        targetPitch = targetAngles[1];

        switch (flickPhase) {
            case PHASE_AWAY:
                if (now - phaseStartTime >= phaseDuration) {
                    startSettleBack(now);
                }
                break;
            case PHASE_BACK:
                float dY = Math.abs(wrapDelta(targetYaw - getCurrentYaw()));
                float dP = Math.abs(targetPitch - getCurrentPitch());
                if (dY < 1.5F && dP < 1.5F) {
                    flickPhase = PHASE_OFF;
                    hasPrev = false;
                }
                break;
        }

        if (flickPhase == PHASE_OFF) return;

        float[] result = computeRotation(now);
        float fy = result[0];
        float fp = MathHelper.clamp_float(result[1], -90.0F, 90.0F);

        if (flickPhase == PHASE_AWAY) {
            jitterTick++;
            if (jitterTick >= jitterInterval) {
                jitterTick = 0;
                jitterInterval = 1 + rand.nextInt(3);
                jitterY = (float) (rand.nextGaussian() * (0.6 + rand.nextDouble() * 1.2));
                jitterP = (float) (rand.nextGaussian() * (0.4 + rand.nextDouble() * 0.8));
            }
            fy += jitterY;
            fp += jitterP;

            flickWobbleOffset += flickWobbleSpeed;
            flickWobbleSpeed += (rand.nextFloat() - 0.5F) * 0.4F;
            flickWobbleSpeed *= 0.92F;
            fy += (float) Math.sin(flickWobbleOffset) * flickWobble * 0.3F;
            fp += (float) Math.cos(flickWobbleOffset * 0.7F) * flickWobble * 0.15F;

            fp = MathHelper.clamp_float(fp, -90.0F, 90.0F);
        }

        e.setYaw(fy);
        e.setPitch(fp);
        mc.thePlayer.rotationYaw = fy;
        mc.thePlayer.rotationPitch = fp;
        mc.thePlayer.renderYawOffset = fy;
        mc.thePlayer.rotationYawHead = fy;

        prevYaw = fy;
        prevPitch = fp;
        hasPrev = true;
    }

    private void startFlickAway(long now) {
        flickPhase = PHASE_AWAY;
        phaseStartTime = now;
        phaseDuration = getAwayMs();

        suppressComboAim();

        flickStartYaw = getCurrentYaw();
        flickStartPitch = getCurrentPitch();

        float intensity = getIntensity();
        double yawChange = (rand.nextDouble() - 0.5) * 2.0 * intensity;

        if (spin360.isToggled() && rand.nextInt(3) == 0) {
            yawChange = (rand.nextBoolean() ? 1.0 : -1.0) * (200.0 + rand.nextDouble() * 360.0);
        }

        flickEndYaw = flickStartYaw + (float) yawChange;

        if (verticalFlick.isToggled()) {
            double ps = (rand.nextDouble() - 0.5) * 2.0 * intensity * 0.5;
            flickEndPitch = MathHelper.clamp_float(flickStartPitch + (float) ps, -90.0F, 90.0F);
        } else {
            flickEndPitch = flickStartPitch + (float) ((rand.nextDouble() - 0.5) * 15.0);
            flickEndPitch = MathHelper.clamp_float(flickEndPitch, -90.0F, 90.0F);
        }

        flickWobble = 1.0F + rand.nextFloat() * 3.0F;
        flickWobbleSpeed = (rand.nextFloat() - 0.5F) * 0.6F;
        flickWobbleOffset = rand.nextFloat() * 6.28F;
    }

    private void startSettleBack(long now) {
        flickPhase = PHASE_BACK;
        phaseStartTime = now;
        phaseDuration = getBackMs();
    }

    private float[] computeRotation(long now) {
        float cy = getCurrentYaw();
        float cp = getCurrentPitch();

        if (flickPhase == PHASE_AWAY) {
            float progress = (float) (now - phaseStartTime) / (float) phaseDuration;
            progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

            float speed = getSpeed();
            float dY = wrapDelta(flickEndYaw - cy);
            float dP = flickEndPitch - cp;

            float closeness = 1.0F - progress;
            float aggression = 0.5F + closeness * 0.5F;
            float step = speed * aggression * 8.0F;

            dY = MathHelper.clamp_float(dY, -step, step);
            dP = MathHelper.clamp_float(dP, -step * 0.7F, step * 0.7F);

            return new float[]{cy + dY, cp + dP};
        }

        if (flickPhase == PHASE_BACK) {
            float speed = getSpeed();
            float dY = wrapDelta(targetYaw - cy);
            float dP = targetPitch - cp;
            float dist = (float) Math.sqrt(dY * dY + dP * dP);

            if (dist < 2.0F) {
                return new float[]{targetYaw, MathHelper.clamp_float(targetPitch, -90.0F, 90.0F)};
            }

            float step = Math.max(speed * 6.0F, dist * 0.7F);
            dY = MathHelper.clamp_float(dY, -step, step);
            dP = MathHelper.clamp_float(dP, -step * 0.7F, step * 0.7F);
            return new float[]{cy + dY, MathHelper.clamp_float(cp + dP, -90.0F, 90.0F)};
        }

        return new float[]{cy, cp};
    }

    private float wrapDelta(float d) {
        while (d > 180.0F) d -= 360.0F;
        while (d < -180.0F) d += 360.0F;
        return d;
    }

    private float[] getAnglesToEntity(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dy = (entity.posY + entity.getEyeHeight()) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = entity.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = MathHelper.clamp_float(pitch, -90.0F, 90.0F);
        return new float[]{yaw, pitch};
    }

    private EntityPlayer findTargetById(int id) {
        if (mc.theWorld == null || id == -1) return null;
        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (entity instanceof EntityPlayer && entity.getEntityId() == id) {
                return (EntityPlayer) entity;
            }
        }
        return null;
    }

    private void suppressComboAim() {
        if (suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            savedComboAimState = AimAssist.comboAim.isToggled();
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(false);
            }
            suppressedComboAim = true;
        }
    }

    private void restoreComboAim() {
        if (!suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(true);
            }
        }
        suppressedComboAim = false;
        savedComboAimState = false;
    }
}
