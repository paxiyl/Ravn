package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class CrazyFlick extends Module {

    public static SliderSetting flickSpeed;
    public static SliderSetting flickIntensity;
    public static SliderSetting pitchRange;
    public static SliderSetting flickDuration;
    public static SliderSetting settleTime;
    public static SliderSetting aimSpeed;
    public static SliderSetting targetRange;
    public static SliderSetting hitsRequired;
    public static TickSetting spin360;
    public static TickSetting verticalFlick;
    public static TickSetting randomJitter;

    private final Random rand = new Random();

    private int state = 0;
    private long stateStartTime = 0;
    private long stateDuration = 0;

    private float flickStartYaw = 0;
    private float flickStartPitch = 0;
    private float flickEndYaw = 0;
    private float flickEndPitch = 0;

    private float settleStartYaw = 0;
    private float settleStartPitch = 0;
    private float settleEndYaw = 0;
    private float settleEndPitch = 0;

    private float prevAppliedYaw = 0;
    private float prevAppliedPitch = 0;
    private boolean hasPrev = false;

    private float jitterOffsetYaw = 0;
    private float jitterOffsetPitch = 0;
    private int jitterCounter = 0;

    private EntityPlayer comboTarget = null;

    private int comboCount = 0;
    private boolean flickActive = false;

    private long lastAttackTime = 0;
    private long prevAttackTime = 0;

    private float savedTargetYaw = 0;
    private float savedTargetPitch = 0;

    private boolean suppressedComboAim = false;
    private boolean savedComboAimState = false;

    private static final int STATE_IDLE = 0;
    private static final int STATE_FLICKING = 1;
    private static final int STATE_SETTLING = 2;

    private static final long HOLD_THRESHOLD_MS = 55;
    private static final long CLICK_TIMEOUT_MS = 600;

    public CrazyFlick() {
        super("CrazyFlick", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Flicks between single clicks in combos"));
        this.registerSetting(hitsRequired = new SliderSetting("Hits to activate", 3.0D, 1.0D, 10.0D, 1.0D));
        this.registerSetting(flickSpeed = new SliderSetting("Flick speed", 20.0D, 8.0D, 40.0D, 1.0D));
        this.registerSetting(flickIntensity = new SliderSetting("Flick intensity", 120.0D, 30.0D, 360.0D, 5.0D));
        this.registerSetting(pitchRange = new SliderSetting("Pitch range", 40.0D, 5.0D, 80.0D, 5.0D));
        this.registerSetting(flickDuration = new SliderSetting("Flick away (ms)", 80.0D, 20.0D, 200.0D, 5.0D));
        this.registerSetting(settleTime = new SliderSetting("Settle back (ms)", 120.0D, 40.0D, 300.0D, 5.0D));
        this.registerSetting(aimSpeed = new SliderSetting("Aim speed", 15.0D, 5.0D, 30.0D, 1.0D));
        this.registerSetting(targetRange = new SliderSetting("Target range", 4.0D, 2.0D, 6.0D, 0.5D));
        this.registerSetting(spin360 = new TickSetting("360 spins", false));
        this.registerSetting(verticalFlick = new TickSetting("Vertical flick", true));
        this.registerSetting(randomJitter = new TickSetting("Random jitter", true));
    }

    @Override
    public void onEnable() {
        state = STATE_IDLE;
        hasPrev = false;
        jitterOffsetYaw = 0;
        jitterOffsetPitch = 0;
        jitterCounter = 0;
        comboCount = 0;
        comboTarget = null;
        flickActive = false;
        lastAttackTime = 0;
        prevAttackTime = 0;
    }

    @Override
    public void onDisable() {
        hasPrev = false;
        flickActive = false;
        comboCount = 0;
        state = STATE_IDLE;
        restoreComboAim();
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof AttackEntityEvent) {
            AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
            if (event.entityPlayer != mc.thePlayer) return;
            if (!(event.target instanceof EntityPlayer)) return;

            EntityPlayer hit = (EntityPlayer) event.target;
            long now = System.currentTimeMillis();

            long gap = now - lastAttackTime;
            boolean isHolding = gap < HOLD_THRESHOLD_MS && lastAttackTime > 0;

            prevAttackTime = lastAttackTime;
            lastAttackTime = now;

            if (isHolding) {
                comboCount = 0;
                comboTarget = null;
                flickActive = false;
                state = STATE_IDLE;
                hasPrev = false;
                restoreComboAim();
                return;
            }

            if (comboTarget != null && comboTarget.getEntityId() == hit.getEntityId()) {
                comboCount++;
            } else {
                comboTarget = hit;
                comboCount = 1;
            }

            if (comboCount >= (int) hitsRequired.getInput()) {
                flickActive = true;
            }

            if (flickActive && state == STATE_IDLE) {
                savedTargetYaw = getAnglesToEntity(hit)[0];
                savedTargetPitch = getAnglesToEntity(hit)[1];
                beginFlickAway(now);
            } else if (flickActive && state == STATE_SETTLING) {
                settleEndYaw = getAnglesToEntity(hit)[0];
                settleEndPitch = getAnglesToEntity(hit)[1];
            }
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            flickActive = false;
            comboCount = 0;
            return;
        }

        if (mc.thePlayer.hurtTime > 0) {
            comboCount = 0;
            comboTarget = null;
            flickActive = false;
            state = STATE_IDLE;
            hasPrev = false;
            restoreComboAim();
            return;
        }

        if (!flickActive) {
            if (state != STATE_IDLE) {
                state = STATE_IDLE;
                hasPrev = false;
                restoreComboAim();
            }
            return;
        }

        if (comboTarget == null || comboTarget.isDead || !comboTarget.isEntityAlive()) {
            comboCount = 0;
            comboTarget = null;
            flickActive = false;
            state = STATE_IDLE;
            hasPrev = false;
            restoreComboAim();
            return;
        }

        if (mc.thePlayer.getDistanceToEntity(comboTarget) > targetRange.getInput() + 2.0F) {
            comboCount = 0;
            comboTarget = null;
            flickActive = false;
            state = STATE_IDLE;
            hasPrev = false;
            restoreComboAim();
            return;
        }

        long now = System.currentTimeMillis();

        boolean comboExpired = lastAttackTime > 0 && (now - lastAttackTime) > CLICK_TIMEOUT_MS;
        if (comboExpired) {
            comboCount = 0;
            comboTarget = null;
            flickActive = false;
            state = STATE_IDLE;
            hasPrev = false;
            restoreComboAim();
            return;
        }

        switch (state) {
            case STATE_FLICKING:
                if (now - stateStartTime >= stateDuration) {
                    beginSettleBack(now);
                }
                break;

            case STATE_SETTLING:
                if (now - stateStartTime >= stateDuration) {
                    state = STATE_IDLE;
                    hasPrev = false;
                }
                break;
        }

        float[] result = computeRotation(now);
        float finalYaw = result[0];
        float finalPitch = MathHelper.clamp_float(result[1], -90.0F, 90.0F);

        if (randomJitter.isToggled() && state == STATE_FLICKING) {
            jitterCounter++;
            if (jitterCounter >= 2 + rand.nextInt(3)) {
                jitterCounter = 0;
                jitterOffsetYaw = (float) (rand.nextGaussian() * 0.8);
                jitterOffsetPitch = (float) (rand.nextGaussian() * 0.5);
            }
            finalYaw += jitterOffsetYaw;
            finalPitch += jitterOffsetPitch;
            finalPitch = MathHelper.clamp_float(finalPitch, -90.0F, 90.0F);
        }

        e.setYaw(finalYaw);
        e.setPitch(finalPitch);

        mc.thePlayer.rotationYaw = finalYaw;
        mc.thePlayer.rotationPitch = finalPitch;
        mc.thePlayer.renderYawOffset = finalYaw;
        mc.thePlayer.rotationYawHead = finalYaw;

        prevAppliedYaw = finalYaw;
        prevAppliedPitch = finalPitch;
        hasPrev = true;
    }

    private void beginFlickAway(long now) {
        state = STATE_FLICKING;
        stateStartTime = now;
        stateDuration = (long) (flickDuration.getInput() + rand.nextDouble() * flickDuration.getInput() * 0.2);

        suppressComboAim();

        flickStartYaw = mc.thePlayer.rotationYaw;
        flickStartPitch = mc.thePlayer.rotationPitch;

        double intensity = flickIntensity.getInput();
        double yawChange = (rand.nextDouble() - 0.5) * 2.0 * intensity;

        if (spin360.isToggled() && rand.nextInt(3) == 0) {
            double sign = rand.nextBoolean() ? 1.0 : -1.0;
            yawChange = sign * (180.0 + rand.nextDouble() * 360.0);
        }

        flickEndYaw = flickStartYaw + (float) yawChange;

        if (verticalFlick.isToggled()) {
            double pitchSwing = (rand.nextDouble() - 0.5) * 2.0 * pitchRange.getInput();
            flickEndPitch = MathHelper.clamp_float(flickStartPitch + (float) pitchSwing, -90.0F, 90.0F);
        } else {
            flickEndPitch = flickStartPitch + (float) ((rand.nextDouble() - 0.5) * 15.0);
            flickEndPitch = MathHelper.clamp_float(flickEndPitch, -90.0F, 90.0F);
        }
    }

    private void beginSettleBack(long now) {
        state = STATE_SETTLING;
        stateStartTime = now;
        stateDuration = (long) (settleTime.getInput() + rand.nextDouble() * settleTime.getInput() * 0.2);

        settleStartYaw = mc.thePlayer.rotationYaw;
        settleStartPitch = mc.thePlayer.rotationPitch;
        settleEndYaw = savedTargetYaw;
        settleEndPitch = savedTargetPitch;
    }

    private float[] computeRotation(long now) {
        float curYaw = hasPrev ? prevAppliedYaw : mc.thePlayer.rotationYaw;
        float curPitch = hasPrev ? prevAppliedPitch : mc.thePlayer.rotationPitch;

        switch (state) {
            case STATE_FLICKING:
                return computeFlickRotation(curYaw, curPitch, now);

            case STATE_SETTLING:
                return computeSettleRotation(curYaw, curPitch, now);

            default:
                return new float[]{curYaw, curPitch};
        }
    }

    private float[] computeFlickRotation(float curYaw, float curPitch, long now) {
        float progress = (float) (now - stateStartTime) / (float) stateDuration;
        progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

        float eased = easeOutCubic(progress);

        float desiredYaw = flickStartYaw + wrapDelta(flickEndYaw - flickStartYaw) * eased;
        float desiredPitch = flickStartPitch + (flickEndPitch - flickStartPitch) * eased;

        float speed = (float) flickSpeed.getInput();
        float dYaw = wrapDelta(desiredYaw - curYaw);
        float dPitch = desiredPitch - curPitch;

        float maxStep = speed * 5.0F;
        dYaw = MathHelper.clamp_float(dYaw, -maxStep, maxStep);
        dPitch = MathHelper.clamp_float(dPitch, -maxStep * 0.7F, maxStep * 0.7F);

        float newYaw = curYaw + dYaw;
        float newPitch = MathHelper.clamp_float(curPitch + dPitch, -90.0F, 90.0F);

        return new float[]{newYaw, newPitch};
    }

    private float[] computeSettleRotation(float curYaw, float curPitch, long now) {
        float progress = (float) (now - stateStartTime) / (float) stateDuration;
        progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

        float speed = (float) aimSpeed.getInput();
        float dYaw = wrapDelta(settleEndYaw - curYaw);
        float dPitch = settleEndPitch - curPitch;

        float closeness = 1.0F - progress;
        float maxStep = speed * (0.3F + closeness * 0.7F) * 4.0F;
        dYaw = MathHelper.clamp_float(dYaw, -maxStep, maxStep);
        dPitch = MathHelper.clamp_float(dPitch, -maxStep * 0.7F, maxStep * 0.7F);

        float newYaw = curYaw + dYaw;
        float newPitch = MathHelper.clamp_float(curPitch + dPitch, -90.0F, 90.0F);

        return new float[]{newYaw, newPitch};
    }

    private float easeOutCubic(float t) {
        return 1.0F - (float) Math.pow(1.0 - t, 3);
    }

    private float wrapDelta(float delta) {
        while (delta > 180.0F) delta -= 360.0F;
        while (delta < -180.0F) delta += 360.0F;
        return delta;
    }

    private float[] getAnglesToEntity(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dy = (entity.posY + entity.getEyeHeight()) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = entity.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = MathHelper.clamp_float(pitch, -90.0F, 90.0F);
        return new float[]{yaw, pitch};
    }

    private void suppressComboAim() {
        if (suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            savedComboAimState = AimAssist.comboAim.isToggled();
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(false);
            }
            suppressedComboAim = true;
        }
    }

    private void restoreComboAim() {
        if (!suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(true);
            }
        }
        suppressedComboAim = false;
        savedComboAimState = false;
    }
}
