package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

import java.util.Random;

public class CrazyFlick extends Module {

    public static SliderSetting hitsRequired;
    public static SliderSetting flickStrength;
    public static SliderSetting targetRange;
    public static TickSetting spin360;
    public static TickSetting verticalFlick;

    private final Random rand = new Random();

    private int flickPhase = 0;
    private long phaseStartTime = 0;
    private long phaseDuration = 0;

    private float flickStartYaw, flickStartPitch;
    private float flickEndYaw, flickEndPitch;
    private float targetYaw, targetPitch;

    private float prevYaw = 0, prevPitch = 0;
    private boolean hasPrev = false;

    private float jitterY = 0, jitterP = 0;
    private int jitterTick = 0;
    private int jitterInterval = 3;

    private int comboTargetId = -1;
    private int comboCount = 0;
    private boolean flickUnlocked = false;

    private long lastAttackTime = 0;
    private boolean holdingReset = false;

    private boolean suppressedComboAim = false;
    private boolean savedComboAimState = false;

    private float wobblePhase = 0;
    private float wobbleAmp = 0;

    private double velYaw = 0, velPitch = 0;

    private static final int PHASE_OFF = 0;
    private static final int PHASE_AWAY = 1;
    private static final int PHASE_BACK = 2;

    private static final double DT = 0.016D;
    private static final double SPEED_CAP = 900.0D;
    private static final double PITCH_RATIO = 0.75D;
    private static final double DEADZONE = 0.5D;

    public CrazyFlick() {
        super("CrazyFlick", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Crazy flicks between clicks in combos"));
        this.registerSetting(hitsRequired = new SliderSetting("Hits to activate", 2.0D, 1.0D, 5.0D, 1.0D));
        this.registerSetting(flickStrength = new SliderSetting("Flick strength", 3.0D, 1.0D, 5.0D, 0.5D));
        this.registerSetting(targetRange = new SliderSetting("Target range", 4.0D, 2.0D, 6.0D, 0.5D));
        this.registerSetting(spin360 = new TickSetting("360 spins", false));
        this.registerSetting(verticalFlick = new TickSetting("Vertical flick", true));
    }

    @Override
    public void onEnable() {
        resetAll();
    }

    @Override
    public void onDisable() {
        resetAll();
        restoreComboAim();
    }

    private void resetAll() {
        flickPhase = PHASE_OFF;
        comboCount = 0;
        comboTargetId = -1;
        flickUnlocked = false;
        hasPrev = false;
        lastAttackTime = 0;
        holdingReset = false;
        velYaw = 0;
        velPitch = 0;
    }

    private float getIntensity() {
        float s = (float) flickStrength.getInput();
        return s * 55.0F + rand.nextFloat() * s * 15.0F;
    }

    private float getOmega() {
        return (float) flickStrength.getInput() * 2.5F;
    }

    private long getAwayMs() {
        float s = (float) flickStrength.getInput();
        return (long) (30.0 + s * 8.0 + rand.nextDouble() * s * 4.0);
    }

    private float getCurrentYaw() {
        return hasPrev ? prevYaw : mc.thePlayer.rotationYaw;
    }

    private float getCurrentPitch() {
        return hasPrev ? prevPitch : mc.thePlayer.rotationPitch;
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (!(fe.getEvent() instanceof AttackEntityEvent)) return;
        AttackEntityEvent event = (AttackEntityEvent) fe.getEvent();
        if (event.entityPlayer != mc.thePlayer) return;
        if (!(event.target instanceof EntityPlayer)) return;

        EntityPlayer hit = (EntityPlayer) event.target;
        long now = System.currentTimeMillis();
        int hitId = hit.getEntityId();
        long gap = now - lastAttackTime;
        lastAttackTime = now;

        if (gap < 50) {
            holdingReset = true;
            comboCount = 0;
            comboTargetId = -1;
            flickUnlocked = false;
            flickPhase = PHASE_OFF;
            hasPrev = false;
            velYaw = 0;
            velPitch = 0;
            restoreComboAim();
            return;
        }

        holdingReset = false;

        if (comboTargetId == hitId) {
            comboCount++;
        } else {
            comboTargetId = hitId;
            comboCount = 1;
        }

        if (comboCount >= (int) hitsRequired.getInput()) {
            flickUnlocked = true;
        }

        if (!flickUnlocked) return;

        float[] angles = getAnglesToEntity(hit);
        targetYaw = angles[0];
        targetPitch = angles[1];

        if (flickPhase == PHASE_OFF || flickPhase == PHASE_BACK) {
            startFlickAway(now);
        }
    }

    @Subscribe
    public void onUpdate(UpdateEvent e) {
        if (!e.isPre()) return;
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (holdingReset) return;

        if (Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled()) {
            if (flickPhase != PHASE_OFF) {
                flickPhase = PHASE_OFF;
                hasPrev = false;
                velYaw = 0;
                velPitch = 0;
                restoreComboAim();
            }
            return;
        }

        if (mc.thePlayer.hurtTime > 0) {
            resetAll();
            restoreComboAim();
            return;
        }

        if (!flickUnlocked) return;

        long now = System.currentTimeMillis();

        if (lastAttackTime > 0 && (now - lastAttackTime) > 500) {
            resetAll();
            restoreComboAim();
            return;
        }

        EntityPlayer target = findTargetById(comboTargetId);
        if (target == null || target.isDead || !target.isEntityAlive()) {
            resetAll();
            restoreComboAim();
            return;
        }

        if (mc.thePlayer.getDistanceToEntity(target) > targetRange.getInput() + 2.0F) {
            resetAll();
            restoreComboAim();
            return;
        }

        float[] targetAngles = getAnglesToEntity(target);
        targetYaw = targetAngles[0];
        targetPitch = targetAngles[1];

        switch (flickPhase) {
            case PHASE_AWAY:
                if (now - phaseStartTime >= phaseDuration) {
                    flickPhase = PHASE_BACK;
                    velYaw = 0;
                    velPitch = 0;
                }
                break;
            case PHASE_BACK:
                float dY = Math.abs(wrapDelta(targetYaw - getCurrentYaw()));
                float dP = Math.abs(targetPitch - getCurrentPitch());
                if (dY < 1.0F && dP < 1.0F) {
                    flickPhase = PHASE_OFF;
                    hasPrev = false;
                    velYaw = 0;
                    velPitch = 0;
                }
                break;
        }

        if (flickPhase == PHASE_OFF) return;

        float[] result = computeRotation(now);
        float fy = result[0];
        float fp = MathHelper.clamp_float(result[1], -90.0F, 90.0F);

        if (flickPhase == PHASE_AWAY) {
            jitterTick++;
            if (jitterTick >= jitterInterval) {
                jitterTick = 0;
                jitterInterval = 1 + rand.nextInt(3);
                jitterY = (float) (rand.nextGaussian() * (0.5 + rand.nextDouble() * 0.8));
                jitterP = (float) (rand.nextGaussian() * (0.3 + rand.nextDouble() * 0.5));
            }
            fy += jitterY;
            fp += jitterP;

            wobblePhase += 0.3F + rand.nextFloat() * 0.2F;
            fy += (float) Math.sin(wobblePhase) * wobbleAmp;
            fp += (float) Math.cos(wobblePhase * 0.7F) * wobbleAmp * 0.4F;

            fp = MathHelper.clamp_float(fp, -90.0F, 90.0F);
        }

        e.setYaw(fy);
        e.setPitch(fp);
        mc.thePlayer.rotationYaw = fy;
        mc.thePlayer.rotationPitch = fp;
        mc.thePlayer.renderYawOffset = fy;
        mc.thePlayer.rotationYawHead = fy;

        prevYaw = fy;
        prevPitch = fp;
        hasPrev = true;
    }

    private void startFlickAway(long now) {
        flickPhase = PHASE_AWAY;
        phaseStartTime = now;
        phaseDuration = getAwayMs();

        suppressComboAim();

        flickStartYaw = getCurrentYaw();
        flickStartPitch = getCurrentPitch();

        float intensity = getIntensity();
        double yawChange = (rand.nextDouble() - 0.5) * 2.0 * intensity;

        if (spin360.isToggled() && rand.nextInt(3) == 0) {
            yawChange = (rand.nextBoolean() ? 1.0 : -1.0) * (200.0 + rand.nextDouble() * 360.0);
        }

        flickEndYaw = flickStartYaw + (float) yawChange;

        if (verticalFlick.isToggled()) {
            double ps = (rand.nextDouble() - 0.5) * 2.0 * intensity * 0.5;
            flickEndPitch = MathHelper.clamp_float(flickStartPitch + (float) ps, -90.0F, 90.0F);
        } else {
            flickEndPitch = flickStartPitch + (float) ((rand.nextDouble() - 0.5) * 10.0);
            flickEndPitch = MathHelper.clamp_float(flickEndPitch, -90.0F, 90.0F);
        }

        wobbleAmp = 0.5F + rand.nextFloat() * 2.0F;
        wobblePhase = rand.nextFloat() * 6.28F;
        velYaw = 0;
        velPitch = 0;
    }

    private float[] computeRotation(long now) {
        float cy = getCurrentYaw();
        float cp = getCurrentPitch();

        if (flickPhase == PHASE_AWAY) {
            float progress = (float) (now - phaseStartTime) / (float) phaseDuration;
            progress = MathHelper.clamp_float(progress, 0.0F, 1.0F);

            float desiredY = flickStartYaw + wrapDelta(flickEndYaw - flickStartYaw) * progress;
            float desiredP = flickStartPitch + (flickEndPitch - flickStartPitch) * progress;

            float omega = getOmega();
            float dY = wrapDelta(desiredY - cy);
            float dP = desiredP - cp;

            float closeness = 1.0F - progress;
            float stepY = omega * (0.6F + closeness * 0.4F) * 5.0F;
            float stepP = stepY * 0.7F;
            dY = MathHelper.clamp_float(dY, -stepY, stepY);
            dP = MathHelper.clamp_float(dP, -stepP, stepP);

            return new float[]{cy + dY, cp + dP};
        }

        if (flickPhase == PHASE_BACK) {
            double errYaw = wrapDeltaDouble(targetYaw - cy);
            double errPitch = targetPitch - cp;

            double omega = Math.max(getOmega() * 1.5F, 4.0D);
            omega = Math.min(omega, 1.5D / DT);

            double moveYaw = springStep(errYaw, velYaw, omega);
            velYaw = moveYaw / DT;
            double maxStepH = SPEED_CAP * DT;
            moveYaw = Math.max(-maxStepH, Math.min(maxStepH, moveYaw));
            if (Math.abs(errYaw) < DEADZONE) {
                moveYaw = 0;
                velYaw *= Math.exp(-10.0 * DT);
            }

            double movePitch = springStep(errPitch, velPitch, omega * 0.85D);
            velPitch = movePitch / DT;
            double maxStepV = SPEED_CAP * PITCH_RATIO * DT;
            movePitch = Math.max(-maxStepV, Math.min(maxStepV, movePitch));
            if (Math.abs(errPitch) < DEADZONE) {
                movePitch = 0;
                velPitch *= Math.exp(-10.0 * DT);
            }

            float newYaw = (float) (cy + moveYaw);
            float newPitch = MathHelper.clamp_float((float) (cp + movePitch), -90.0F, 90.0F);
            return new float[]{newYaw, newPitch};
        }

        return new float[]{cy, cp};
    }

    private double springStep(double error, double velocity, double omega) {
        double stiffness = omega * omega;
        double damping = 2.0D * omega;
        double newVel = velocity + (stiffness * error - damping * velocity) * DT;
        return (velocity + newVel) * 0.5D * DT;
    }

    private float wrapDelta(float d) {
        while (d > 180.0F) d -= 360.0F;
        while (d < -180.0F) d += 360.0F;
        return d;
    }

    private double wrapDeltaDouble(double d) {
        while (d > 180.0D) d -= 360.0D;
        while (d < -180.0D) d += 360.0D;
        return d;
    }

    private float[] getAnglesToEntity(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dy = (entity.posY + entity.getEyeHeight()) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = entity.posZ - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = MathHelper.clamp_float(pitch, -90.0F, 90.0F);
        return new float[]{yaw, pitch};
    }

    private EntityPlayer findTargetById(int id) {
        if (mc.theWorld == null || id == -1) return null;
        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (entity instanceof EntityPlayer && entity.getEntityId() == id) {
                return (EntityPlayer) entity;
            }
        }
        return null;
    }

    private void suppressComboAim() {
        if (suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            savedComboAimState = AimAssist.comboAim.isToggled();
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(false);
            }
            suppressedComboAim = true;
        }
    }

    private void restoreComboAim() {
        if (!suppressedComboAim) return;
        Module m = Raven.moduleManager.getModuleByClazz(AimAssist.class);
        if (m != null && m.isEnabled()) {
            if (savedComboAimState) {
                AimAssist.comboAim.setEnabled(true);
            }
        }
        suppressedComboAim = false;
        savedComboAimState = false;
    }
}
