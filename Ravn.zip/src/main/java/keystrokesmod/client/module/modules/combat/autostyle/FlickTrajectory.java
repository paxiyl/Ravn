package keystrokesmod.client.module.modules.combat.autostyle;

public class FlickTrajectory {

    public final float startYaw;
    public final float startPitch;
    public final float peakYaw;
    public final float peakPitch;
    public final float overshootYaw;
    public final float overshootPitch;
    public final float endYaw;
    public final float endPitch;
    public final long flickDurationNanos;
    public final long overshootDurationNanos;
    public final long recoveryDurationNanos;
    public final long totalDurationNanos;

    public FlickTrajectory(
        float startYaw, float startPitch,
        float peakYaw, float peakPitch,
        float overshootYaw, float overshootPitch,
        float endYaw, float endPitch,
        long flickDurationNanos,
        long overshootDurationNanos,
        long recoveryDurationNanos
    ) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.overshootYaw = overshootYaw;
        this.overshootPitch = overshootPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.flickDurationNanos = flickDurationNanos;
        this.overshootDurationNanos = overshootDurationNanos;
        this.recoveryDurationNanos = recoveryDurationNanos;
        this.totalDurationNanos = flickDurationNanos + overshootDurationNanos + recoveryDurationNanos;
    }

    public Rotation evaluate(long elapsedNanos) {
        if (elapsedNanos < 0) return new Rotation(startYaw, startPitch);
        if (elapsedNanos >= totalDurationNanos) return new Rotation(endYaw, endPitch);

        if (elapsedNanos < flickDurationNanos) {
            return evaluateFlick(elapsedNanos);
        }
        long afterFlick = elapsedNanos - flickDurationNanos;
        if (afterFlick < overshootDurationNanos) {
            return evaluateOvershoot(afterFlick);
        }
        long afterOvershoot = afterFlick - overshootDurationNanos;
        return evaluateRecovery(afterOvershoot);
    }

    private Rotation evaluateFlick(long elapsed) {
        double t = (double) elapsed / flickDurationNanos;
        double eased = easeOutCubic(t);
        float yaw = startYaw + (peakYaw - startYaw) * (float) eased;
        float pitch = startPitch + (peakPitch - startPitch) * (float) eased;
        return new Rotation(yaw, Rotation.clampPitch(pitch));
    }

    private Rotation evaluateOvershoot(long elapsed) {
        double t = (double) elapsed / overshootDurationNanos;
        double eased = easeInOutQuad(t);
        float yaw = peakYaw + (overshootYaw - peakYaw) * (float) eased;
        float pitch = peakPitch + (overshootPitch - peakPitch) * (float) eased;
        return new Rotation(yaw, Rotation.clampPitch(pitch));
    }

    private Rotation evaluateRecovery(long elapsed) {
        double t = (double) elapsed / recoveryDurationNanos;
        double eased = easeOutQuart(t);
        float yaw = overshootYaw + (endYaw - overshootYaw) * (float) eased;
        float pitch = overshootPitch + (endPitch - overshootPitch) * (float) eased;
        return new Rotation(yaw, Rotation.clampPitch(pitch));
    }

    private static double easeOutCubic(double t) {
        double f = 1.0 - t;
        return 1.0 - f * f * f;
    }

    private static double easeInOutQuad(double t) {
        return t < 0.5 ? 2.0 * t * t : 1.0 - Math.pow(-2.0 * t + 2.0, 2) / 2.0;
    }

    private static double easeOutQuart(double t) {
        double f = 1.0 - t;
        return 1.0 - f * f * f * f;
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalDurationNanos;
    }

    public static FlickTrajectory create(
        float currentYaw, float currentPitch,
        float targetYaw, float targetPitch,
        float amplitude, float pitchAmplitude,
        boolean directionLeft,
        double overshootPercent, double overshootAngleMax,
        double flickSpeedMultiplier, double recoverySpeedMultiplier,
        long flickDurationNanos
    ) {
        float sign = directionLeft ? -1.0F : 1.0F;

        float peakYaw = currentYaw + sign * amplitude;
        float peakPitch = Rotation.clampPitch(currentPitch + pitchAmplitude * sign);

        float overshootAmount = (float) Math.min(
            amplitude * overshootPercent,
            overshootAngleMax
        );
        float overshootYaw = peakYaw + sign * overshootAmount;
        float overshootPitch = Rotation.clampPitch(peakPitch + pitchAmplitude * 0.3F * sign);

        long overshootDuration = (long) (flickDurationNanos * 0.3);
        long recoveryDuration = (long) (flickDurationNanos * recoverySpeedMultiplier * 0.6);

        return new FlickTrajectory(
            currentYaw, currentPitch,
            peakYaw, peakPitch,
            overshootYaw, overshootPitch,
            targetYaw, Rotation.clampPitch(targetPitch),
            flickDurationNanos,
            overshootDuration,
            recoveryDuration
        );
    }
}
