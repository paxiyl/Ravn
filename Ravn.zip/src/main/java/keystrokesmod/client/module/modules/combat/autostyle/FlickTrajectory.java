package keystrokesmod.client.module.modules.combat.autostyle;

public class FlickTrajectory {

    private final float startYaw, startPitch;
    private final float peakYaw, peakPitch;
    private final float endYaw, endPitch;
    private final long flickNanos;
    private final long returnNanos;
    private final long totalNanos;

    public FlickTrajectory(
        float startYaw, float startPitch,
        float peakYaw, float peakPitch,
        float endYaw, float endPitch,
        long flickNanos, long returnNanos
    ) {
        this.startYaw = startYaw;
        this.startPitch = startPitch;
        this.peakYaw = peakYaw;
        this.peakPitch = peakPitch;
        this.endYaw = endYaw;
        this.endPitch = endPitch;
        this.flickNanos = flickNanos;
        this.returnNanos = returnNanos;
        this.totalNanos = flickNanos + returnNanos;
    }

    public Rotation evaluate(long elapsedNanos) {
        if (elapsedNanos >= totalNanos) return new Rotation(endYaw, endPitch);

        if (elapsedNanos < flickNanos) {
            double t = (double) elapsedNanos / flickNanos;
            double e = easeOutCubic(t);
            return new Rotation(
                startYaw + (peakYaw - startYaw) * (float) e,
                Rotation.clampPitch(startPitch + (peakPitch - startPitch) * (float) e)
            );
        }

        double t = (double) (elapsedNanos - flickNanos) / returnNanos;
        double e = easeOutQuad(t);
        return new Rotation(
            peakYaw + (endYaw - peakYaw) * (float) e,
            Rotation.clampPitch(peakPitch + (endPitch - peakPitch) * (float) e)
        );
    }

    public boolean isComplete(long elapsedNanos) {
        return elapsedNanos >= totalNanos;
    }

    public long getTotalNanos() { return totalNanos; }

    private static double easeOutCubic(double t) {
        double f = 1.0 - t;
        return 1.0 - f * f * f;
    }

    private static double easeOutQuad(double t) {
        return 1.0 - (1.0 - t) * (1.0 - t);
    }
}
