package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class ShearsToSword extends Module {
    public static TickSetting switchBackDelay;
    public static TickSetting onlyPlayers;

    private int savedSlot = -1;
    private boolean switched = false;
    private int switchBackTimer = 0;

    public ShearsToSword() {
        super("Shears To Sword", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Switches shears to sword on attack."));
        this.registerSetting(switchBackDelay = new TickSetting("Switch back", true));
        this.registerSetting(onlyPlayers = new TickSetting("Players only", false));
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || mc.currentScreen != null)
            return;

        if (switchBackTimer > 0) {
            switchBackTimer--;
            if (switchBackTimer == 0 && switched) {
                mc.thePlayer.inventory.currentItem = savedSlot;
                switched = false;
                savedSlot = -1;
            }
            return;
        }

        if (!mc.gameSettings.keyBindAttack.isKeyDown()) {
            if (switched) {
                mc.thePlayer.inventory.currentItem = savedSlot;
                switched = false;
                savedSlot = -1;
            }
            return;
        }

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null)
            return;
        if (!(held.getItem() instanceof ItemShears))
            return;

        Entity target = mc.objectMouseOver != null ? mc.objectMouseOver.entityHit : null;
        if (target == null)
            return;

        if (onlyPlayers.isToggled() && !(target instanceof EntityPlayer))
            return;

        int swordSlot = findBestSword();
        if (swordSlot == -1)
            return;

        savedSlot = mc.thePlayer.inventory.currentItem;
        mc.thePlayer.inventory.currentItem = swordSlot;
        switched = true;
        switchBackTimer = 6;
    }

    private int findBestSword() {
        int bestSlot = -1;
        int bestDamage = -1;

        for (int slot = 0; slot <= 8; slot++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
            if (stack == null)
                continue;

            Item item = stack.getItem();
            if (!(item instanceof ItemSword))
                continue;

            int damage = (int) ((ItemSword) item).getDamageVsEntity();
            if (stack.isItemEnchanted())
                damage += 2;

            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = slot;
            }
        }

        return bestSlot;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (switched) {
            mc.thePlayer.inventory.currentItem = savedSlot;
            switched = false;
            savedSlot = -1;
        }
        switchBackTimer = 0;
    }
}
