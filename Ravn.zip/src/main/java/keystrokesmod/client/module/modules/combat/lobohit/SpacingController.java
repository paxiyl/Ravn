package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

public class SpacingController {

    private static final float MC_REACH = 3.0f;
    private static final float GROUND_FRICTION = 0.91f;
    private static final float AIR_FRICTION = 0.98f;

    private float idealDistance = 3.0f;
    private float error = 0;
    private float errorVelocity = 0;
    private float previousError = 0;

    private float predictedDist20 = 3.0f;
    private float convergenceTicks = 999;

    private ActionSequence recommendedAction = ActionSequence.NONE;

    public enum ActionSequence {
        NONE,
        SPRINT_RESET_WTAP,
        SPRINT_RESET_STAP,
        SPRINT_CANCEL,
        SPRINT_RESUME,
        JUMP_RESET
    }

    public void reset() {
        idealDistance = 3.0f;
        error = 0;
        errorVelocity = 0;
        previousError = 0;
        predictedDist20 = 3.0f;
        convergenceTicks = 999;
        recommendedAction = ActionSequence.NONE;
    }

    public void update(CombatState state, TargetAnalyzer target, EntityPlayer targetPlayer) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        previousError = error;

        idealDistance = calculateIdealDistance(state, target, targetPlayer);
        state.setIdealDistance(idealDistance);

        error = state.getCurrentDistance() - idealDistance;

        errorVelocity = error - previousError;

        calculatePrediction(state, target, targetPlayer);

        recommendedAction = calculateOptimalAction(state, target);
    }

    private float calculateIdealDistance(CombatState state, TargetAnalyzer target, EntityPlayer targetPlayer) {
        float ideal = MC_REACH;

        float myPing = state.getSmoothedPing();
        float theirPing = state.getPingMs();
        float pingRatio = myPing / Math.max(theirPing, 1.0f);
        if (pingRatio > 1.2f) {
            ideal += (pingRatio - 1.0f) * 0.08f;
        } else if (pingRatio < 0.8f) {
            ideal -= (1.0f - pingRatio) * 0.05f;
        }

        float myKB = state.getPlayerKbReceived();
        float theirKB = state.getRecentKnockback();
        float avgTheirKB = target.getAverageKnockback();

        float kbAdvantage = theirKB - myKB;
        if (kbAdvantage > 0) {
            ideal -= kbAdvantage * 0.12f;
        } else {
            ideal += Math.abs(kbAdvantage) * 0.18f;
        }

        if (myKB > 0.4f) {
            ideal += myKB * 0.25f;
        }

        float targetClosingSpeed = 0;
        if (state.getDistanceDelta() < -0.02f) {
            targetClosingSpeed = Math.abs(state.getDistanceDelta()) * 20;
        }
        if (targetClosingSpeed > 2.0f) {
            ideal += targetClosingSpeed * 0.04f;
        }

        float playerClosingSpeed = 0;
        if (state.getDistanceDelta() > 0.02f) {
            playerClosingSpeed = state.getDistanceDelta() * 20;
        }
        if (playerClosingSpeed > 3.0f) {
            ideal -= playerClosingSpeed * 0.03f;
        }

        float mySpeed = state.getPlayerVelocity();
        float theirSpeed = state.getTargetVelocity();
        float speedAdvantage = mySpeed - theirSpeed;
        ideal -= speedAdvantage * 0.02f;

        if (state.isTargetGrounded() && !state.isPlayerGrounded()) {
            ideal += 0.15f;
        }
        if (!state.isTargetGrounded() && state.isPlayerGrounded()) {
            ideal -= 0.1f;
        }

        float healthRatio = state.getPlayerHealth() / Math.max(state.getTargetHealth(), 1.0f);
        if (healthRatio < 0.5f) {
            ideal += 0.35f;
        } else if (healthRatio < 0.8f) {
            ideal += 0.15f;
        } else if (healthRatio > 2.0f) {
            ideal -= 0.2f;
        }

        if (state.getTicksInCombat() < 10) {
            ideal += 0.1f;
        }

        if (targetPlayer != null) {
            float targetMovingToward = target.isMovingTowards(targetPlayer) ? 1.0f : -1.0f;
            ideal += targetMovingToward * 0.1f;
        }

        if (avgTheirKB > 0.3f) {
            ideal += avgTheirKB * 0.1f;
        }

        return MathHelper.clamp_float(ideal, 2.2f, 4.8f);
    }

    private void calculatePrediction(CombatState state, TargetAnalyzer target, EntityPlayer targetPlayer) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || targetPlayer == null) return;

        float playerVX = (float) mc.thePlayer.motionX;
        float playerVZ = (float) mc.thePlayer.motionZ;
        boolean playerGrounded = mc.thePlayer.onGround;

        float targetVX = target.getMotionX();
        float targetVZ = target.getMotionZ();
        boolean targetGrounded = state.isTargetGrounded();

        float simPlayerX = (float) mc.thePlayer.posX;
        float simPlayerZ = (float) mc.thePlayer.posZ;
        float simTargetX = (float) targetPlayer.posX;
        float simTargetZ = (float) targetPlayer.posZ;

        float simPVX = playerVX;
        float simPVZ = playerVZ;
        float simTVX = targetVX;
        float simTVZ = targetVZ;

        for (int t = 0; t < 20; t++) {
            float pFric = playerGrounded ? GROUND_FRICTION : AIR_FRICTION;
            float tFric = targetGrounded ? GROUND_FRICTION : AIR_FRICTION;

            simPVX *= pFric;
            simPVZ *= pFric;
            simTVX *= tFric;
            simTVZ *= tFric;

            simPlayerX += simPVX;
            simPlayerZ += simPVZ;
            simTargetX += simTVX;
            simTargetZ += simTVZ;
        }

        float pdx = simPlayerX - simTargetX;
        float pdz = simPlayerZ - simTargetZ;
        predictedDist20 = MathHelper.sqrt_float(pdx * pdx + pdz * pdz);

        float distDelta = predictedDist20 - state.getCurrentDistance();
        if (Math.abs(distDelta) > 0.01f) {
            convergenceTicks = Math.abs(error) / (Math.abs(distDelta) / 20.0f + 0.001f);
        } else {
            convergenceTicks = 999;
        }
    }

    private ActionSequence calculateOptimalAction(CombatState state, TargetAnalyzer target) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return ActionSequence.NONE;

        float absError = Math.abs(error);
        boolean closing = errorVelocity < -0.01f;
        boolean separating = errorVelocity > 0.01f;
        boolean sprinting = mc.thePlayer.isSprinting();
        boolean grounded = state.isPlayerGrounded();
        boolean justHit = state.getTicksSinceLastHit() < 2;

        if (absError < 0.15f) return ActionSequence.NONE;

        if (error > 0.2f) {
            if (separating || absError > 0.6f) {
                if (sprinting && grounded) return ActionSequence.SPRINT_CANCEL;
            }
            return ActionSequence.NONE;
        }

        if (error < -0.2f) {
            if (justHit && sprinting && state.getPlayerVelocity() > 3.5f) {
                boolean overshooting = errorVelocity < -0.03f;
                return overshooting ? ActionSequence.SPRINT_RESET_STAP : ActionSequence.SPRINT_RESET_WTAP;
            }

            if (separating) return ActionSequence.NONE;

            if (absError > 0.4f) {
                if (!sprinting && grounded) return ActionSequence.SPRINT_RESUME;
                return ActionSequence.NONE;
            }

            if (absError > 0.2f && state.getPlayerVelocity() > 3.0f && grounded && !sprinting) {
                return ActionSequence.SPRINT_RESUME;
            }
        }

        return ActionSequence.NONE;
    }

    public float getNudgeAmount() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return 0;
        if (!mc.thePlayer.onGround) return 0;

        float absError = Math.abs(error);
        if (absError < 0.2f) return 0;

        float nudge = error * 0.04f;
        return MathHelper.clamp_float(nudge, -0.08f, 0.08f);
    }

    public float getIdealDistance() { return idealDistance; }
    public float getError() { return error; }
    public float getErrorVelocity() { return errorVelocity; }
    public float getConvergenceTicks() { return convergenceTicks; }
    public ActionSequence getRecommendedAction() { return recommendedAction; }
    public float getPredictedDist20() { return predictedDist20; }
}
