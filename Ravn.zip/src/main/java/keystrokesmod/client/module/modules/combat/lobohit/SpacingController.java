package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

public class SpacingController {
    private float optimalDistance = 3.0f;
    private float aggressiveDistance = 2.5f;
    private float defensiveDistance = 3.5f;
    private float currentSpacingAdjustment = 0;
    private float spacingMomentum = 0;
    private int spacingTicks = 0;
    private boolean strafeActive = false;
    private boolean backwardActive = false;
    private boolean forwardActive = true;
    private int strafeDirection = 1;
    private int strafeTicks = 0;
    private int strafeDuration = 0;

    public void reset() {
        optimalDistance = 3.0f;
        aggressiveDistance = 2.5f;
        defensiveDistance = 3.5f;
        currentSpacingAdjustment = 0;
        spacingMomentum = 0;
        spacingTicks = 0;
        strafeActive = false;
        backwardActive = false;
        forwardActive = true;
        strafeDirection = 1;
        strafeTicks = 0;
        strafeDuration = 0;
    }

    public void update(CombatState state, TargetAnalyzer targetAnalyzer, EntityPlayer player) {
        if (player == null) return;

        spacingTicks++;

        float distance = state.getTargetDistance();
        float distanceDelta = state.getTargetDistanceDelta();
        float targetSpeed = targetAnalyzer.getSpeed();
        float playerHealth = state.getPlayerHealth();
        float targetHealth = state.getTargetHealth();
        float ping = state.getPingMs();

        float pingCompensation = ping / 100.0f;
        float healthRatio = playerHealth / Math.max(targetHealth, 0.01f);
        float velocityFactor = targetSpeed / 4.317f;

        optimalDistance = calculateOptimalDistance(distance, distanceDelta, targetSpeed, healthRatio, pingCompensation);
        aggressiveDistance = optimalDistance - 0.5f;
        defensiveDistance = optimalDistance + 0.5f;

        if (distance > optimalDistance + 0.5f) {
            currentSpacingAdjustment = -0.2f;
        } else if (distance < optimalDistance - 0.5f) {
            currentSpacingAdjustment = 0.2f;
        } else {
            currentSpacingAdjustment *= 0.8f;
        }

        spacingMomentum += currentSpacingAdjustment;
        spacingMomentum *= 0.9f;

        state.setPlayerShouldApproach(distance > optimalDistance + 0.3f);

        if (state.isTargetMoving() && targetAnalyzer.isStrafing()) {
            handleStrafe(player, targetAnalyzer, state);
        } else {
            strafeActive = false;
        }

        state.setPlayerPositionConfidence(Math.max(0, 1.0f - distanceDelta * 2));
    }

    private float calculateOptimalDistance(float distance, float distanceDelta, float targetSpeed, float healthRatio, float pingComp) {
        float base = 2.8f;

        if (healthRatio > 1.5f) {
            base -= 0.3f;
        } else if (healthRatio < 0.7f) {
            base += 0.3f;
        }

        if (targetSpeed > 3.5f) {
            base += 0.2f;
        }

        base += pingComp * 0.1f;

        if (distanceDelta < -0.1f) {
            base += 0.2f;
        } else if (distanceDelta > 0.1f) {
            base -= 0.1f;
        }

        return MathHelper.clamp_float(base, 2.2f, 4.0f);
    }

    private void handleStrafe(EntityPlayer player, TargetAnalyzer targetAnalyzer, CombatState state) {
        strafeTicks++;
        if (strafeTicks >= strafeDuration || strafeDuration <= 0) {
            strafeActive = !strafeActive;
            if (strafeActive) {
                strafeDirection *= -1;
                strafeDuration = 8 + (int)(Math.random() * 12);
            } else {
                strafeDuration = 4 + (int)(Math.random() * 6);
            }
            strafeTicks = 0;
        }
    }

    public float getOptimalDistance() { return optimalDistance; }
    public float getAggressiveDistance() { return aggressiveDistance; }
    public float getDefensiveDistance() { return defensiveDistance; }
    public float getSpacingAdjustment() { return currentSpacingAdjustment; }
    public float getSpacingMomentum() { return spacingMomentum; }
    public boolean isStrafeActive() { return strafeActive; }
    public int getStrafeDirection() { return strafeDirection; }
    public boolean isForwardActive() { return forwardActive; }
    public boolean isBackwardActive() { return backwardActive; }
    public float getDistanceError(float currentDistance) {
        return currentDistance - optimalDistance;
    }

    public MovementInput calculateMovementInput(EntityPlayer player, TargetAnalyzer targetAnalyzer, CombatState state) {
        MovementInput input = new MovementInput();

        float distance = state.getTargetDistance();
        float distanceDelta = state.getTargetDistanceDelta();
        float targetSpeed = targetAnalyzer.getSpeed();

        input.forward = distance > optimalDistance + 0.2f ? 1.0f : (distance < optimalDistance - 0.2f ? -0.5f : 0);

        if (strafeActive) {
            input.strafe = strafeDirection * 0.8f;
        } else {
            input.strafe = 0;
        }

        if (targetAnalyzer.isMovingTowards(player)) {
            input.forward = Math.max(input.forward, 0.5f);
        }

        if (distance < aggressiveDistance && state.getTargetHealth() > 5) {
            input.forward = 1.0f;
        }

        if (state.isPlayerVulnerable() && state.getPlayerHealth() < 8) {
            input.forward = -0.3f;
            input.strafe = 0;
        }

        input.forward = MathHelper.clamp_float(input.forward, -1.0f, 1.0f);
        input.strafe = MathHelper.clamp_float(input.strafe, -1.0f, 1.0f);

        return input;
    }

    public static class MovementInput {
        public float forward = 0;
        public float strafe = 0;
        public boolean jump = false;
        public boolean sneak = false;
    }
}
