package keystrokesmod.client.module.modules.combat.lobohit;

import net.minecraft.util.MathHelper;

public class SpacingController {

    private float currentIdealDistance = 3.0f;
    private float distanceError = 0;
    private float velocityCorrection = 0;

    private static final float BASE_IDEAL = 3.0f;
    private static final float MIN_IDEAL = 2.2f;
    private static final float MAX_IDEAL = 4.5f;

    public void reset() {
        currentIdealDistance = BASE_IDEAL;
        distanceError = 0;
        velocityCorrection = 0;
    }

    public void update(CombatState state, TargetAnalyzer target) {
        float currentDist = state.getCurrentDistance();
        float playerVel = state.getPlayerVelocity();
        float targetVel = state.getTargetVelocity();
        float relVel = state.getRelativeVelocity();
        float kb = state.getEstimatedKnockback();
        float ping = state.getSmoothedPing();
        float targetHealth = state.getTargetHealth();
        float playerHealth = state.getPlayerHealth();

        currentIdealDistance = calculateIdealDistance(playerVel, targetVel, kb, ping, targetHealth, playerHealth);
        state.setIdealDistance(currentIdealDistance);

        distanceError = currentDist - currentIdealDistance;

        velocityCorrection = calculateVelocityCorrection(playerVel, targetVel, relVel);
    }

    private float calculateIdealDistance(float playerVel, float targetVel, float kb, float ping, float targetHealth, float playerHealth) {
        float ideal = BASE_IDEAL;

        float pingFactor = ping / 100.0f;
        ideal += pingFactor * 0.1f;

        float healthRatio = playerHealth / Math.max(targetHealth, 1.0f);
        if (healthRatio < 0.7f) {
            ideal += 0.25f;
        } else if (healthRatio > 1.5f) {
            ideal -= 0.15f;
        }

        if (kb > 0.2f) {
            ideal += kb * 0.15f;
        }

        if (targetVel > 3.5f) {
            ideal += 0.15f;
        }

        return MathHelper.clamp_float(ideal, MIN_IDEAL, MAX_IDEAL);
    }

    private float calculateVelocityCorrection(float playerVel, float targetVel, float relVel) {
        float correction = 0;

        if (relVel < -0.2f) {
            correction = relVel * 0.3f;
        } else if (relVel > 0.2f) {
            correction = relVel * 0.25f;
        }

        if (playerVel > 4.0f && targetVel < 2.0f) {
            correction -= 0.4f;
        }

        return MathHelper.clamp_float(correction, -1.0f, 1.0f);
    }

    public CombatState.SpacingDecision decide(CombatState state, TargetAnalyzer target) {
        boolean targetUnpredictable = target.isTargetChangedDirection();
        float confidence = state.getPredictionConfidence();

        if (Math.abs(distanceError) < 0.3f && Math.abs(velocityCorrection) < 0.15f && confidence > 0.5f) {
            return CombatState.SpacingDecision.MAINTAIN;
        }

        float effectiveError = distanceError + velocityCorrection * confidence;

        if (effectiveError > 0.4f) {
            return CombatState.SpacingDecision.CLOSE;
        }

        if (effectiveError < -0.4f) {
            return CombatState.SpacingDecision.BACK_OFF;
        }

        return CombatState.SpacingDecision.MAINTAIN;
    }

    public float getForwardAdjustment(CombatState.SpacingDecision decision) {
        switch (decision) {
            case CLOSE:
                return MathHelper.clamp_float(distanceError * 0.35f + velocityCorrection * 0.2f, -0.5f, 0.5f);
            case BACK_OFF:
                return MathHelper.clamp_float(distanceError * 0.25f + velocityCorrection * 0.15f, -0.4f, 0.4f);
            case MAINTAIN:
            default:
                return 0;
        }
    }

    public float getCurrentIdealDistance() { return currentIdealDistance; }
    public float getDistanceError() { return distanceError; }
    public float getVelocityCorrection() { return velocityCorrection; }
}
