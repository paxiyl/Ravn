package keystrokesmod.client.event.impl;

import keystrokesmod.client.event.types.CancellableEvent;

public final class JumpEvent extends CancellableEvent {
    private float yaw;
    private double motion;

    public JumpEvent(float yaw, double motion) {
        this.yaw = yaw;
        this.motion = motion;
    }

    public float getYaw() {
        return yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public double getMotion() {
        return motion;
    }

    public void setMotion(double motion) {
        this.motion = motion;
    }
}
