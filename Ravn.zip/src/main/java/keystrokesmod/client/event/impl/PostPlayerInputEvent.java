package keystrokesmod.client.event.impl;

import keystrokesmod.client.event.types.Event;

/**
 * Fires in MixinEntityPlayerSP.onLivingUpdate() immediately after
 * movementInput.updatePlayerMoveState() but BEFORE sprint logic and
 * super.onLivingUpdate(). Matches NeverBeBanned's onPostPlayerInput() timing.
 *
 * Use this to override movementInput before sprint/movement processing.
 */
public class PostPlayerInputEvent extends Event {
}
