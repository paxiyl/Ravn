package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ModelBiped.class)
public abstract class MixinModelBiped {

    @Shadow
    public ModelRenderer bipedRightArm;

    @Shadow
    public ModelRenderer bipedLeftArm;

    @Inject(
            method = "setRotationAngles",
            at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/model/ModelRenderer;rotateAngleY:F", shift = At.Shift.AFTER, ordinal = 0)
    )
    private void animatium$reAssignArmPosition(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn, CallbackInfo ci) {
        if (Animations.isActive() && Animations.oldArmPosition.isToggled()) {
            this.bipedRightArm.rotateAngleY = 0.0f;
        }
    }

    @Redirect(method = "setRotationAngles", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/model/ModelRenderer;rotateAngleZ:F", ordinal = 0))
    private void animatium$removeField(ModelRenderer instance, float value) {
        if (!Animations.isActive() || !Animations.wackyArms.isToggled()) {
            this.bipedRightArm.rotateAngleZ = 0.0f;
        }
    }

    @Redirect(method = "setRotationAngles", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/model/ModelRenderer;rotateAngleZ:F", ordinal = 1))
    private void animatium$removeField2(ModelRenderer instance, float value) {
        if (!Animations.isActive() || !Animations.wackyArms.isToggled()) {
            this.bipedLeftArm.rotateAngleZ = 0.0f;
        }
    }

    @Redirect(method = "setRotationAngles", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/model/ModelRenderer;rotateAngleZ:F", ordinal = 2))
    private void animatium$removeField3(ModelRenderer instance, float value) {
        if (!Animations.isActive() || !Animations.wackyArms.isToggled()) {
            this.bipedRightArm.rotateAngleZ = 0.0f;
        }
    }

    @Inject(method = "setRotationAngles", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/MathHelper;cos(F)F", ordinal = 2))
    private void animatium$wackyArms(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn, CallbackInfo ci) {
        if (Animations.isActive() && Animations.wackyArms.isToggled()) {
            this.bipedRightArm.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 2.0F * limbSwingAmount;
            this.bipedRightArm.rotateAngleZ = (MathHelper.cos(limbSwing * 0.2312F) + 1.0F) * 1.0F * limbSwingAmount;
            this.bipedLeftArm.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 2.0F * limbSwingAmount;
            this.bipedLeftArm.rotateAngleZ = (MathHelper.cos(limbSwing * 0.2812F) - 1.0F) * 1.0F * limbSwingAmount;
        }
    }
}
