package keystrokesmod.client.mixin.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Java port of Animatium's SwingHook.kt.
 * Forces hand swing with proper duration check.
 */
public final class SwingHelper {

    private SwingHelper() {
    }

    public static void swingHand() {
        EntityPlayer player = Minecraft.getMinecraft().thePlayer;
        if (player == null) return;

        if (!player.isSwingInProgress || player.swingProgressInt < 0) {
            player.swingProgressInt = -1;
            player.isSwingInProgress = true;
        }
    }
}
