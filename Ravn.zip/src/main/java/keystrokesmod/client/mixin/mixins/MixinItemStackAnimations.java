package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class MixinItemStackAnimations {

    @Inject(method = "getIsItemStackEqual", at = @At("RETURN"), cancellable = true)
    private void animatium$modifyReequip(ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
        if (Animations.isActive() && Animations.itemSwitchMode.getMode() == Animations.ItemSwitchMode.V1_7) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) {
                int currentItem = mc.thePlayer.inventory.currentItem;
                cir.setReturnValue(cir.getReturnValue());
            }
        }
    }
}
