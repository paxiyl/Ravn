package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumAction;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MixinMinecraftAnimations {

    @Shadow
    public MovingObjectPosition objectMouseOver;

    @Shadow
    public EffectRenderer effectRenderer;

    @Shadow
    public EntityPlayerSP thePlayer;

    @Shadow
    public WorldClient theWorld;

    @Shadow
    private int leftClickCounter;

    @Shadow
    public GameSettings gameSettings;

    @Shadow
    public EntityRenderer entityRenderer;

    @Shadow
    public PlayerControllerMP playerController;

    @Inject(method = "sendClickBlockToController", at = @At("HEAD"))
    private void animatium$blockHitAnimation(boolean leftClick, CallbackInfo ci) {
        if (!Animations.isActive() || !Animations.oldBlockhitting.isToggled()) return;
        if (this.thePlayer == null) return;

        boolean allowedUsage = Animations.usagePunching.isToggled()
                && this.thePlayer.getHeldItem() != null
                && this.thePlayer.isUsingItem()
                && this.gameSettings.keyBindAttack.isKeyDown();

        if (!allowedUsage) return;

        MovingObjectPosition object = this.objectMouseOver;
        if (object != null && object.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            BlockPos blockPos = object.getBlockPos();
            if (Animations.usagePunchingParticles.isToggled() && this.theWorld != null && !this.theWorld.isAirBlock(blockPos)) {
                this.effectRenderer.addBlockHitEffects(blockPos, object.sideHit);
            }
            SwingHelper.swingHand();
        }
    }

    @Inject(method = "clickMouse", at = @At(value = "TAIL"))
    private void animatium$onHitParticles(CallbackInfo ci) {
        if (!Animations.isActive() || this.leftClickCounter <= 0) return;

        if (Animations.fakeMissPenaltyParticles.isToggled() && this.objectMouseOver != null
                && this.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY
                && this.objectMouseOver.entityHit instanceof EntityLivingBase) {
            if (this.thePlayer.fallDistance > 0.0F && !this.thePlayer.onGround
                    && !this.thePlayer.isOnLadder() && !this.thePlayer.isInWater()
                    && !this.thePlayer.isPotionActive(Potion.blindness)
                    && this.thePlayer.ridingEntity == null) {
                this.thePlayer.onCriticalHit(this.objectMouseOver.entityHit);
            }
        }

        if (Animations.fakeMissPenaltySwing.isToggled()) {
            SwingHelper.swingHand();
        }
    }

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/settings/KeyBinding;isPressed()Z", ordinal = 7))
    private void animatium$fakeBlockHit(CallbackInfo ci) {
        if (Animations.isActive() && Animations.fakeBlockHit.isToggled()) {
            while (this.gameSettings.keyBindAttack.isPressed()) {
                SwingHelper.swingHand();
            }
        }
    }

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;dropOneItem(Z)Lnet/minecraft/entity/item/EntityItem;", shift = At.Shift.AFTER))
    private void animatium$dropItemSwing(CallbackInfo ci) {
        if (Animations.isActive() && Animations.modernDropSwing.isToggled() && this.thePlayer.getHeldItem() != null) {
            SwingHelper.swingHand();
        }
    }

    @Inject(method = "rightClickMouse", at = @At(value = "HEAD"))
    private void animatium$funnyFidget(CallbackInfo ci) {
        if (Animations.isActive() && Animations.funnyFidget.isToggled()
                && this.thePlayer != null && this.thePlayer.getHeldItem() != null
                && this.thePlayer.getHeldItem().getItemUseAction() != EnumAction.NONE) {
            this.entityRenderer.itemRenderer.resetEquippedProgress();
        }
    }
}
