package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.module.modules.render.AimSmooth;
import net.minecraft.util.MouseHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks MouseHelper.mouseXYChange() to intercept raw deltaX/deltaY
 * and pass them through AimSmooth's exponential smoothing filter.
 * <p>
 * This runs inside the synchronized block, so the filtered values
 * are atomically visible to whoever reads deltaX/deltaY afterward.
 */
@Mixin(MouseHelper.class)
public class MixinMouseHelper {

    @Shadow
    private int deltaX;

    @Shadow
    private int deltaY;

    @Inject(method = "mouseXYChange", at = @At("RETURN"))
    private void onXYChange(CallbackInfo ci) {
        int[] filtered = AimSmooth.onMouseDelta(deltaX, deltaY);
        deltaX = filtered[0];
        deltaY = filtered[1];
    }
}
