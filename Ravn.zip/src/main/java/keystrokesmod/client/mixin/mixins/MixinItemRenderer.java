package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.modules.combat.KillAura;
import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(net.minecraft.client.renderer.ItemRenderer.class)
public abstract class MixinItemRenderer {

    @Shadow @Final private Minecraft mc;
    @Shadow private float equippedProgress;
    @Shadow private float prevEquippedProgress;
    @Shadow private ItemStack itemToRender;

    @Shadow protected abstract void transformFirstPersonItem(float equipProgress, float swingProgress);
    @Shadow protected abstract void func_178101_a(float angle, float angleY);
    @Shadow protected abstract void renderItemMap(AbstractClientPlayer clientPlayer, float pitch, float equipmentProgress, float swingProgress);
    @Shadow protected abstract void func_178109_a(AbstractClientPlayer clientPlayer);
    @Shadow protected abstract void func_178110_a(EntityPlayerSP entityplayerspIn, float partialTicks);
    @Shadow protected abstract void func_178104_a(AbstractClientPlayer clientPlayer, float partialTicks);
    @Shadow protected abstract void func_178098_a(float partialTicks, AbstractClientPlayer clientPlayer);
    @Shadow protected abstract void func_178105_d(float swingProgress);
    @Shadow public abstract void renderItem(EntityLivingBase entityIn, ItemStack heldStack, ItemCameraTransforms.TransformType transform);
    @Shadow protected abstract void func_178095_a(AbstractClientPlayer clientPlayer, float equipProgress, float swingProgress);

    @Unique
    private void doSwordBlockAnimation() {
        GlStateManager.translate(-0.5F, 0.4F, -0.1F);
        GlStateManager.rotate(30.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-80.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(60.0F, 0.0F, 1.0F, 0.0F);
    }

    @Unique
    private static void animatium$applyItemTransforms() {
        final float scale = 0.8823529411764706F;
        GlStateManager.scale(scale, scale, scale);
        GlStateManager.rotate(5.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.translate(-0.29F, 0.149F, -0.0328F);
    }

    /**
     * @author Cosmic
     * @reason fake autoblock + 1.7 animations from Animatium
     */
    @Overwrite
    public void renderItemInFirstPerson(float partialTicks) {
        try {
            float f = 1.0F - (this.prevEquippedProgress + (this.equippedProgress - this.prevEquippedProgress) * partialTicks);
            EntityPlayerSP player = this.mc.thePlayer;
            float f1 = player.getSwingProgress(partialTicks);
            float f2 = player.prevRotationPitch + (player.rotationPitch - player.prevRotationPitch) * partialTicks;
            float f3 = player.prevRotationYaw + (player.rotationYaw - player.prevRotationYaw) * partialTicks;
            this.func_178101_a(f2, f3);
            this.func_178109_a(player);
            this.func_178110_a(player, partialTicks);
            GlStateManager.enableRescaleNormal();
            GlStateManager.pushMatrix();

            if (this.itemToRender != null) {
                if (this.itemToRender.getItem() instanceof ItemMap) {
                    this.renderItemMap(player, f2, f, f1);
                } else if (player.getItemInUseCount() > 0 || (itemToRender.getItem() instanceof ItemSword && KillAura.blockMode.getMode() == KillAura.BlockMode.Fake && KillAura.getTraget() != null && Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())) {
                    EnumAction action = this.itemToRender.getItemUseAction();
                    switch (action) {
                        case NONE:
                            this.transformFirstPersonItem(f, 0.0F);
                            break;
                        case EAT:
                        case DRINK:
                            this.func_178104_a(player, partialTicks);
                            this.transformFirstPersonItem(f, f1);
                            break;
                        case BLOCK:
                            this.transformFirstPersonItem(f, f1);
                            this.doSwordBlockAnimation();
                            break;
                        case BOW:
                            this.transformFirstPersonItem(f, f1);
                            this.func_178098_a(partialTicks, player);
                    }
                } else {
                    this.func_178105_d(f1);
                    this.transformFirstPersonItem(f, f1);
                }

                if (Animations.isActive() && !Animations.lunarPositions.isToggled()
                        && !(this.itemToRender.getItem() instanceof ItemSword && Animations.lunarBlockhit.isToggled())) {
                    animatium$applyItemTransforms();
                }

                this.renderItem(player, this.itemToRender, ItemCameraTransforms.TransformType.FIRST_PERSON);
            } else if (!player.isInvisible()) {
                this.func_178095_a(player, f, f1);
            }

            GlStateManager.popMatrix();
            GlStateManager.disableRescaleNormal();
            RenderHelper.disableStandardItemLighting();
        } catch (Exception e) {
        }
    }
}
