package keystrokesmod.client.mixin.mixins;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.modules.combat.KillAura;
import keystrokesmod.client.module.modules.other.Animations;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.*;
import net.minecraft.util.MathHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public abstract class MixinItemRenderer {

    @Shadow @Final private Minecraft mc;
    @Shadow private float equippedProgress;
    @Shadow private float prevEquippedProgress;
    @Shadow private ItemStack itemToRender;
    @Shadow private int equippedItemSlot;
    @Shadow @Final private RenderItem itemRenderer;

    @Shadow protected abstract void transformFirstPersonItem(float equipProgress, float swingProgress);
    @Shadow protected abstract void func_178101_a(float angle, float angleY);
    @Shadow protected abstract void renderItemMap(AbstractClientPlayer clientPlayer, float pitch, float equipmentProgress, float swingProgress);
    @Shadow protected abstract void func_178109_a(AbstractClientPlayer clientPlayer);
    @Shadow protected abstract void func_178110_a(EntityPlayerSP entityplayerspIn, float partialTicks);
    @Shadow protected abstract void func_178104_a(AbstractClientPlayer clientPlayer, float partialTicks);
    @Shadow protected abstract void func_178098_a(float partialTicks, AbstractClientPlayer clientPlayer);
    @Shadow protected abstract void func_178105_d(float swingProgress);
    @Shadow public abstract void renderItem(EntityLivingBase entityIn, ItemStack heldStack, ItemCameraTransforms.TransformType transform);
    @Shadow protected abstract void func_178095_a(AbstractClientPlayer clientPlayer, float equipProgress, float swingProgress);

    @Unique
    private void doSwordBlockAnimation() {
        GlStateManager.translate(-0.5F, 0.4F, -0.1F);
        GlStateManager.rotate(30.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-80.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(60.0F, 0.0F, 1.0F, 0.0F);
    }

    @Unique
    private static void animatium$applyItemTransforms() {
        final float scale = 0.8823529411764706F;
        GlStateManager.scale(scale, scale, scale);
        GlStateManager.rotate(5.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.translate(-0.29F, 0.149F, -0.0328F);
    }

    @Inject(method = "transformFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void animatium$itemTransform(final float equipProgress, final float swingProgress, final CallbackInfo ci) {
        if (!Animations.isActive()) return;
        final Item item = this.itemToRender.getItem();

        if (Animations.lunarPositions.isToggled() && item != null) {
            if (item instanceof ItemSword) {
                GlStateManager.translate(0.0F, 0.0F, -0.02F);
                GlStateManager.rotate(1.0F, 0.0F, 0.0F, -0.1F);
            } else if (item instanceof ItemPotion) {
                GlStateManager.translate(-0.0225F, -0.02F, 0.0F);
                GlStateManager.rotate(1.0F, 0.0F, 0.0F, 0.1F);
            } else if (item instanceof ItemFishingRod || item instanceof ItemCarrotOnAStick) {
                GlStateManager.translate(0.08F, -0.0275F, -0.33F);
                GlStateManager.scale(0.949999988079071D, 1.0D, 1.0D);
            } else if (item instanceof ItemBow) {
                GlStateManager.rotate(0.9F, 0.0F, 0.001F, 0.0F);
            } else if (item instanceof ItemBlock) {
                Block block = ((ItemBlock) item).getBlock();
                if (block instanceof BlockCarpet || block instanceof BlockSnow) {
                    GlStateManager.translate(0.0F, -0.25F, 0.0F);
                }
            }
        }

        if (Animations.globalPositions.isToggled()) {
            GlStateManager.translate(0.56f * (1.0F + (float) Animations.itemPositionX.getInput()), -0.52f * (1.0F - (float) Animations.itemPositionY.getInput()), -0.72f * (1.0F + (float) Animations.itemPositionZ.getInput()));
            GlStateManager.translate(0.0f, equipProgress * -0.6f, 0.0f);
            GlStateManager.rotate((float) Animations.itemRotationPitch.getInput(), 1.0f, 0.0f, 0.0f);
            GlStateManager.rotate((float) Animations.itemRotationYaw.getInput(), 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate((float) Animations.itemRotationRoll.getInput(), 0.0f, 0.0f, 1.0f);
            GlStateManager.rotate(45.0f, 0.0f, 1.0f, 0.0f);
            float f = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
            float f1 = MathHelper.sin(MathHelper.sqrt_float(swingProgress) * (float) Math.PI);
            GlStateManager.rotate(f * -20.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(f1 * -20.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.rotate(f1 * -80.0f, 1.0f, 0.0f, 0.0f);
            double scale = 0.4f * Math.exp((float) Animations.itemScale.getInput());
            GlStateManager.scale(scale, scale, scale);
            ci.cancel();
        }
    }

    @Inject(method = "doItemUsedTransformations", at = @At("HEAD"), cancellable = true)
    private void animatium$swingTransformations(final float swingProgress, final CallbackInfo ci) {
        if (Animations.isActive() && Animations.globalPositions.isToggled()) {
            if (Animations.swingSetting.getMode() == Animations.SwingSetting.DISABLE_TRANSLATION) {
                ci.cancel();
            } else {
                final float scale = (1.0F + (Animations.swingSetting.getMode() == Animations.SwingSetting.SMART_SCALING ? (float) Animations.itemScale.getInput() : 0.0F));
                final float f = (-0.4f * (1.0F + (float) Animations.blockedPositionX.getInput())) * MathHelper.sin(MathHelper.sqrt_float(swingProgress) * (float) Math.PI) * scale;
                final float f1 = 0.2f * (1.0F - (float) Animations.blockedPositionY.getInput()) * MathHelper.sin(MathHelper.sqrt_float(swingProgress) * (float) Math.PI * 2.0f) * scale;
                final float f2 = -0.2f * (1.0F + (float) Animations.blockedPositionZ.getInput()) * MathHelper.sin(swingProgress * (float) Math.PI) * scale;
                GlStateManager.translate(f, f1, f2);
                ci.cancel();
            }
        }
    }

    @Inject(method = "doBlockTransformations", at = @At("HEAD"), cancellable = true)
    private void animatium$blockedItemTransform(final CallbackInfo ci) {
        if (Animations.isActive() && Animations.globalPositions.isToggled()) {
            GlStateManager.translate(-0.5f * (1.0F + (float) Animations.blockedPositionX.getInput()), 0.2f * (1.0F + (float) Animations.blockedPositionY.getInput()), 0.0f + (float) Animations.blockedPositionZ.getInput());
            GlStateManager.rotate((float) Animations.blockedRotationPitch.getInput(), 1.0f, 0.0f, 0.0f);
            GlStateManager.rotate((float) Animations.blockedRotationYaw.getInput(), 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate((float) Animations.blockedRotationRoll.getInput(), 0.0f, 0.0f, 1.0f);
            GlStateManager.rotate(30.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(-80.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.rotate(60.0f, 0.0f, 1.0f, 0.0f);
            if (Animations.lunarBlockhit.isToggled()) {
                GlStateManager.translate(-0.55F, 0.2F, 0.1F);
                GlStateManager.scale(0.85F, 0.85F, 0.85F);
                GlStateManager.rotate(1.0F, 0.0F, 0.0F, -1.0F);
                GlStateManager.rotate(1.0F, 0.25F, 0.0F, 0.0F);
                GlStateManager.rotate(2.0F, 0.0F, 2.0F, 0.0F);
            }
            final double scale = 1.0f * Math.exp((float) Animations.blockedScale.getInput());
            GlStateManager.scale(scale, scale, scale);
            ci.cancel();
        }
    }

    @Inject(method = "doBlockTransformations", at = @At("RETURN"))
    private void animatium$lunarTransform(final CallbackInfo ci) {
        if (Animations.isActive() && Animations.lunarBlockhit.isToggled() && !Animations.globalPositions.isToggled()) {
            GlStateManager.translate(-0.55F, 0.2F, 0.1F);
            GlStateManager.scale(0.85F, 0.85F, 0.85F);
            GlStateManager.rotate(1.0F, 0.0F, 0.0F, -1.0F);
            GlStateManager.rotate(1.0F, 0.25F, 0.0F, 0.0F);
            GlStateManager.rotate(2.0F, 0.0F, 2.0F, 0.0F);
        }
    }

    @Inject(method = "performDrinking", at = @At("HEAD"), cancellable = true)
    private void animatium$drinkingItemTransform(final AbstractClientPlayer clientPlayer, final float tickDelta, final CallbackInfo ci) {
        if (Animations.isActive() && Animations.globalPositions.isToggled()) {
            float f = (float) clientPlayer.getItemInUseCount() - tickDelta + 1.0f;
            float f1 = f / (float) this.itemToRender.getMaxItemUseDuration();
            float f2 = MathHelper.abs(MathHelper.cos(f / 4.0f * (float) Math.PI) * 0.1f);
            if (f1 >= 0.8f) f2 = 0.0f;

            float posX = 0.56f * (1.0F + (float) Animations.itemPositionX.getInput());
            float posY = -0.52f * (1.0F - (float) Animations.itemPositionY.getInput());
            float posZ = -0.72f * (1.0F + (float) Animations.itemPositionZ.getInput());
            if (Animations.shouldScaleEat.isToggled()) {
                GlStateManager.translate(-0.56f, 0.52f, 0.72f);
                GlStateManager.translate(posX, posY, posZ);
            }

            GlStateManager.translate((float) Animations.consumePositionX.getInput(), (float) Animations.consumePositionY.getInput(), (float) Animations.consumePositionZ.getInput());
            GlStateManager.translate(0.0f, f2 * (1.0F + (float) Animations.consumeIntensity.getInput()), 0.0f);
            float f3 = 1.0f - (float) Math.pow(f1, 27.0f * (1.0F + (float) Animations.consumeSpeed.getInput()));
            GlStateManager.translate(f3 * 0.6f, f3 * -0.5f, f3 * 0.0f);
            GlStateManager.rotate((float) Animations.consumeRotationPitch.getInput(), 1.0f, 0.0f, 0.0f);
            GlStateManager.rotate((float) Animations.consumeRotationYaw.getInput(), 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate((float) Animations.consumeRotationRoll.getInput(), 0.0f, 0.0f, 1.0f);
            GlStateManager.rotate(f3 * 90.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(f3 * 10.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.rotate(f3 * 30.0f, 0.0f, 0.0f, 1.0f);
            if (Animations.shouldScaleEat.isToggled()) {
                GlStateManager.translate(0.56f, -0.52f, -0.72f);
                GlStateManager.translate(-posX, -posY, -posZ);
            }

            ci.cancel();
        }
    }

    @Inject(method = "doBowTransformations", at = @At("HEAD"))
    private void animatium$lunarBowPosition(final float tickDelta, final AbstractClientPlayer clientPlayer, final CallbackInfo ci) {
        if (Animations.isActive() && Animations.lunarPositions.isToggled()) {
            GlStateManager.translate(-0.2D, 0.0D, -0.175D);
            GlStateManager.rotate(1.0F, 0.0F, 0.0F, -1.25F);
        }
    }

    @Inject(method = "doBowTransformations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;scale(FFF)V"))
    private void animatium$preBowTransform(final float tickDelta, final AbstractClientPlayer clientPlayer, final CallbackInfo ci) {
        if (Animations.isActive() && Animations.firstPersonItemPositions.isToggled() && !Animations.lunarPositions.isToggled()) {
            GlStateManager.rotate(-335.0F, 0.0F, 0.0F, 1.0F);
            GlStateManager.rotate(-50.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.translate(0.0F, 0.5F, 0.0F);
        }
    }

    @Inject(method = "doBowTransformations", at = @At("RETURN"))
    private void animatium$postBowTransform(final float tickDelta, final AbstractClientPlayer clientPlayer, final CallbackInfo ci) {
        if (Animations.isActive() && Animations.firstPersonItemPositions.isToggled() && !Animations.lunarPositions.isToggled()) {
            GlStateManager.translate(0.0F, -0.5F, 0.0F);
            GlStateManager.rotate(50.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(335.0F, 0.0F, 0.0F, 1.0F);
        }
    }

    @Inject(method = "updateEquippedItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemRenderer;resetEquippedProgress()V"))
    private void animatium$onEquipReset(final CallbackInfo ci) {
        if (Animations.isActive() && Animations.itemSwitchMode.getMode() == Animations.ItemSwitchMode.DISABLED) {
            final EntityPlayer player = this.mc.thePlayer;
            this.itemToRender = player.inventory.getCurrentItem();
            this.equippedItemSlot = player.inventory.currentItem;
        }
    }

    /**
     * @author Cosmic
     * @reason fake autoblock + 1.7 animations
     */
    @Overwrite
    public void renderItemInFirstPerson(float partialTicks) {
        try {
            float f = 1.0F - (this.prevEquippedProgress + (this.equippedProgress - this.prevEquippedProgress) * partialTicks);
            EntityPlayerSP player = this.mc.thePlayer;
            float f1 = player.getSwingProgress(partialTicks);
            float f2 = player.prevRotationPitch + (player.rotationPitch - player.prevRotationPitch) * partialTicks;
            float f3 = player.prevRotationYaw + (player.rotationYaw - player.prevRotationYaw) * partialTicks;
            this.func_178101_a(f2, f3);
            this.func_178109_a(player);
            this.func_178110_a(player, partialTicks);
            GlStateManager.enableRescaleNormal();
            GlStateManager.pushMatrix();

            if (this.itemToRender != null) {
                if (this.itemToRender.getItem() instanceof ItemMap) {
                    this.renderItemMap(player, f2, f, f1);
                } else if (player.getItemInUseCount() > 0 || (itemToRender.getItem() instanceof ItemSword && KillAura.blockMode.getMode() == KillAura.BlockMode.Fake && KillAura.getTraget() != null && Raven.moduleManager.getModuleByClazz(KillAura.class).isEnabled())) {
                    EnumAction action = this.itemToRender.getItemUseAction();
                    switch (action) {
                        case NONE:
                            this.transformFirstPersonItem(f, 0.0F);
                            break;
                        case EAT:
                        case DRINK:
                            this.func_178104_a(player, partialTicks);
                            this.transformFirstPersonItem(f, f1);
                            break;
                        case BLOCK:
                            this.transformFirstPersonItem(f, f1);
                            this.doSwordBlockAnimation();
                            break;
                        case BOW:
                            this.transformFirstPersonItem(f, f1);
                            this.func_178098_a(partialTicks, player);
                    }
                } else {
                    this.func_178105_d(f1);
                    this.transformFirstPersonItem(f, f1);
                }

                if (Animations.isActive() && !Animations.lunarPositions.isToggled()
                        && !this.itemRenderer.shouldRenderItemIn3D(this.itemToRender)) {
                    if (Animations.firstPersonFishingRodPosition.isToggled()
                            && this.itemToRender.getItem().shouldRotateAroundWhenRendering()) {
                        GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
                        animatium$applyItemTransforms();
                    } else if (Animations.firstPersonItemPositions.isToggled()
                            && !(this.itemToRender.getItem() instanceof ItemSword && Animations.lunarBlockhit.isToggled())) {
                        animatium$applyItemTransforms();
                    }
                }

                this.renderItem(player, this.itemToRender, ItemCameraTransforms.TransformType.FIRST_PERSON);
            } else if (!player.isInvisible()) {
                this.func_178095_a(player, f, f1);
            }

            GlStateManager.popMatrix();
            GlStateManager.disableRescaleNormal();
            RenderHelper.disableStandardItemLighting();
        } catch (Exception e) {
        }
    }
}
