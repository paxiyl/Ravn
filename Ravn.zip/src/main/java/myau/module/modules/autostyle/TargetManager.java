package myau.module.modules.autostyle;

import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.Vec3;

public class TargetManager {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public enum TargetPriority {
        DISTANCE, HEALTH, HURT_TIME, ANGLE, COMBO_LOCK
    }

    public enum TargetPoint {
        CENTER, CHEST, HEAD, RANDOMIZED_BODY, DYNAMIC
    }

    private EntityPlayer lockedTarget;
    private int lockedTargetId = -1;
    private long lockStartTime = 0;
    private int lastHurtTime = 0;
    private int comboCount = 0;

    public void reset() {
        lockedTarget = null;
        lockedTargetId = -1;
        lockStartTime = 0;
        lastHurtTime = 0;
        comboCount = 0;
    }

    public EntityPlayer findTarget(double range, double fov, boolean playersOnly, boolean los, TargetPriority priority) {
        List<EntityPlayer> candidates = new ArrayList<>();

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            EntityPlayer player = (EntityPlayer) entity;
            if (player == mc.thePlayer) continue;
            if (player.isDead || !player.isEntityAlive()) continue;
            if (player.isSpectator()) continue;
            if (mc.thePlayer.getDistanceToEntity(player) > range) continue;
            if (!isWithinFOV(player, fov)) continue;
            if (los && !hasLineOfSight(player)) continue;
            candidates.add(player);
        }

        if (candidates.isEmpty()) return null;

        switch (priority) {
            case COMBO_LOCK:
                if (lockedTarget != null && lockedTarget.isEntityAlive() &&
                    mc.thePlayer.getDistanceToEntity(lockedTarget) <= range &&
                    candidates.contains(lockedTarget)) {
                    return lockedTarget;
                }
                break;
            case DISTANCE:
                candidates.sort(Comparator.comparingDouble(p -> mc.thePlayer.getDistanceToEntity(p)));
                break;
            case HEALTH:
                candidates.sort(Comparator.comparingDouble(p -> p.getHealth()));
                break;
            case HURT_TIME:
                candidates.sort(Comparator.comparingDouble(p -> -p.hurtTime));
                break;
            case ANGLE:
                candidates.sort(Comparator.comparingDouble(p -> Math.abs(getYawError(p))));
                break;
        }

        return candidates.get(0);
    }

    public EntityPlayer getLockedTarget() {
        if (lockedTarget != null && (!lockedTarget.isEntityAlive() || lockedTarget.isDead)) {
            lockedTarget = null;
            lockedTargetId = -1;
        }
        return lockedTarget;
    }

    public void lockTarget(EntityPlayer target) {
        if (target != null && target != lockedTarget) {
            lockedTarget = target;
            lockedTargetId = target.getEntityId();
            lockStartTime = System.nanoTime();
            lastHurtTime = target.hurtTime;
            comboCount = 0;
        }
    }

    public void updateCombo() {
        if (lockedTarget == null) return;
        if (lockedTarget.hurtTime > 0 && lastHurtTime == 0) {
            comboCount++;
        }
        lastHurtTime = lockedTarget.hurtTime;
    }

    public int getComboCount() {
        return comboCount;
    }

    public Vec3 getTargetPoint(EntityPlayer target, TargetPoint point, long timeNanos) {
        if (target == null) return null;

        double x = target.posX;
        double y;
        double z = target.posZ;

        switch (point) {
            case HEAD:
                y = target.posY + target.getEyeHeight();
                break;
            case CHEST:
                y = target.posY + target.getEyeHeight() * 0.5;
                break;
            case CENTER:
                y = target.posY + target.height * 0.5;
                break;
            case RANDOMIZED_BODY:
                double noise = Math.sin(timeNanos * 0.0000001) * 0.15;
                y = target.posY + target.getEyeHeight() * (0.4 + noise);
                break;
            case DYNAMIC:
                double targetVelAngle = Math.atan2(target.motionZ, target.motionX);
                double offset = Math.sin(targetVelAngle) * 0.1;
                x += offset;
                y = target.posY + target.getEyeHeight() * 0.55;
                z += Math.cos(targetVelAngle) * 0.1;
                break;
            default:
                y = target.posY + target.getEyeHeight() * 0.5;
                break;
        }

        return new Vec3(x, y, z);
    }

    public Rotation getRotationToTarget(EntityPlayer target, TargetPoint point, double predictionTime, long timeNanos) {
        if (target == null || mc.thePlayer == null) return null;

        Vec3 targetPoint = getTargetPoint(target, point, timeNanos);
        if (targetPoint == null) return null;

        double px = targetPoint.xCoord + target.motionX * predictionTime;
        double py = targetPoint.yCoord + target.motionY * predictionTime;
        double pz = targetPoint.zCoord + target.motionZ * predictionTime;

        double dx = px - mc.thePlayer.posX;
        double dy = py - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pz - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));

        return new Rotation(yaw, Rotation.clampPitch(pitch));
    }

    public float getYawError(EntityPlayer target) {
        Rotation rot = getRotationToTarget(target, TargetPoint.CENTER, 0.0, System.nanoTime());
        if (rot == null) return 0.0F;
        return Rotation.angleDiff(mc.thePlayer.rotationYaw, rot.yaw);
    }

    private boolean isWithinFOV(EntityPlayer target, double fov) {
        float yawError = Math.abs(getYawError(target));
        return yawError <= fov / 2.0;
    }

    private boolean hasLineOfSight(EntityPlayer target) {
        if (mc.thePlayer == null || target == null) return false;
        Vec3 eyePos = new Vec3(
            mc.thePlayer.posX,
            mc.thePlayer.posY + mc.thePlayer.getEyeHeight(),
            mc.thePlayer.posZ
        );
        Vec3 targetPos = new Vec3(
            target.posX,
            target.posY + target.getEyeHeight() * 0.5,
            target.posZ
        );
        return mc.theWorld.rayTraceBlocks(eyePos, targetPos) == null;
    }
}
