package myau.module.modules.autostyle;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.Minecraft;

public class MovementAnalyzer {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public enum StrafeDirection {
        NONE, LEFT, RIGHT, FORWARD, BACKWARD
    }

    public static StrafeDirection getPlayerStrafe() {
        if (mc.thePlayer == null) return StrafeDirection.NONE;

        float forward = 0.0F;
        float strafe = 0.0F;

        if (mc.gameSettings.keyBindForward.isKeyDown()) forward += 1.0F;
        if (mc.gameSettings.keyBindBack.isKeyDown()) forward -= 1.0F;
        if (mc.gameSettings.keyBindLeft.isKeyDown()) strafe += 1.0F;
        if (mc.gameSettings.keyBindRight.isKeyDown()) strafe -= 1.0F;

        if (strafe > 0) return StrafeDirection.LEFT;
        if (strafe < 0) return StrafeDirection.RIGHT;
        if (forward > 0) return StrafeDirection.FORWARD;
        if (forward < 0) return StrafeDirection.BACKWARD;
        return StrafeDirection.NONE;
    }

    public static double getHorizontalVelocity() {
        if (mc.thePlayer == null) return 0.0;
        return Math.sqrt(
            mc.thePlayer.motionX * mc.thePlayer.motionX +
            mc.thePlayer.motionZ * mc.thePlayer.motionZ
        );
    }

    public static double getTargetHorizontalVelocity(EntityPlayer target) {
        if (target == null) return 0.0;
        return Math.sqrt(
            target.motionX * target.motionX +
            target.motionZ * target.motionZ
        );
    }

    public static float getTargetMoveAngle(EntityPlayer target) {
        if (target == null) return 0.0F;
        return (float) Math.toDegrees(Math.atan2(target.motionZ, target.motionX));
    }

    public static float getRelativeAngleToTarget(EntityPlayer target) {
        if (mc.thePlayer == null || target == null) return 0.0F;
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        float angleToTarget = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        return Rotation.angleDiff(mc.thePlayer.rotationYaw, angleToTarget);
    }

    public static boolean isPlayerStrafing() {
        return mc.gameSettings.keyBindLeft.isKeyDown() ||
               mc.gameSettings.keyBindRight.isKeyDown();
    }

    public static boolean isPlayerMoving() {
        return mc.gameSettings.keyBindForward.isKeyDown() ||
               mc.gameSettings.keyBindBack.isKeyDown() ||
               mc.gameSettings.keyBindLeft.isKeyDown() ||
               mc.gameSettings.keyBindRight.isKeyDown();
    }

    public static float predictTargetYaw(EntityPlayer target, double predictionTime) {
        if (target == null) return 0.0F;
        double px = target.posX + target.motionX * predictionTime;
        double pz = target.posZ + target.motionZ * predictionTime;
        double dx = px - mc.thePlayer.posX;
        double dz = pz - mc.thePlayer.posZ;
        return (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
    }

    public static float predictTargetPitch(EntityPlayer target, double predictionTime) {
        if (target == null) return 0.0F;
        double px = target.posX + target.motionX * predictionTime;
        double py = target.posY + target.getEyeHeight() + target.motionY * predictionTime;
        double pz = target.posZ + target.motionZ * predictionTime;
        double dx = px - mc.thePlayer.posX;
        double dy = py - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = pz - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return (float) (-Math.toDegrees(Math.atan2(dy, dist)));
    }

    public static boolean shouldAlternateDirection(boolean lastWasLeft, double variation) {
        double r = Math.random();
        if (r < 0.5 - variation * 0.3) return !lastWasLeft;
        if (r > 0.5 + variation * 0.3) return lastWasLeft;
        return Math.random() < 0.5;
    }
}
