package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.ItemUtil;
import myau.util.PlayerUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Mouse;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AimAssist extends Module {
    private static final Minecraft MC = Minecraft.getMinecraft();

    public final FloatProperty hSpeed = new FloatProperty("horizontal-speed", 3.0F, 0.0F, 10.0F);
    public final FloatProperty vSpeed = new FloatProperty("vertical-speed", 0.0F, 0.0F, 10.0F);
    public final IntProperty smoothing = new IntProperty("smoothing", 50, 0, 100);
    public final FloatProperty range = new FloatProperty("range", 4.5F, 3.0F, 8.0F);
    public final IntProperty fov = new IntProperty("fov", 90, 30, 360);
    public final BooleanProperty clickAim = new BooleanProperty("only-while-clicking", true);
    public final BooleanProperty comboAim = new BooleanProperty("combo-auto-aim", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("weapons-only", true);
    public final BooleanProperty allowTools = new BooleanProperty("allow-tools", false, () -> weaponOnly.getValue());
    public final BooleanProperty botChecks = new BooleanProperty("bot-check", true);
    public final BooleanProperty team = new BooleanProperty("teams", true);

    private EntityPlayer comboTarget;
    private int comboCount;
    private int prevComboTargetHurtTime;
    private float prevComboDistance;
    private boolean comboAimActive;
    private EntityPlayer activeTarget;
    private double smoothPointX, smoothPointZ;
    private boolean hasSmoothPoint;
    private double targetVelX, targetVelZ;
    private double velYaw, velPitch;
    private long lastFrameNanos = -1L;
    private long manualHoldNanos;
    private float blend = 1.0F;
    private float lastAppliedYaw, lastAppliedPitch;
    private boolean hasLastApplied;

    public AimAssist() { super("AimAssist", false); }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || !(event.getTarget() instanceof EntityPlayer) || MC.thePlayer == null) return;
        EntityPlayer target = (EntityPlayer) event.getTarget();
        if (target == MC.thePlayer) return;
        if (comboTarget != target) {
            comboTarget = target;
            comboCount = 0;
            prevComboTargetHurtTime = target.hurtTime;
            prevComboDistance = MC.thePlayer.getDistanceToEntity(target);
            comboAimActive = false;
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!isEnabled() || event.getType() != EventType.PRE || MC.thePlayer == null || MC.theWorld == null || MC.currentScreen != null) {
            if (!isEnabled()) resetTracking();
            return;
        }
        updateComboState();
        if (!shouldAssist()) { resetAimOnly(); return; }
        updateTarget();
        if (activeTarget == null) { resetAimOnly(); return; }
        applyAim();
    }

    private void updateComboState() {
        if (!comboAim.getValue() || comboTarget == null) { resetCombo(); return; }
        if (MC.thePlayer.hurtTime > 0 || comboTarget.isDead || !comboTarget.isEntityAlive() || !hasLineOfSight(comboTarget)) {
            resetCombo(); return;
        }
        if (comboTarget.hurtTime > 0 && prevComboTargetHurtTime == 0) {
            comboCount++;
            comboAimActive = comboCount >= 2;
        }
        prevComboTargetHurtTime = comboTarget.hurtTime;
        float dist = MC.thePlayer.getDistanceToEntity(comboTarget);
        if (dist - prevComboDistance > 0.8F || dist > range.getValue() + 2.0F) resetCombo();
        else prevComboDistance = dist;
    }

    private boolean shouldAssist() {
        if (MC.gameSettings.keyBindUseItem.isKeyDown()) return false;
        if (weaponOnly.getValue() && !ItemUtil.hasRawUnbreakingEnchant() && !(allowTools.getValue() && ItemUtil.isHoldingTool())) return false;
        boolean comboActive = comboAim.getValue() && comboAimActive && comboTarget != null && hasLineOfSight(comboTarget);
        if (comboActive) return true; // Ravn combo mode intentionally bypasses click gating after the 2-hit combo.
        if (!clickAim.getValue()) return true;
        if (Myau.moduleManager.getModule(AutoClicker.class).isEnabled()) return false;
        return Mouse.isButtonDown(0) && !(isLookingAtBlock());
    }

    private boolean isLookingAtBlock() { return MC.objectMouseOver != null && MC.objectMouseOver.typeOfHit == MovingObjectType.BLOCK; }

    private void updateTarget() {
        if (comboAimActive && comboTarget != null && isTargetUsable(comboTarget, range.getValue() + 2.0F, fov.getValue() + 15.0F)) {
            activeTarget = comboTarget;
            return;
        }
        List<EntityPlayer> inRange = MC.theWorld.loadedEntityList.stream()
                .filter(e -> e instanceof EntityPlayer)
                .map(e -> (EntityPlayer)e)
                .filter(this::isValidTarget)
                .sorted(Comparator.comparingDouble(this::distanceTo))
                .collect(Collectors.toList());
        activeTarget = inRange.isEmpty() ? null : inRange.get(0);
        if (activeTarget != null && !hasSmoothPoint) {
            hasSmoothPoint = false;
            targetVelX = targetVelZ = 0.0D;
        }
    }

    private boolean isValidTarget(EntityPlayer p) {
        return isTargetUsable(p, range.getValue(), fov.getValue());
    }

    private boolean isTargetUsable(EntityPlayer p, double maxRange, double maxFov) {
        if (p == null || p == MC.thePlayer || p.isDead || !p.isEntityAlive()) return false;
        if (MC.thePlayer.getDistanceToEntity(p) > maxRange) return false;
        float yaw = RotationUtil.getRotationsTo(p.posX, p.posY + p.getEyeHeight() * 0.5, p.posZ, MC.thePlayer.rotationYaw, MC.thePlayer.rotationPitch)[0];
        if (Math.abs(wrap(yaw - MC.thePlayer.rotationYaw)) > maxFov) return false;
        if (TeamUtil.isFriend(p)) return false;
        if (team.getValue() && TeamUtil.isSameTeam(p)) return false;
        return !botChecks.getValue() || !TeamUtil.isBot(p);
    }

    private void applyAim() {
        long now = System.nanoTime();
        double dt = lastFrameNanos < 0 ? 0.016 : Math.max(0.0005, Math.min(0.05, (now-lastFrameNanos)*1e-9));
        lastFrameNanos = now;
        EntityPlayer target = activeTarget;
        AxisAlignedBB bb = target.getEntityBoundingBox();
        double rawX=(bb.minX+bb.maxX)*0.5, rawZ=(bb.minZ+bb.maxZ)*0.5;
        targetVelX=(target.posX-target.prevPosX)*20.0; targetVelZ=(target.posZ-target.prevPosZ)*20.0;
        double alpha=1.0-Math.exp(-dt/0.09);
        if (!hasSmoothPoint){smoothPointX=rawX;smoothPointZ=rawZ;hasSmoothPoint=true;} else {smoothPointX+=(rawX-smoothPointX)*alpha;smoothPointZ+=(rawZ-smoothPointZ)*alpha;}
        double tx=smoothPointX+targetVelX*0.07, tz=smoothPointZ+targetVelZ*0.07;
        double eyeY=MC.thePlayer.posY+MC.thePlayer.getEyeHeight();
        double dx=tx-MC.thePlayer.posX,dz=tz-MC.thePlayer.posZ,h=Math.sqrt(dx*dx+dz*dz);
        float desiredYaw=(float)(Math.toDegrees(Math.atan2(dz,dx))-90.0);
        double top=-(Math.toDegrees(Math.atan2(bb.maxY-eyeY,h))), bottom=-(Math.toDegrees(Math.atan2(bb.minY-eyeY,h)));
        double pitch=MC.thePlayer.rotationPitch;
        if(pitch<top+0.75) pitch=top+0.75; else if(pitch>bottom-0.75) pitch=bottom-0.75;
        float desiredPitch=(float)Math.max(-89.9,Math.min(89.9,pitch));
        float cy=MC.thePlayer.rotationYaw,cp=MC.thePlayer.rotationPitch;
        if(!hasLastApplied){lastAppliedYaw=cy;lastAppliedPitch=cp;hasLastApplied=true;}
        float manualYaw=wrap(cy-lastAppliedYaw), manualPitch=cp-lastAppliedPitch;
        double manualMag=Math.sqrt(manualYaw*manualYaw+manualPitch*manualPitch);
        if(manualMag>0.6) manualHoldNanos=120_000_000L; else manualHoldNanos=Math.max(0,manualHoldNanos-(long)(dt*1e9));
        double targetBlend=manualHoldNanos>0?0.7:1.0;
        blend+=(targetBlend-blend)*(1-Math.exp(-dt/0.18));
        float yawStep=(float)Math.max(-900*dt,Math.min(900*dt,(desiredYaw-cy)*Math.min(1.0,hSpeed.getValue()/10.0)*0.5*blend));
        float pitchStep=(float)Math.max(-675*dt,Math.min(675*dt,(desiredPitch-cp)*Math.min(1.0,vSpeed.getValue()/10.0)*0.5*blend));
        float ny=cy+yawStep,np=(float)Math.max(-90,Math.min(90,cp+pitchStep));
        Myau.rotationManager.setRotation(ny,np,0,false);
        lastAppliedYaw=ny;lastAppliedPitch=np;
    }

    private void resetAimOnly(){activeTarget=null;hasSmoothPoint=false;targetVelX=targetVelZ=0;hasLastApplied=false;velYaw=velPitch=0;}
    private void resetTracking(){resetAimOnly();resetCombo();lastFrameNanos=-1L;blend=1.0F;}
    private void resetCombo(){comboTarget=null;comboCount=0;prevComboTargetHurtTime=0;prevComboDistance=0;comboAimActive=false;}
    private boolean hasLineOfSight(EntityPlayer target){Vec3 eye=new Vec3(MC.thePlayer.posX,MC.thePlayer.posY+MC.thePlayer.getEyeHeight(),MC.thePlayer.posZ);AxisAlignedBB bb=target.getEntityBoundingBox();Vec3 p=new Vec3((bb.minX+bb.maxX)*.5,(bb.minY+bb.maxY)*.5,(bb.minZ+bb.maxZ)*.5);return MC.theWorld.rayTraceBlocks(eye,p)==null;}
    private double distanceTo(EntityPlayer p){return MC.thePlayer.getDistanceToEntity(p);}
    private float wrap(float d){while(d<=-180)d+=360;while(d>180)d-=360;return d;}

    @Override public void onEnabled(){resetTracking();}
    @Override public void onDisabled(){resetTracking();}
    public EntityPlayer getEnemy(){return activeTarget;}
}
