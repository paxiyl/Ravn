package myau.mixin;

import myau.module.modules.AimSmooth;
import net.minecraft.util.MouseHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = MouseHelper.class, priority = 9999)
public abstract class MixinMouseHelper {
    @Shadow private int deltaX;
    @Shadow private int deltaY;

    @Inject(method = "mouseXYChange", at = @At("RETURN"))
    private void myau$aimSmooth(CallbackInfo ci) {
        int[] filtered = AimSmooth.onMouseDelta(this.deltaX, this.deltaY);
        this.deltaX = filtered[0];
        this.deltaY = filtered[1];
    }
}
